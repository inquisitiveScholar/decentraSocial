import { useState, useEffect, useCallback } from "react";
import { useLocation, useRouter } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useWalletConnect } from "@/hooks/useWalletConnect";
import { useAuth } from "@/context/AuthContext";
import { Loader2 } from "lucide-react";
import { formatUrl } from "@/lib/utils";
import NetworkGate from "@/components/NetworkGate";
import WalletAccountSwitcher from "@/components/WalletAccountSwitcher";

// Import DC avatar images directly
import dcAvatar1 from "@assets/DC_avtar1_1749581137967.png";
import dcAvatar2 from "@assets/DC_avtar2_1749581137970.png";
import dcAvatar3 from "@assets/DC_avtar3_1749581137970.png";
import dcAvatar4 from "@assets/DC_avtar4_1749581137970.png";
import dcAvatar5 from "@assets/DC_avtar5_1749581137970.png";
import dcAvatar6 from "@assets/DC_avtar6_1749581137970.png";
import dcAvatar7 from "@assets/DC_avtar7_1749581137970.png";
import dcAvatar8 from "@assets/DC_avtar8_1749581137970.png";
import dcAvatar9 from "@assets/DC_avtar9_1749581137969.png";
import dcAvatar10 from "@assets/DC_avtar10_1749581137969.png";
import dcAvatar11 from "@assets/DC_avtar11_1749581137969.png";
import dcAvatar12 from "@assets/DC_avtar12_1749581137969.png";
import dcAvatar13 from "@assets/DC_avtar13_1749581137969.png";
import dcAvatar14 from "@assets/DC_avtar14_1749581137968.png";

const avatarOptions = [
  { id: "dc_avatar_1", src: dcAvatar1, name: "DC Avatar 1" },
  { id: "dc_avatar_2", src: dcAvatar2, name: "DC Avatar 2" },
  { id: "dc_avatar_3", src: dcAvatar3, name: "DC Avatar 3" },
  { id: "dc_avatar_4", src: dcAvatar4, name: "DC Avatar 4" },
  { id: "dc_avatar_5", src: dcAvatar5, name: "DC Avatar 5" },
  { id: "dc_avatar_6", src: dcAvatar6, name: "DC Avatar 6" },
  { id: "dc_avatar_7", src: dcAvatar7, name: "DC Avatar 7" },
  { id: "dc_avatar_8", src: dcAvatar8, name: "DC Avatar 8" },
  { id: "dc_avatar_9", src: dcAvatar9, name: "DC Avatar 9" },
  { id: "dc_avatar_10", src: dcAvatar10, name: "DC Avatar 10" },
  { id: "dc_avatar_11", src: dcAvatar11, name: "DC Avatar 11" },
  { id: "dc_avatar_12", src: dcAvatar12, name: "DC Avatar 12" },
  { id: "dc_avatar_13", src: dcAvatar13, name: "DC Avatar 13" },
  { id: "dc_avatar_14", src: dcAvatar14, name: "DC Avatar 14" },
];

export default function EthWalletAuthPage() {
  const [, navigate] = useLocation();
  const { toast } = useToast();
  
  // Get authentication context from our hook
  const { 
    user,
    loginWithWallet,
    checkWalletRegistration
  } = useAuth();

  // Get wallet connection from our custom hook
  const { 
    walletAddress, 
    walletConnected,
    isConnecting: isWalletConnecting,
    isRegistering: isWalletRegistering,
    connectWallet,
    registerWithWallet
  } = useWalletConnect();
  
  // Show registration form or not
  const [showRegistrationForm, setShowRegistrationForm] = useState(false);
  
  // Registration form state
  const [username, setUsername] = useState("");
  const [displayName, setDisplayName] = useState("");
  const [bio, setBio] = useState("");
  const [selectedAvatar, setSelectedAvatar] = useState(avatarOptions[0].id);
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const [isWalletRegistered, setIsWalletRegistered] = useState<boolean | null>(null);
  const [hasShownRegisteredToast, setHasShownRegisteredToast] = useState(false);
  const [isCheckingUsername, setIsCheckingUsername] = useState(false);
  const [isAuthenticating, setIsAuthenticating] = useState(false);
  const [selectedWalletAddress, setSelectedWalletAddress] = useState<string | null>(null);

  // If user is already logged in, redirect to home
  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  // Check wallet registration status only
  const handleCheckWallet = async () => {
    if (walletAddress && walletConnected && !user) {
      try {
        const isRegistered = await checkWalletRegistration(walletAddress);
        setIsWalletRegistered(isRegistered);
        
        if (isRegistered && !hasShownRegisteredToast) {
          setHasShownRegisteredToast(true);
          toast({
            title: "Wallet recognized",
            description: "Your wallet is registered. Click 'Proceed to Authentication' to sign in.",
          });
        } else if (!isRegistered && !hasShownRegisteredToast) {
          setHasShownRegisteredToast(true);
          toast({
            title: "New wallet detected",
            description: "This wallet needs to be registered. Please create an account.",
          });
        }
      } catch (error) {
        console.error("Error checking wallet registration:", error);
        setIsWalletRegistered(false);
      }
    }
  };

  // Handle authentication for registered wallets
  const handleAuthentication = async () => {
    const currentAddress = selectedWalletAddress || walletAddress;
    if (!currentAddress) return;
    
    setIsAuthenticating(true);
    try {
      const result = await loginWithWallet(currentAddress);
      if (result) {
        toast({
          title: "Welcome back!",
          description: "You've been logged in successfully.",
        });
        // Smooth navigation to home page
        setTimeout(() => {
          navigate("/");
        }, 1000);
      }
    } catch (error) {
      console.error("Authentication failed:", error);
      toast({
        variant: "destructive",
        title: "Authentication failed",
        description: "Could not log you in. Please try again.",
      });
    } finally {
      setIsAuthenticating(false);
    }
  };

  // Check wallet registration status when wallet connects
  useEffect(() => {
    if (walletAddress && walletConnected && !user) {
      handleCheckWallet();
    } else if (!walletAddress || !walletConnected) {
      setIsWalletRegistered(null);
      setHasShownRegisteredToast(false);
    }
  }, [walletAddress, walletConnected, user]);

  // Handle username availability check
  const checkUsernameAvailability = useCallback(async (usernameToCheck?: string) => {
    const currentUsername = usernameToCheck || username;
    if (!currentUsername || currentUsername.length < 3) return;
    
    setIsCheckingUsername(true);
    try {
      const currentWalletAddress = selectedWalletAddress || walletAddress;
      const url = currentWalletAddress 
        ? formatUrl(`/api/users/check-username?username=${currentUsername}&walletAddress=${currentWalletAddress}`)
        : formatUrl(`/api/users/check-username?username=${currentUsername}`);
      
      console.log("Checking username availability with URL:", url);
      const response = await fetch(url);
      const data = await response.json();
      console.log("Username check response:", data);
      
      setUsernameAvailable(data.available);
      
      // Check if wallet is already registered
      if (data.walletAlreadyRegistered && data.existingWalletUser) {
        toast({
          variant: "destructive",
          title: "Wallet Already Registered",
          description: `This wallet is already registered to ${data.existingWalletUser.displayName} (@${data.existingWalletUser.username}). Please use the login option instead.`,
        });
        
        // Redirect to login after a short delay
        setTimeout(() => {
          navigate('/login');
        }, 3000);
        return;
      }
      
      if (!data.available) {
        toast({
          variant: "destructive",
          title: "Username unavailable",
          description: "This username is already taken. Please choose another one."
        });
      }
    } catch (error) {
      console.error("Error checking username:", error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to check username availability. Please try again."
      });
    } finally {
      setIsCheckingUsername(false);
    }
  }, [username, walletAddress, selectedWalletAddress, toast, navigate]);

  // Debounced username check effect
  useEffect(() => {
    if (username && username.length >= 3) {
      const timer = setTimeout(() => {
        checkUsernameAvailability();
      }, 500); // 500ms delay after user stops typing
      
      return () => clearTimeout(timer);
    } else {
      setUsernameAvailable(null);
    }
  }, [username, checkUsernameAvailability]);

  // Create a proper blur handler
  const handleUsernameBlur = () => {
    checkUsernameAvailability();
  };

  // Handle registration
  const handleRegister = async () => {
    if (!walletAddress || !walletConnected) {
      toast({
        variant: "destructive",
        title: "Wallet not connected",
        description: "Please connect your wallet first"
      });
      return;
    }
    
    if (!username || !displayName) {
      toast({
        variant: "destructive",
        title: "Missing information",
        description: "Please fill in all required fields"
      });
      return;
    }
    
    if (username.length < 3) {
      toast({
        variant: "destructive",
        title: "Username too short",
        description: "Username must be at least 3 characters long"
      });
      return;
    }
    
    try {
      await registerWithWallet({
        username,
        displayName,
        bio: bio || null,
        avatar: selectedAvatar,
        walletAddress: selectedWalletAddress || walletAddress!,
        network: "0x4b18" // DCSM network
      });
      
      // Smooth redirect to home page after successful registration
      setTimeout(() => {
        navigate("/");
      }, 1500);
      
    } catch (error) {
      console.error("Registration error:", error);
    }
  };

  return (
    <NetworkGate requireUserConfirmation={true}>
      <div className="min-h-screen flex flex-col items-center justify-center bg-background p-4">
        <div className="max-w-5xl w-full mx-auto flex flex-col lg:flex-row gap-8">
        {/* Hero section */}
        <div className="flex-1 flex flex-col justify-center">
          <h1 className="text-4xl font-bold tracking-tight text-primary mb-3">
            Web3 Social Platform
          </h1>
          <p className="text-xl text-muted-foreground mb-8">
            Connect with crypto enthusiasts, share ideas, and join the decentralized social revolution
          </p>
          <div className="space-y-4">
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M19 12a7 7 0 11-14 0 7 7 0 0114 0z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary" />
                  <path d="M21.54 15a10 10 0 01-4.53 5.1" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Web3 Wallet Authentication</h3>
                <p className="text-sm text-muted-foreground">Connect and sign in with your Ethereum wallet</p>
              </div>
            </div>
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M9 12h.01M12 12h.01M15 12h.01M9 16h6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary" />
                  <path d="M12 22c5.523 0 10-4.477 10-10S17.523 2 12 2 2 6.477 2 12c0 1.821.487 3.53 1.338 5L2.5 21.5l4.5-.838A9.955 9.955 0 0012 22z" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Share Ideas</h3>
                <p className="text-sm text-muted-foreground">Post thoughts, memes, and more with crypto community</p>
              </div>
            </div>
            <div className="flex items-center">
              <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center mr-3">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M16 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary" />
                  <path d="M8.5 11a4 4 0 100-8 4 4 0 000 8zM20 8v6M23 11h-6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="text-primary" />
                </svg>
              </div>
              <div>
                <h3 className="font-medium">Connect with Others</h3>
                <p className="text-sm text-muted-foreground">Follow, comment, and discover like-minded enthusiasts</p>
              </div>
            </div>
          </div>
        </div>

        {/* Auth section */}
        <div className="flex-1 flex flex-col items-center justify-center">
          <Card className="w-full max-w-md border-border">
            <CardHeader>
              <h2 className="text-2xl font-bold mb-0 text-center">Connect Your Wallet</h2>
            </CardHeader>
            <CardContent>
              {!walletConnected ? (
                <div className="space-y-4">
                  <p className="text-muted-foreground text-center mb-4">
                    Connect your Ethereum wallet to continue
                  </p>
                  <Button 
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                    onClick={connectWallet}
                    disabled={isWalletConnecting}
                  >
                    {isWalletConnecting ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Connecting...
                      </>
                    ) : "Connect Wallet"}
                  </Button>
                </div>
              ) : isWalletRegistered === true ? (
                <div className="space-y-4 text-center">
                  <div className="p-4 bg-green-500/10 rounded-md border border-green-500/20">
                    <p className="text-green-500 mb-2">Wallet Recognized!</p>
                    <p className="text-muted-foreground text-sm">
                      Your wallet is registered. Click below to authenticate and access your account.
                    </p>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Address: {walletAddress?.slice(0, 6)}...{walletAddress?.slice(-4)}
                  </p>
                  <Button 
                    className="w-full bg-primary hover:bg-primary/90 text-primary-foreground"
                    onClick={handleAuthentication}
                    disabled={isAuthenticating}
                  >
                    {isAuthenticating ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Authenticating...
                      </>
                    ) : "Proceed to Authentication"}
                  </Button>
                </div>
              ) : isWalletRegistered === false ? (
                <div className="space-y-6">
                  <div className="p-3 bg-blue-500/10 rounded-md border border-blue-500/20 mb-4">
                    <p className="text-blue-500 text-sm">
                      <span className="font-medium">Wallet Connected:</span> {(selectedWalletAddress || walletAddress)?.slice(0, 6)}...{(selectedWalletAddress || walletAddress)?.slice(-4)}
                    </p>
                  </div>
                  
                  {/* Account Switcher */}
                  <WalletAccountSwitcher
                    onAccountChange={setSelectedWalletAddress}
                    currentAddress={selectedWalletAddress || walletAddress || ""}
                    isConnected={walletConnected}
                  />
                  
                  {showRegistrationForm ? (
                    <div className="space-y-4">
                      {/* Registration Form */}
                      <div className="space-y-2">
                        <Label htmlFor="username">Username</Label>
                        <div className="flex gap-2">
                          <Input
                            id="username"
                            placeholder="Choose a unique username"
                            value={username}
                            onChange={(e) => {
                              setUsername(e.target.value);
                              setUsernameAvailable(null);
                            }}
                            onBlur={handleUsernameBlur}
                            className={usernameAvailable === true ? "border-green-500" : ""}
                          />
                          {isCheckingUsername ? (
                            <Button variant="outline" size="icon" disabled>
                              <Loader2 className="h-4 w-4 animate-spin" />
                            </Button>
                          ) : usernameAvailable === true ? (
                            <Button variant="outline" size="icon" className="bg-green-50 border-green-500">
                              <svg width="15" height="15" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg" className="text-green-500">
                                <path d="M11.4669 3.72684C11.7558 3.91574 11.8369 4.30308 11.648 4.59198L7.39799 11.092C7.29783 11.2452 7.13556 11.3467 6.95402 11.3699C6.77247 11.3931 6.58989 11.3355 6.45446 11.2124L3.70446 8.71241C3.44905 8.48022 3.43023 8.08494 3.66242 7.82953C3.89461 7.57412 4.28989 7.55529 4.5453 7.78749L6.75292 9.79441L10.6018 3.90792C10.7907 3.61902 11.178 3.53795 11.4669 3.72684Z" fill="currentColor" fillRule="evenodd" clipRule="evenodd"></path>
                              </svg>
                            </Button>
                          ) : null}
                        </div>
                        {usernameAvailable === true && (
                          <p className="text-xs text-green-500 flex items-center mt-1">
                            <svg width="12" height="12" viewBox="0 0 15 15" fill="none" xmlns="http://www.w3.org/2000/svg" className="mr-1">
                              <path d="M11.4669 3.72684C11.7558 3.91574 11.8369 4.30308 11.648 4.59198L7.39799 11.092C7.29783 11.2452 7.13556 11.3467 6.95402 11.3699C6.77247 11.3931 6.58989 11.3355 6.45446 11.2124L3.70446 8.71241C3.44905 8.48022 3.43023 8.08494 3.66242 7.82953C3.89461 7.57412 4.28989 7.55529 4.5453 7.78749L6.75292 9.79441L10.6018 3.90792C10.7907 3.61902 11.178 3.53795 11.4669 3.72684Z" fill="currentColor" fillRule="evenodd" clipRule="evenodd"></path>
                            </svg>
                            Username is available!
                          </p>
                        )}
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="displayName">Display Name</Label>
                        <Input
                          id="displayName"
                          placeholder="Your display name"
                          value={displayName}
                          onChange={(e) => setDisplayName(e.target.value)}
                        />
                      </div>

                      <div className="space-y-2">
                        <Label htmlFor="bio">Bio</Label>
                        <Textarea
                          id="bio"
                          placeholder="Tell us about yourself"
                          value={bio}
                          onChange={(e) => setBio(e.target.value)}
                          className="resize-none"
                        />
                      </div>

                      <div className="space-y-2">
                        <Label>Choose an Avatar</Label>
                        <div className="grid grid-cols-3 gap-2">
                          {avatarOptions.map((avatar, index) => (
                            <div
                              key={index}
                              className={`cursor-pointer p-1 rounded-md ${
                                selectedAvatar === avatar.id ? "bg-primary/20 ring-2 ring-primary" : ""
                              }`}
                              onClick={() => setSelectedAvatar(avatar.id)}
                            >
                              <Avatar className="h-16 w-16 mx-auto">
                                <AvatarImage src={avatar.src} alt={avatar.name} />
                                <AvatarFallback>DC</AvatarFallback>
                              </Avatar>
                            </div>
                          ))}
                        </div>
                      </div>

                      <div className="flex gap-3 mt-6">
                        <Button 
                          variant="outline"
                          className="flex-1"
                          onClick={() => setShowRegistrationForm(false)}
                        >
                          Cancel
                        </Button>

                        <Button 
                          className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600" 
                          onClick={handleRegister}
                          disabled={isWalletRegistering || !username || !displayName || usernameAvailable !== true}
                        >
                          {isWalletRegistering ? (
                            <>
                              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                              Creating Account...
                            </>
                          ) : (
                            "Create Account"
                          )}
                        </Button>
                      </div>
                    </div>
                  ) : (
                    <>
                      <div className="p-4 bg-yellow-500/10 rounded-md border border-yellow-500/20">
                        <p className="font-medium mb-1">New wallet detected!</p>
                        <p className="text-sm text-muted-foreground">
                          This wallet address isn't registered yet. Would you like to create a new account or go back?
                        </p>
                      </div>
                      
                      <div className="flex gap-4">
                        <Button 
                          variant="outline" 
                          className="flex-1"
                          onClick={() => navigate("/login")}
                        >
                          Go Back
                        </Button>
                        <Button 
                          className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600"
                          onClick={() => setShowRegistrationForm(true)}
                        >
                          Register Now
                        </Button>
                      </div>
                    </>
                  )}
                </div>
              ) : (
                <div className="text-center">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto" />
                  <p className="text-muted-foreground mt-2">Checking wallet status...</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
        </div>
      </div>
    </NetworkGate>
  );
}