import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

export default function Login() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  // If user is already logged in, redirect to home
  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0d1425] p-4">
      <Card className="w-full max-w-md border-[#1a2747] bg-[#0f172a] text-white">
        <CardHeader className="pb-6">
          <CardTitle className="text-2xl font-bold text-center bg-gradient-to-r from-blue-400 to-indigo-500 bg-clip-text text-transparent">
            Welcome to Web3 Social
          </CardTitle>
          <CardDescription className="text-center text-gray-400">
            Connect your wallet to sign in or create a new account
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="p-6 border border-[#1a2747] rounded-lg bg-[#131d33] text-center">
            <svg className="w-16 h-16 mx-auto mb-4" viewBox="0 0 784.37 1277.39" xmlns="http://www.w3.org/2000/svg">
              <g>
                <polygon fill="#343434" fillRule="nonzero" points="392.07,0 383.5,29.11 383.5,873.74 392.07,882.29 784.13,650.54"/>
                <polygon fill="#8C8C8C" fillRule="nonzero" points="392.07,0 -0,650.54 392.07,882.29 392.07,472.33"/>
                <polygon fill="#3C3C3B" fillRule="nonzero" points="392.07,956.52 387.24,962.41 387.24,1263.28 392.07,1277.38 784.37,724.89"/>
                <polygon fill="#8C8C8C" fillRule="nonzero" points="392.07,1277.38 392.07,956.52 -0,724.89"/>
                <polygon fill="#141414" fillRule="nonzero" points="392.07,882.29 784.13,650.54 392.07,472.33"/>
                <polygon fill="#393939" fillRule="nonzero" points="0,650.54 392.07,882.29 392.07,472.33"/>
              </g>
            </svg>
            <h3 className="text-xl font-semibold mb-2">Wallet Authentication</h3>
            <p className="text-gray-400 mb-6">Use your Ethereum wallet to securely sign in</p>
            <Button 
              onClick={() => navigate("/eth-wallet-auth")}
              className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700"
            >
              Connect Wallet
            </Button>
          </div>
        </CardContent>
        <CardFooter className="pt-0 text-sm text-center text-gray-500 flex justify-center">
          No registration forms needed - just connect your wallet!
        </CardFooter>
      </Card>
    </div>
  );
}