import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import MobileDrawer from "@/components/MobileDrawer";
import MobileNav from "@/components/MobileNav";
import PostCard from "@/components/PostCard";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import CreatePostInput from "@/components/CreatePostInput";
import { useAuth } from "@/context/AuthContext";
import { apiRequest } from "@/lib/queryClient";
import { useUserPosts } from "@/hooks/usePosts";
import { getAvatarSrc } from "@/components/AvatarSelector";

interface ProfileProps {
  username: string;
}

export default function Profile({ username }: ProfileProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [createPostOpen, setCreatePostOpen] = useState(false);
  const [, navigate] = useLocation();
  const { user: currentUser } = useAuth();
  const isOwnProfile = currentUser?.username === username;
  
  // Local state to track follower count for real-time UI updates
  const [followerCount, setFollowerCount] = useState<number | null>(null);

  // Fetch profile user data from the user search endpoint
  const { data: profileUser, isLoading: isLoadingUser } = useQuery({
    queryKey: ["/api/users/profile", username],
    queryFn: async () => {
      // First try to get the profile directly
      try {
        const profileResponse = await fetch(`/api/users/profile/${username}`, {
          credentials: "include",
        });
        
        if (profileResponse.ok) {
          return profileResponse.json();
        }
      } catch (error) {
        console.error("Error fetching from profile endpoint:", error);
      }
      
      // Fallback to search endpoint
      const response = await fetch(`/api/users/search?q=${username}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to fetch user");
      }
      
      const users = await response.json();
      const user = users.find((u: any) => u.username === username);
      
      if (!user) {
        throw new Error("User not found");
      }
      
      // Add default values for follower/following counts if they don't exist
      return {
        ...user,
        followersCount: user.followersCount || 0,
        followingCount: user.followingCount || 0
      };
    },
  });

  // Update local follower count state when profile data loads
  if (profileUser && followerCount === null) {
    setFollowerCount(profileUser.followersCount || 0);
  }

  // Fetch user posts
  const { data: posts = [], isLoading: isLoadingPosts } = useUserPosts(
    profileUser?.id, 
    20, 
    0
  );

  // Check if current user is following this profile
  const { data: followData, refetch: refetchFollowStatus } = useQuery({
    queryKey: ["/api/users", profileUser?.id, "follow"],
    queryFn: async () => {
      if (!currentUser || !profileUser) return { following: false };
      
      const response = await fetch(`/api/users/${profileUser.id}/follow`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to fetch follow status");
      }
      
      return response.json();
    },
    enabled: !!currentUser && !!profileUser && !isOwnProfile,
  });

  // Follow/unfollow mutation
  const followMutation = useMutation({
    mutationFn: async () => {
      if (!profileUser) throw new Error("No profile user");
      
      if (followData?.following) {
        // Unfollow
        return apiRequest("DELETE", `/api/users/${profileUser.id}/follow`);
      } else {
        // Follow
        return apiRequest("POST", `/api/users/${profileUser.id}/follow`);
      }
    },
    onSuccess: async () => {
      // Update follower count in the UI immediately for better UX
      if (followerCount !== null) {
        if (followData?.following) {
          // User unfollowed, decrement count
          setFollowerCount(Math.max(0, followerCount - 1));
        } else {
          // User followed, increment count
          setFollowerCount(followerCount + 1);
        }
      }
      
      // Refetch follow status to ensure UI is consistent
      await refetchFollowStatus();
    },
  });

  const handleFollowToggle = () => {
    if (!currentUser) {
      navigate("/login");
      return;
    }
    
    followMutation.mutate();
  };

  if (isLoadingUser) {
    return (
      <div className="flex flex-col min-h-screen">
        <Header openMobileMenu={() => setMobileMenuOpen(true)} />
        
        <div className="flex flex-1 relative">
          <MobileDrawer 
            isOpen={mobileMenuOpen} 
            onClose={() => setMobileMenuOpen(false)} 
          />
          
          <Sidebar />
          
          <main className="flex-1 max-w-2xl mx-auto border-l border-r border-elevation4 min-h-[calc(100vh-4rem)]">
            <div className="p-4 text-center mt-10">
              <div className="animate-spin h-8 w-8 border-t-2 border-b-2 border-primary rounded-full mx-auto"></div>
              <p className="mt-2">Loading profile...</p>
            </div>
          </main>
        </div>
        
        <MobileNav onCreatePost={() => setCreatePostOpen(true)} />
      </div>
    );
  }

  if (!profileUser) {
    return (
      <div className="flex flex-col min-h-screen">
        <Header openMobileMenu={() => setMobileMenuOpen(true)} />
        
        <div className="flex flex-1 relative">
          <MobileDrawer 
            isOpen={mobileMenuOpen} 
            onClose={() => setMobileMenuOpen(false)} 
          />
          
          <Sidebar />
          
          <main className="flex-1 max-w-2xl mx-auto border-l border-r border-elevation4 min-h-[calc(100vh-4rem)]">
            <div className="p-4 text-center mt-10">
              <p className="text-destructive">User not found</p>
              <Button 
                className="mt-4"
                onClick={() => navigate("/")}
              >
                Go Home
              </Button>
            </div>
          </main>
        </div>
        
        <MobileNav onCreatePost={() => setCreatePostOpen(true)} />
      </div>
    );
  }

  // Current follower count (use local state if available, otherwise from profile data)
  const displayFollowerCount = followerCount !== null ? followerCount : profileUser.followersCount || 0;

  return (
    <div className="flex flex-col min-h-screen">
      <Header openMobileMenu={() => setMobileMenuOpen(true)} />
      
      <div className="flex flex-1 relative">
        <MobileDrawer 
          isOpen={mobileMenuOpen} 
          onClose={() => setMobileMenuOpen(false)} 
        />
        
        <Sidebar />
        
        <main className="flex-1 max-w-2xl mx-auto border-l border-r border-elevation4 min-h-[calc(100vh-4rem)]">
          {/* Profile Header */}
          <div className="bg-elevation1 p-6 border-b border-elevation4">
            <div className="flex items-center mb-4">
              <div className="h-20 w-20 rounded-full overflow-hidden mr-4">
                {profileUser.avatar ? (
                  <img 
                    src={getAvatarSrc(profileUser.avatar)} 
                    alt={`${profileUser.displayName}'s avatar`} 
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <div className="h-full w-full bg-primary flex items-center justify-center">
                    <span className="material-icons text-xl text-primary-foreground">person</span>
                  </div>
                )}
              </div>
              
              <div className="flex-1">
                <h1 className="text-2xl font-bold">{profileUser.displayName}</h1>
                <p className="text-gray-400">@{profileUser.username}</p>
                
                {!isOwnProfile && currentUser && profileUser.id !== currentUser.id && (
                  <Button
                    className={
                      followData?.following
                        ? "mt-2 px-4 bg-transparent border border-primary text-primary hover:bg-primary hover:text-primary-foreground"
                        : "mt-2 px-4 bg-primary text-primary-foreground hover:bg-primary/90"
                    }
                    onClick={handleFollowToggle}
                    disabled={followMutation.isPending}
                  >
                    {followMutation.isPending ? "Processing..." : (followData?.following ? "Unfollow" : "Follow")}
                  </Button>
                )}
              </div>
            </div>
            
            {profileUser.bio && (
              <p className="mb-4">{profileUser.bio}</p>
            )}
            
            <div className="flex space-x-6">
              <div>
                <span className="font-bold">{profileUser.followingCount || 0}</span>{" "}
                <span className="text-gray-400">Following</span>
              </div>
              <div>
                <span className="font-bold">{displayFollowerCount}</span>{" "}
                <span className="text-gray-400">Followers</span>
              </div>
            </div>
          </div>
          
          <Tabs defaultValue="posts" className="w-full">
            <TabsList className="w-full grid grid-cols-2 bg-elevation2">
              <TabsTrigger value="posts">Posts</TabsTrigger>
              <TabsTrigger value="media">Media</TabsTrigger>
            </TabsList>
            
            <TabsContent value="posts" className="divide-y divide-elevation4">
              {isLoadingPosts ? (
                <div className="p-4 text-center">
                  <div className="animate-spin h-8 w-8 border-t-2 border-b-2 border-primary rounded-full mx-auto"></div>
                  <p className="mt-2">Loading posts...</p>
                </div>
              ) : posts.length === 0 ? (
                <div className="p-4 text-center py-10">
                  <span className="material-icons text-4xl text-gray-400 mb-2">article_off</span>
                  <p className="text-gray-400">No posts yet</p>
                </div>
              ) : (
                posts.map(post => (
                  <PostCard key={post.id} post={post} />
                ))
              )}
            </TabsContent>
            
            <TabsContent value="media" className="divide-y divide-elevation4">
              {isLoadingPosts ? (
                <div className="p-4 text-center">
                  <div className="animate-spin h-8 w-8 border-t-2 border-b-2 border-primary rounded-full mx-auto"></div>
                  <p className="mt-2">Loading media...</p>
                </div>
              ) : posts.filter(post => post.image || post.content.match(/(https?:\/\/.*\.(?:png|jpg|jpeg|gif))/i)).length === 0 ? (
                <div className="p-4 text-center py-10">
                  <span className="material-icons text-4xl text-gray-400 mb-2">image_not_supported</span>
                  <p className="text-gray-400">No media posts yet</p>
                </div>
              ) : (
                posts
                  .filter(post => post.image || post.content.match(/(https?:\/\/.*\.(?:png|jpg|jpeg|gif))/i))
                  .map(post => (
                    <PostCard key={post.id} post={post} />
                  ))
              )}
            </TabsContent>
          </Tabs>
        </main>
      </div>
      
      <MobileNav onCreatePost={() => setCreatePostOpen(true)} />
      
      <Dialog open={createPostOpen} onOpenChange={setCreatePostOpen}>
        <DialogContent className="bg-elevation2 border-elevation4">
          <DialogHeader>
            <DialogTitle>Create a new post</DialogTitle>
          </DialogHeader>
          <CreatePostInput inDialog onComplete={() => setCreatePostOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
