import { useState, useEffect } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import Header from "@/components/Header";
import Sidebar from "@/components/Sidebar";
import MobileNav from "@/components/MobileNav";
import CreatePostInput from "@/components/CreatePostInput";
import PostCard from "@/components/PostCard";
import TrendingSection from "@/components/TrendingSection";
import UserSuggestions from "@/components/UserSuggestions";
import { usePosts } from "@/hooks/usePosts";
import { queryClient } from "@/lib/queryClient";


export default function Home() {
  const [createPostOpen, setCreatePostOpen] = useState(false);
  const { data: posts = [], isLoading, isError, refetch, isFetching } = usePosts();

  // Optimized refresh - only when user is active and tab is visible
  useEffect(() => {
    let interval: NodeJS.Timeout;
    
    const handleVisibilityChange = () => {
      if (document.visibilityState === 'visible' && !isFetching) {
        refetch();
      }
    };

    // Set up periodic refresh only when tab is visible
    if (document.visibilityState === 'visible') {
      interval = setInterval(() => {
        if (!isFetching) {
          refetch();
        }
      }, 60000); // Reduced to 60 seconds for better performance
    }

    document.addEventListener('visibilitychange', handleVisibilityChange);

    return () => {
      if (interval) clearInterval(interval);
      document.removeEventListener('visibilitychange', handleVisibilityChange);
    };
  }, [refetch, isFetching]);

  return (
    <div className="flex flex-col min-h-screen bg-[#0f172a]">
      <Header />
      
      <div className="flex flex-1 relative">
        <Sidebar />
        
        <main className="flex-1 max-w-2xl mx-auto border-l border-r border-[#1a2747] min-h-[calc(100vh-57px)]">
          <CreatePostInput />
          
          <div>
            {isLoading && posts.length === 0 ? (
              <div className="space-y-4">
                {/* Loading skeleton for better UX */}
                {[1, 2, 3].map((i) => (
                  <div key={i} className="border-b border-[#1a2747] p-6">
                    <div className="flex space-x-3 animate-pulse">
                      <div className="w-12 h-12 bg-gray-700 rounded-full"></div>
                      <div className="flex-1 space-y-2">
                        <div className="h-4 bg-gray-700 rounded w-1/4"></div>
                        <div className="h-4 bg-gray-700 rounded w-3/4"></div>
                        <div className="h-4 bg-gray-700 rounded w-1/2"></div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            ) : isError ? (
              <div className="p-6 text-center">
                <p className="text-red-400">Failed to load posts. Please try again.</p>
                <button 
                  onClick={() => refetch()} 
                  className="mt-2 px-4 py-2 bg-primary text-white rounded hover:bg-primary/80"
                >
                  Retry
                </button>
              </div>
            ) : posts.length === 0 ? (
              <div className="p-6 text-center">
                <p className="text-gray-400">No posts yet. Be the first to post!</p>
              </div>
            ) : (
              <>
                {posts.map((post: any) => (
                  <PostCard key={post.id} post={post} />
                ))}
                {isFetching && posts.length > 0 && (
                  <div className="p-4 text-center">
                    <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin mx-auto"></div>
                  </div>
                )}
              </>
            )}
          </div>
        </main>
        
        <aside className="hidden lg:block w-80 p-4 sticky top-[57px] h-[calc(100vh-57px)] overflow-y-auto scrollbar-hide">
          <TrendingSection />
          <UserSuggestions />
          
          <div className="bg-[#141e33] rounded-xl p-4 border border-[#1a2747] text-sm text-gray-400">
            <div className="mb-4 flex flex-wrap gap-2">
              <a href="#" className="hover:text-primary hover:underline transition-colors">Terms</a>
              <a href="#" className="hover:text-primary hover:underline transition-colors">Privacy</a>
              <a href="#" className="hover:text-primary hover:underline transition-colors">Cookies</a>
              <a href="#" className="hover:text-primary hover:underline transition-colors">About</a>
              <a href="#" className="hover:text-primary hover:underline transition-colors">More</a>
            </div>
            <div>© 2025 Hey, Inc.</div>
          </div>
        </aside>
      </div>
      
      <MobileNav onCreatePost={() => setCreatePostOpen(true)} />
      
      <Dialog open={createPostOpen} onOpenChange={setCreatePostOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl">
          <DialogHeader>
            <DialogTitle className="text-lg text-white font-bold">Create a new post</DialogTitle>
          </DialogHeader>
          <CreatePostInput inDialog onComplete={() => setCreatePostOpen(false)} />
        </DialogContent>
      </Dialog>
    </div>
  );
}
