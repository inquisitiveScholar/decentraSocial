import { useEffect } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/context/AuthContext";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";

export default function Auth() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  // If user is already logged in, redirect to home
  useEffect(() => {
    if (user) {
      navigate("/");
    }
  }, [user, navigate]);

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#0d1425] p-4">
      <Card className="w-full max-w-md border-[#1a2747] bg-[#0f172a] text-white">
        <CardHeader className="pb-6">
          <CardTitle className="text-2xl sm:text-3xl font-bold text-center bg-gradient-to-r from-purple-400 to-blue-500 bg-clip-text text-transparent">DC Social</CardTitle>
          <CardDescription className="text-center text-gray-400 mt-2">
            Connect your wallet and join the community
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 px-4 sm:px-6">
          <div className="p-4 sm:p-5 border border-purple-900/30 rounded-lg bg-[#131d33] text-center shadow-md">
            <h3 className="text-lg sm:text-xl font-semibold mb-3">Already have an account?</h3>
            <Button 
              onClick={() => navigate("/login")}
              className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-2"
            >
              Sign In
            </Button>
          </div>

          <div className="p-4 sm:p-5 border border-blue-900/30 rounded-lg bg-[#131d33] text-center shadow-md">
            <h3 className="text-lg sm:text-xl font-semibold mb-3">New to the platform?</h3>
            <Button 
              onClick={() => navigate("/eth-wallet-auth")}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 text-white py-2"
            >
              Sign Up
            </Button>
          </div>
        </CardContent>
        <CardFooter className="pt-2 text-sm text-center text-gray-400 flex justify-center px-4">
          Secure wallet authentication for Web3 enthusiasts
        </CardFooter>
      </Card>
    </div>
  );
}