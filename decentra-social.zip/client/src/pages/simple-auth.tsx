import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { useWeb3 } from '@/context/Web3Context';
import { Wallet } from 'lucide-react';

export default function SimpleAuth() {
  const { address, isConnected, openModal, disconnect } = useWeb3();
  const [walletInfo, setWalletInfo] = useState<any>(null);

  const handleConnect = () => {
    openModal();
  };

  const handleDisconnect = () => {
    disconnect();
    setWalletInfo(null);
  };

  return (
    <div className="min-h-screen bg-background flex items-center justify-center">
      <Card className="w-[350px] shadow-lg">
        <CardHeader>
          <CardTitle className="text-center">Web3 Auth Demo</CardTitle>
          <CardDescription className="text-center">Connect your wallet to authenticate</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {isConnected ? (
            <div className="p-4 border rounded border-border">
              <h3 className="font-medium mb-2">Wallet Connected</h3>
              <p className="text-sm text-muted-foreground break-all">{address}</p>
            </div>
          ) : (
            <div className="p-8 border rounded border-border flex flex-col items-center justify-center">
              <Wallet className="h-12 w-12 text-primary mb-4" />
              <p className="text-center text-muted-foreground mb-4">Connect your wallet to continue</p>
            </div>
          )}
        </CardContent>
        <CardFooter>
          {isConnected ? (
            <Button 
              variant="destructive" 
              className="w-full" 
              onClick={handleDisconnect}
            >
              Disconnect Wallet
            </Button>
          ) : (
            <Button 
              className="w-full" 
              onClick={handleConnect}
            >
              <Wallet className="mr-2 h-4 w-4" />
              Connect Wallet
            </Button>
          )}
        </CardFooter>
      </Card>
    </div>
  );
}