import React, { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useAuth } from "@/context/AuthContext";
import { formatDistanceToNow } from "date-fns";
import { 
  Bell, 
  Heart, 
  HeartOff, 
  MessageCircle, 
  UserPlus, 
  FileText, 
  HandHeart,
  Check,
  CheckCheck,
  ArrowLeft
} from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { getAvatarSrc } from "@/components/AvatarSelector";

const getNotificationIcon = (type: string) => {
  switch (type) {
    case 'like':
      return <Heart className="h-5 w-5 text-red-500" />;
    case 'dislike':
      return <HeartOff className="h-5 w-5 text-gray-500" />;
    case 'comment':
      return <MessageCircle className="h-5 w-5 text-blue-500" />;
    case 'follow':
      return <UserPlus className="h-5 w-5 text-green-500" />;
    case 'post':
      return <FileText className="h-5 w-5 text-purple-500" />;
    case 'tip':
      return <HandHeart className="h-5 w-5 text-yellow-500" />;
    default:
      return <Bell className="h-5 w-5 text-gray-500" />;
  }
};

export default function NotificationsPage() {
  const { user } = useAuth();
  const [, navigate] = useLocation();

  const { data: notifications = [], refetch } = useQuery<any[]>({
    queryKey: ["/api/notifications"],
    enabled: !!user,
    refetchInterval: 30000,
  });

  const markAsReadMutation = useMutation({
    mutationFn: (notificationId: number) => 
      apiRequest("PATCH", `/api/notifications/${notificationId}/read`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });

  const markAllAsReadMutation = useMutation({
    mutationFn: () => 
      apiRequest("POST", "/api/notifications/mark-all-read"),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notifications"] });
    },
  });

  const handleNotificationClick = (notification: any) => {
    if (!notification.read) {
      markAsReadMutation.mutate(notification.id);
    }
  };

  const unreadCount = notifications.filter((n) => !n.read).length;

  if (!user) {
    return (
      <div className="min-h-screen bg-[#0f172a] flex items-center justify-center">
        <p className="text-gray-400">Please log in to view notifications</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0f172a] pb-20 md:pb-0">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-[#0f172a] border-b border-[#1a2747] px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button 
              onClick={() => navigate("/")}
              className="p-2 rounded-full hover:bg-[#1a2747] transition-colors"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2">
              <Bell className="h-6 w-6 text-purple-400" />
              <h1 className="text-xl font-bold">Notifications</h1>
              {unreadCount > 0 && (
                <Badge variant="destructive" className="h-6 min-w-6 px-2 text-xs">
                  {unreadCount > 99 ? '99+' : unreadCount}
                </Badge>
              )}
            </div>
          </div>
          
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              onClick={() => markAllAsReadMutation.mutate()}
              disabled={markAllAsReadMutation.isPending}
              className="text-purple-400 hover:text-purple-300"
            >
              <CheckCheck className="h-4 w-4 mr-2" />
              Mark all read
            </Button>
          )}
        </div>
      </div>

      {/* Notifications List */}
      <div className="px-4 py-2">
        {notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <Bell className="h-16 w-16 text-gray-600 mb-4" />
            <h3 className="text-lg font-medium text-gray-300 mb-2">No notifications yet</h3>
            <p className="text-gray-500">When someone interacts with your posts, you'll see it here</p>
          </div>
        ) : (
          <div className="space-y-1">
            {notifications.map((notification: any) => (
              <div
                key={notification.id}
                className={`flex items-start gap-4 p-4 rounded-lg border transition-colors cursor-pointer ${
                  !notification.read 
                    ? 'bg-[#1a2747] border-[#2a3759] hover:bg-[#1e2951]' 
                    : 'bg-[#0f172a] border-[#1a2747] hover:bg-[#141e33]'
                }`}
                onClick={() => handleNotificationClick(notification)}
              >
                {/* Avatar or Icon */}
                <div className="flex-shrink-0 mt-1">
                  {notification.fromUser ? (
                    <Avatar className="h-10 w-10">
                      <AvatarImage 
                        src={notification.fromUser.avatar ? getAvatarSrc(notification.fromUser.avatar) : undefined} 
                        alt={notification.fromUser.displayName}
                      />
                      <AvatarFallback className="bg-primary/10 text-primary">
                        {notification.fromUser.displayName?.charAt(0).toUpperCase() || "U"}
                      </AvatarFallback>
                    </Avatar>
                  ) : (
                    <div className="h-10 w-10 bg-[#2a3759] rounded-full flex items-center justify-center">
                      {getNotificationIcon(notification.type)}
                    </div>
                  )}
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-start justify-between gap-2">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-medium text-white">
                          {notification.fromUser?.displayName || 'Someone'}
                        </span>
                        <div className="flex items-center gap-1">
                          {getNotificationIcon(notification.type)}
                        </div>
                        {!notification.read && (
                          <div className="h-2 w-2 bg-blue-500 rounded-full" />
                        )}
                      </div>
                      
                      <p className="text-gray-300 text-sm leading-relaxed mb-2">
                        {notification.message}
                      </p>
                      
                      <p className="text-xs text-gray-500">
                        {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                      </p>
                    </div>
                    
                    {notification.read && (
                      <Check className="h-4 w-4 text-green-500 flex-shrink-0 mt-1" />
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}