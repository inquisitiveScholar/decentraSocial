import { useState, useEffect } from 'react';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { forceDCSMNetwork, getCurrentWalletAddress } from '@/lib/web3';
import { getDefaultNetwork } from '@/lib/networks';

interface UseWalletConnectReturn {
  walletAddress: string | null;
  walletConnected: boolean;
  isConnecting: boolean;
  isRegistering: boolean;
  connectWallet: () => Promise<void>;
  disconnectWallet: () => void;
  registerWithWallet: (userData: RegisterData) => Promise<void>;
  checkWalletRegistration: (address: string) => Promise<boolean>;
}

interface RegisterData {
  username: string;
  displayName: string;
  bio?: string | null;
  avatar?: string | null;
  walletAddress: string;
  network: string;
}

// Simple hook for wallet connection that doesn't rely on WalletConnect
export const useWalletConnect = (): UseWalletConnectReturn => {
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const { toast } = useToast();
  const { registerWithWallet, checkWalletRegistration: checkRegistration } = useAuth();

  // Check for existing connection on mount
  useEffect(() => {
    const checkExistingConnection = async () => {
      if (typeof window !== 'undefined' && window.ethereum) {
        try {
          const accounts = await window.ethereum.request({ method: 'eth_accounts' });
          if (accounts && accounts.length > 0) {
            setWalletAddress(accounts[0]);
          }
        } catch (error) {
          console.error('Error checking wallet connection:', error);
        }
      }
    };

    checkExistingConnection();
  }, []);

  // Connect wallet - force DCSM Mainnet
  const connectWallet = async (): Promise<void> => {
    setIsConnecting(true);
    try {
      if (typeof window !== 'undefined' && window.ethereum) {
        // Force DCSM Mainnet connection first
        await forceDCSMNetwork();
        
        // Then request account access
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        if (accounts && accounts.length > 0) {
          setWalletAddress(accounts[0]);
          toast({
            title: 'Wallet Connected',
            description: `Connected to DCSM Mainnet: ${accounts[0].slice(0, 6)}...${accounts[0].slice(-4)}`,
          });
        }
      } else {
        toast({
          title: 'Wallet Not Found',
          description: 'Please install MetaMask or another Ethereum wallet extension',
          variant: 'destructive',
        });
      }
    } catch (error) {
      console.error('Error connecting wallet:', error);
      toast({
        title: 'Connection Failed',
        description: 'Failed to connect wallet or switch to DCSM Mainnet. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setIsConnecting(false);
    }
  };

  // Disconnect wallet
  const disconnectWallet = (): void => {
    setWalletAddress(null);
    toast({
      title: 'Wallet Disconnected',
      description: 'Your wallet has been disconnected',
    });
  };

  // Register with wallet - force DCSM Mainnet
  const handleRegisterWithWallet = async (userData: RegisterData): Promise<void> => {
    if (!walletAddress) {
      toast({
        title: 'Wallet Not Connected',
        description: 'Please connect your wallet first',
        variant: 'destructive',
      });
      return;
    }

    setIsRegistering(true);
    try {
      // Force DCSM Mainnet connection before registration
      await forceDCSMNetwork();
      
      // Always use DCSM network
      const dcsmNetwork = getDefaultNetwork();
      
      // Add wallet address to user data
      await registerWithWallet({
        username: userData.username,
        displayName: userData.displayName,
        bio: userData.bio,
        avatar: userData.avatar,
        walletAddress: userData.walletAddress,
        network: dcsmNetwork,
      });

      toast({
        title: 'Account Created',
        description: 'Your account has been created successfully on DCSM Mainnet',
      });
    } catch (error: any) {
      console.error('Registration error:', error);
      
      let errorMessage = 'Failed to create account. Please try again.';
      
      if (error.message?.includes('network') || error.message?.includes('chain')) {
        errorMessage = 'Please ensure you are connected to DCSM Mainnet network. Visit https://dcsocial.org/swap.html if you need DCSM tokens.';
      } else if (error.message?.includes('balance') || error.message?.includes('DCSM')) {
        errorMessage = 'Insufficient DCSM balance. You need at least 0.1 DCSM to register. Visit https://dcsocial.org/swap.html to get DCSM tokens.';
      } else if (error.message?.includes('username')) {
        errorMessage = 'Username is already taken. Please choose a different username.';
      } else if (error.message?.includes('bio')) {
        errorMessage = 'Bio is required for registration. Please fill in your bio.';
      }
      
      toast({
        title: 'Registration Failed',
        description: errorMessage,
        variant: 'destructive',
      });
    } finally {
      setIsRegistering(false);
    }
  };

  // Check if wallet is registered
  const checkWalletRegistration = async (address: string): Promise<boolean> => {
    return checkRegistration(address);
  };

  return {
    walletAddress,
    walletConnected: !!walletAddress,
    isConnecting,
    isRegistering,
    connectWallet,
    disconnectWallet,
    registerWithWallet: handleRegisterWithWallet,
    checkWalletRegistration,
  };
};