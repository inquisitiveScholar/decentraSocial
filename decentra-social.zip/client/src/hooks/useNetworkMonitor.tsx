import { useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { forceDCSMNetwork } from '@/lib/web3';
import { getDefaultNetwork, getNetworkConfig } from '@/lib/networks';

export const useNetworkMonitor = () => {
  const [currentNetwork, setCurrentNetwork] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (!window.ethereum) return;

    const handleChainChanged = async (chainId: string) => {
      const dcsmNetwork = getDefaultNetwork();
      const dcsmConfig = getNetworkConfig(dcsmNetwork);
      
      console.log('Network changed to:', chainId, 'Expected:', dcsmConfig?.chainId);
      
      if (chainId !== dcsmConfig?.chainId) {
        toast({
          title: "Wrong Network Detected",
          description: "Switching to DCSM Mainnet automatically...",
          variant: "destructive",
        });

        // Small delay to ensure network change is registered
        setTimeout(async () => {
          try {
            await forceDCSMNetwork();
            toast({
              title: "Network Switched",
              description: "Now connected to DCSM Mainnet",
            });
          } catch (error) {
            console.error('Network switch error:', error);
            toast({
              title: "Manual Switch Required",
              description: "Please switch to DCSM Mainnet in your wallet settings",
              variant: "destructive",
            });
          }
        }, 1000);
      }
      setCurrentNetwork(chainId);
    };

    const handleAccountsChanged = async (accounts: string[]) => {
      if (accounts.length > 0) {
        // When account changes, ensure we're on DCSM network
        try {
          await forceDCSMNetwork();
        } catch (error) {
          console.error('Failed to enforce DCSM network on account change:', error);
        }
      }
    };

    // Listen for network changes
    window.ethereum.on('chainChanged', handleChainChanged);
    window.ethereum.on('accountsChanged', handleAccountsChanged);

    // Check initial network
    const checkInitialNetwork = async () => {
      try {
        const chainId = await window.ethereum.request({ method: 'eth_chainId' });
        handleChainChanged(chainId);
      } catch (error) {
        console.error('Error checking initial network:', error);
      }
    };

    checkInitialNetwork();

    return () => {
      if (window.ethereum && window.ethereum.removeListener) {
        window.ethereum.removeListener('chainChanged', handleChainChanged);
        window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
      }
    };
  }, [toast]);

  return { currentNetwork };
};