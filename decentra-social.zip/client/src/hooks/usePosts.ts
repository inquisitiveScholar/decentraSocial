import { useQuery } from "@tanstack/react-query";
import { PostWithUser } from "@shared/schema";

export function usePosts(limit = 20, offset = 0, feedType = 'home') {
  return useQuery<PostWithUser[]>({
    queryKey: ["/api/posts", { limit, offset, feedType }],
    queryFn: async ({ queryKey }) => {
      const [url, params] = queryKey;
      const { limit, offset, feedType } = params as { limit: number; offset: number; feedType: string };
      const response = await fetch(`${url}?limit=${limit}&offset=${offset}&feedType=${feedType}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to fetch posts");
      }
      
      return response.json();
    },
    staleTime: 30000, // Consider data fresh for 30 seconds
    gcTime: 300000, // Keep in cache for 5 minutes (v5 syntax)
    refetchOnWindowFocus: false, // Prevent unnecessary refetches
    retry: 2, // Retry failed requests twice
    retryDelay: 1000, // Wait 1 second between retries
  });
}

export function useUserPosts(userId: number, limit = 20, offset = 0) {
  return useQuery<PostWithUser[]>({
    queryKey: ["/api/users", userId, "posts", { limit, offset }],
    queryFn: async ({ queryKey }) => {
      const [, userId, , params] = queryKey;
      const { limit, offset } = params as { limit: number; offset: number };
      const response = await fetch(`/api/users/${userId}/posts?limit=${limit}&offset=${offset}`, {
        credentials: "include",
      });
      
      if (!response.ok) {
        throw new Error("Failed to fetch user posts");
      }
      
      return response.json();
    },
  });
}
