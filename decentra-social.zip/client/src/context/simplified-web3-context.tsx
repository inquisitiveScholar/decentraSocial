import React, { createContext, useContext, ReactNode } from 'react';
import { useLocation } from 'wouter';

// Simple Web3 context with minimal functionality
interface Web3ContextType {
  isConnected: boolean;
  address: string | null;
  openModal: () => void;
}

// Create context with default values
const Web3Context = createContext<Web3ContextType>({
  isConnected: false,
  address: null,
  openModal: () => {},
});

// Provider component
export function SimpleWeb3Provider({ children }: { children: ReactNode }) {
  const [, navigate] = useLocation();

  const openModal = () => {
    // Redirect to our eth-wallet-auth page instead of using Web3Modal
    navigate('/eth-wallet-auth');
  };

  return (
    <Web3Context.Provider
      value={{
        isConnected: false,
        address: null,
        openModal,
      }}
    >
      {children}
    </Web3Context.Provider>
  );
}

// Hook for using the context
export function useWeb3() {
  const context = useContext(Web3Context);
  if (context === undefined) {
    throw new Error('useWeb3 must be used within a Web3Provider');
  }
  return context;
}