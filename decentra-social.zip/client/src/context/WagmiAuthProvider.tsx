import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useAccount, useConnect, useDisconnect } from "wagmi";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";
import { formatUrl } from "@/lib/utils";

interface WalletAuthContextType {
  user: User | null;
  isLoading: boolean;
  isConnecting: boolean;
  isRegistering: boolean;
  walletAddress: string | null;
  walletConnected: boolean;
  connectWallet: () => void;
  disconnectWallet: () => void;
  registerWithWallet: (userData: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  checkWalletRegistration: (address: string) => Promise<boolean>;
}

interface RegisterData {
  username: string;
  displayName: string;
  bio?: string | null;
  avatar?: string | null;
}

const WalletAuthContext = createContext<WalletAuthContextType | null>(null);

// Internal provider that uses wagmi hooks
function WalletAuthProviderInternal({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isRegistering, setIsRegistering] = useState(false);
  
  const { address, isConnected, chainId } = useAccount();
  const { connect, connectors, isPending } = useConnect();
  const { disconnect } = useDisconnect();
  const { toast } = useToast();

  // Check session on initial load
  useEffect(() => {
    async function checkSession() {
      try {
        setIsLoading(true);
        const response = await fetch(formatUrl("/api/auth/session"));
        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error("Session check failed:", error);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    }
    
    checkSession();
  }, []);

  // Auto login with wallet when it connects
  useEffect(() => {
    if (isConnected && address && !user && !isLoading) {
      checkWalletRegistration(address)
        .then(isRegistered => {
          if (isRegistered) {
            // Wallet is registered, try to login
            tryWalletLogin(address);
          }
          // If not registered, user will need to complete registration
        })
        .catch(err => {
          console.error("Wallet check failed:", err);
        });
    }
  }, [isConnected, address, user, isLoading]);

  const connectWallet = () => {
    // Find an available connector (WalletConnect or injected)
    const connector = connectors.find(c => c.id === 'walletConnect') || 
                      connectors.find(c => c.id === 'injected');
    
    if (connector) {
      connect({ connector });
    } else {
      toast({
        variant: "destructive",
        title: "Connection Error",
        description: "No wallet connector found"
      });
    }
  };

  const disconnectWallet = () => {
    disconnect();
  };

  const checkWalletRegistration = async (address: string): Promise<boolean> => {
    try {
      const response = await fetch(formatUrl(`/api/wallet/${address}/exists`));
      if (!response.ok) {
        throw new Error("Failed to check wallet registration");
      }
      const data = await response.json();
      return data.exists;
    } catch (error) {
      console.error("Error checking wallet:", error);
      return false;
    }
  };

  const tryWalletLogin = async (walletAddress: string) => {
    try {
      const response = await apiRequest("POST", "/api/auth/wallet", {
        walletAddress,
        network: String(chainId || '1') // Convert chainId to string
      });
      
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
        
        toast({
          title: "Welcome back!",
          description: `You're logged in as ${userData.displayName || userData.username}`
        });
        
        return userData;
      }
      return null;
    } catch (error) {
      console.error("Wallet login failed:", error);
      return null;
    }
  };

  const registerWithWallet = async (userData: RegisterData) => {
    if (!address) {
      toast({
        variant: "destructive",
        title: "Wallet not connected",
        description: "Please connect your wallet first"
      });
      return;
    }
    
    setIsRegistering(true);
    try {
      const response = await apiRequest("POST", "/api/auth/wallet", {
        ...userData,
        walletAddress: address,
        network: String(chainId || '1') // Convert chainId to string
      });
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Registration failed");
      }
      
      const newUser = await response.json();
      setUser(newUser);
      
      toast({
        title: "Registration successful!",
        description: `Welcome to the platform, ${newUser.displayName}!`
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: error.message || "Could not complete registration"
      });
      throw error;
    } finally {
      setIsRegistering(false);
    }
  };

  const logout = async () => {
    try {
      const response = await apiRequest("POST", "/api/auth/logout");
      if (response.ok) {
        setUser(null);
        disconnectWallet();
        
        toast({
          title: "Logged out",
          description: "You have been logged out successfully"
        });
      } else {
        throw new Error("Logout failed");
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Logout failed",
        description: "There was an error logging out"
      });
    }
  };

  return (
    <WalletAuthContext.Provider
      value={{
        user,
        isLoading,
        isConnecting: isPending,
        isRegistering,
        walletAddress: address || null,
        walletConnected: isConnected,
        connectWallet,
        disconnectWallet,
        registerWithWallet,
        logout,
        checkWalletRegistration
      }}
    >
      {children}
    </WalletAuthContext.Provider>
  );
}

// Provider that uses wagmi hooks without extra wrapping
export function WagmiAuthProvider({ children }: { children: ReactNode }) {
  return (
    <WalletAuthProviderInternal>
      {children}
    </WalletAuthProviderInternal>
  );
}

export function useWalletAuth() {
  const context = useContext(WalletAuthContext);
  if (!context) {
    throw new Error("useWalletAuth must be used within a WagmiAuthProvider");
  }
  return context;
}