import { createContext, useContext, useEffect, useState, ReactNode } from "react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";
import { getCurrentWalletAddress } from "@/lib/web3";
import { dcsmEnforcerNew } from "@/lib/dcsmNetworkEnforcerNew";
import { getDefaultNetwork } from "@/lib/networks";

interface AuthContextType {
  user: User | null;
  isLoading: boolean;
  // Remove traditional login
  // login: (username: string, password: string) => Promise<void>; 
  registerWithWallet: (userData: WalletRegisterData) => Promise<void>;
  loginWithWallet: (walletAddress: string, network?: string) => Promise<User | null>;
  // Remove traditional register
  // register: (userData: RegisterData) => Promise<void>;
  logout: () => Promise<void>;
  updateUser: (user: User) => void;
  refreshUserData: () => Promise<User | null>;
  checkWalletRegistration: (walletAddress: string) => Promise<boolean>;
}

interface RegisterData {
  username: string;
  password: string;
  displayName: string;
  bio?: string | null;
  avatar?: string | null;
  walletAddress?: string | null;
  network?: string | null;
}

interface WalletRegisterData {
  username: string;
  displayName: string;
  bio?: string | null;
  avatar?: string | null;
  walletAddress: string;
  network: string;
}

interface ThemeProviderProps {
  children: ReactNode;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const { toast } = useToast();
  
  // Check authentication status on initial load and force DCSM network
  useEffect(() => {
    const checkAuthStatus = async () => {
      setIsLoading(true);
      try {
        // Check if wallet is connected but don't auto-switch network
        // Network switching should only happen when explicitly requested by user
        if (window.ethereum) {
          try {
            const accounts = await window.ethereum.request({ method: 'eth_accounts' });
            if (accounts && accounts.length > 0) {
              // Just check network status without forcing a switch
              const isCorrect = await dcsmEnforcerNew.isOnDCSMNetwork();
              console.log('Wallet connected, DCSM network status:', isCorrect);
            }
          } catch (error) {
            console.log('Network check on load failed:', error);
          }
        }

        const response = await fetch('/api/auth/session', {
          credentials: 'include'
        });
        
        if (response.ok) {
          const data = await response.json();
          if (data.authenticated && data.user) {
            setUser(data.user);
          } else {
            setUser(null);
          }
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error("Failed to check auth status:", error);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    };
    
    checkAuthStatus();
    
    // Set up an interval to periodically check auth status (every 5 minutes)
    const intervalId = setInterval(checkAuthStatus, 5 * 60 * 1000);
    
    return () => clearInterval(intervalId);
  }, []);

  // Function to refresh user data from the server
  const refreshUserData = async (): Promise<User | null> => {
    try {
      const response = await fetch("/api/auth/session", {
        credentials: "include",
      });
      
      if (response.ok) {
        const data = await response.json();
        if (data.authenticated && data.user) {
          setUser(data.user);
          return data.user;
        } else {
          // Session is not valid anymore
          setUser(null);
          return null;
        }
      } else {
        // Handle 401 or other error responses
        setUser(null);
        return null;
      }
    } catch (error) {
      console.error("Session check failed:", error);
      setUser(null);
      return null;
    } finally {
      setIsLoading(false);
    }
  };

  // Function to update user data in context
  const updateUser = (updatedUser: User) => {
    console.log("Updating user in context:", updatedUser);
    setUser(updatedUser);
  };

  useEffect(() => {
    // Only check authentication if we're not on auth pages
    const currentPath = window.location.pathname;
    const isAuthPage = currentPath === '/auth' || currentPath === '/login' || currentPath === '/register';
    
    if (!isAuthPage) {
      refreshUserData();
    } else {
      setIsLoading(false); // Set loading to false on auth pages
    }
  }, []);

  // Function to check if a wallet address is already registered
  const checkWalletRegistration = async (walletAddress: string): Promise<boolean> => {
    try {
      const response = await apiRequest("GET", `/api/wallet/${walletAddress}/exists`);
      if (response.ok) {
        const data = await response.json();
        return data.exists;
      }
      return false;
    } catch (error) {
      console.error("Error checking wallet registration:", error);
      return false;
    }
  };
  
  // Function to login with wallet - force DCSM Mainnet
  const loginWithWallet = async (walletAddress?: string, network?: string): Promise<User | null> => {
    try {
      console.log('=== LOGIN WITH WALLET STARTED ===');
      console.log('Proceeding with authentication (network checked at page level)...');
      
      // Get wallet address if not provided
      const finalWalletAddress = walletAddress || await getCurrentWalletAddress();
      if (!finalWalletAddress) {
        throw new Error("No wallet address available");
      }
      
      // Always use DCSM network
      const dcsmNetwork = getDefaultNetwork();
      
      // Check wallet balance before authentication
      let balance = "0";
      try {
        const { getWalletBalance } = await import("@/lib/web3");
        balance = await getWalletBalance(dcsmNetwork);
        console.log(`Wallet balance: ${balance} DCSM`);
        
        // Check minimum balance requirement
        if (parseFloat(balance) < 0.1) {
          toast({
            variant: "destructive",
            title: "Insufficient Balance",
            description: `You need at least 0.1 DCSM to use this platform. Current balance: ${balance} DCSM`,
          });
          return null;
        }
      } catch (error: any) {
        console.error("Balance check failed:", error);
        toast({
          variant: "destructive",
          title: "Balance Check Failed",
          description: "Unable to verify wallet balance. Please ensure you're connected to DCSM Mainnet.",
        });
        return null;
      }
      
      const response = await apiRequest("POST", "/api/auth/wallet", {
        walletAddress: finalWalletAddress,
        network: dcsmNetwork,
        balance: balance
      });
      
      if (response.ok) {
        const userData = await response.json();
        // Extract user data from the response structure
        const user = userData.user || userData;
        
        // Clear cache before setting new user to prevent old data from showing
        const { queryClient } = await import("@/lib/queryClient");
        queryClient.clear();
        
        setUser(user);
        
        toast({
          title: "Wallet Login Successful",
          description: `Welcome back, ${user.displayName}! Connected to DCSM Mainnet.`,
        });
        
        return user;
      }
      return null;
    } catch (error: any) {
      console.error("Wallet login failed:", error);
      
      // Check if it's an insufficient balance error from server
      if (error.message && error.message.includes("Insufficient balance")) {
        toast({
          variant: "destructive",
          title: "Insufficient Balance",
          description: error.message,
        });
      } else {
        toast({
          variant: "destructive",
          title: "Login Failed",
          description: error.message || "Failed to login with your wallet. Please ensure you're connected to DCSM Mainnet.",
        });
      }
      return null;
    }
  };

  const register = async (userData: RegisterData) => {
    try {
      const response = await apiRequest("POST", "/api/auth/register", userData);
      const newUser = await response.json();
      setUser(newUser);
      
      toast({
        title: "Registration successful",
        description: `Welcome to Micro, ${newUser.displayName}!`,
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: "Username may already be taken",
      });
      throw error;
    }
  };

  const logout = async () => {
    try {
      await apiRequest("POST", "/api/auth/logout", {});
      setUser(null);
      
      // Clear all React Query cache to prevent old data from showing
      const { queryClient } = await import("@/lib/queryClient");
      queryClient.clear();
      
      toast({
        title: "Logged out",
        description: "See you again soon!",
      });
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Logout failed",
        description: "An unexpected error occurred",
      });
      throw error;
    }
  };

  const registerWithWallet = async (userData: WalletRegisterData) => {
    try {
      console.log('=== WALLET REGISTRATION STARTED ===');
      console.log('Proceeding with registration (network checked at page level)...');
      
      // Check if wallet is already registered before attempting registration
      const isRegistered = await checkWalletRegistration(userData.walletAddress);
      if (isRegistered) {
        toast({
          variant: "destructive", 
          title: "Wallet Already Registered",
          description: "This wallet address is already associated with an account. Attempting login instead...",
        });
        
        // Automatically attempt login for registered wallet
        const loginResult = await loginWithWallet(userData.walletAddress);
        if (loginResult) {
          toast({
            title: "Logged In Successfully",
            description: "You have been logged in with your existing account.",
          });
        }
        return;
      }
      
      // Ensure we're using DCSM network
      const dcsmNetwork = getDefaultNetwork();
      
      // Check wallet balance before registration
      let balance = "0";
      try {
        const { getWalletBalance } = await import("@/lib/web3");
        balance = await getWalletBalance(dcsmNetwork);
        console.log(`Wallet balance: ${balance} DCSM`);
        
        // Check minimum balance requirement
        if (parseFloat(balance) < 0.1) {
          toast({
            variant: "destructive",
            title: "Insufficient Balance",
            description: `You need at least 0.1 DCSM to use this platform. Current balance: ${balance} DCSM`,
          });
          throw new Error(`Insufficient balance. You need at least 0.1 DCSM to use this platform. Current balance: ${balance} DCSM`);
        }
      } catch (error: any) {
        console.error("Balance check failed:", error);
        if (error.message.includes("Insufficient balance")) {
          throw error; // Re-throw balance errors
        }
        toast({
          variant: "destructive",
          title: "Balance Check Failed",
          description: "Unable to verify wallet balance. Please ensure you're connected to DCSM Mainnet.",
        });
        throw new Error("Unable to verify wallet balance. Please ensure you're connected to DCSM Mainnet.");
      }
      
      const finalUserData = {
        ...userData,
        network: dcsmNetwork,
        balance: balance
      };
      
      const response = await apiRequest("POST", "/api/auth/wallet", finalUserData);
      const responseData = await response.json();
      
      // Extract user data from the response structure
      const newUser = responseData.user || responseData;
      setUser(newUser);
      
      // Check if this was registration or login
      const isNewRegistration = responseData.registered === true;
      const message = isNewRegistration 
        ? `Welcome to Dc Social, ${newUser.displayName}! Your account has been created and you're now logged in.`
        : `Welcome back, ${newUser.displayName}! You've been logged in successfully.`;
      
      toast({
        title: isNewRegistration ? "Registration & Login Successful" : "Login Successful",
        description: message,
      });
    } catch (error: any) {
      // Check if it's an insufficient balance error from server
      if (error.message && error.message.includes("Insufficient balance")) {
        toast({
          variant: "destructive",
          title: "Insufficient Balance",
          description: error.message,
        });
      } else if (error.message && error.message.includes("Wallet already registered")) {
        // Don't show additional toast as we already showed one above
        return;
      } else if (error.message && error.message.includes("Wallet address already registered")) {
        // Server-side duplicate prevention caught this
        toast({
          variant: "destructive",
          title: "Wallet Already Registered",
          description: "This wallet address is already registered. Attempting login instead...",
        });
        
        // Automatically attempt login
        try {
          const loginResult = await loginWithWallet(userData.walletAddress);
          if (loginResult) {
            toast({
              title: "Logged In Successfully", 
              description: "You have been logged in with your existing account.",
            });
          }
        } catch (loginError) {
          console.error("Auto-login after duplicate detection failed:", loginError);
        }
        return;
      } else {
        toast({
          variant: "destructive",
          title: "Wallet registration failed",
          description: error.message || "An error occurred during wallet registration. Please ensure you're connected to DCSM Mainnet.",
        });
      }
      throw error;
    }
  };

  return (
    <AuthContext.Provider value={{ 
      user, 
      isLoading, 
      registerWithWallet,
      loginWithWallet,
      logout,
      updateUser,
      refreshUserData,
      checkWalletRegistration
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
}

// Material UI Dark Theme Provider
export function ThemeProvider({ children }: ThemeProviderProps) {
  return (
    <div className="min-h-screen bg-background font-roboto text-foreground">
      {children}
    </div>
  );
}
