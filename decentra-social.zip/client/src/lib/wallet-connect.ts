import { createConfig, http } from 'wagmi'
import { sepolia, mainnet } from 'wagmi/chains'
import { injected, walletConnect } from 'wagmi/connectors'

// Your WalletConnect project ID
export const projectId = '2eb44e7fff79353fc5dda881690c2968'

// Create a basic wagmi config with your project ID
export const wagmiConfig = createConfig({
  chains: [sepolia, mainnet],
  transports: {
    [sepolia.id]: http(),
    [mainnet.id]: http(),
  },
  connectors: [
    injected(),
    walletConnect({
      projectId,
      showQrModal: true,
      metadata: {
        name: 'Web3 Social Platform',
        description: 'Social media platform with Web3 wallet authentication',
        url: window?.location?.origin || 'https://replit.dev',
        icons: ['https://avatars.githubusercontent.com/u/37784886']
      }
    }),
  ],
})