import { createConfig, http } from 'wagmi'
import { sepolia, mainnet } from 'wagmi/chains'
import { injected, walletConnect } from 'wagmi/connectors'

// WalletConnect project ID - using the one you provided
export const projectId = '8137aad45a92f2eb9a42812ee05af00c'

// App metadata - using fixed URL to prevent origin mismatch errors
export const metadata = {
  name: 'Web3 Social Platform',
  description: 'A social media platform with Web3 wallet authentication',
  url: 'https://web3social.com', // Fixed domain for consistency
  icons: ['https://avatars.githubusercontent.com/u/37784886']
}

// Create Wagmi config
export const config = createConfig({
  chains: [sepolia, mainnet],
  transports: {
    [sepolia.id]: http(),
    [mainnet.id]: http(),
  },
  connectors: [
    injected(),
    walletConnect({
      projectId,
      metadata,
      showQrModal: true,
    }),
  ],
})