import { configureChains, createConfig } from '@wagmi/core'
import { sepolia, mainnet } from '@wagmi/core/chains'
import { formatUrl } from './utils'

// WalletConnect configuration
export const walletConnectProjectId = '8137aad45a92f2eb9a42812ee05af00c'

// Metadata for your application that shows in wallet UIs
export const projectMetadata = {
  name: import.meta.env.NEXT_PUBLIC_APP_NAME || 'Web3 Social Platform',
  description: 'A social media platform with Web3 wallet authentication',
  url: window.location.origin,
  icons: ['https://avatars.githubusercontent.com/u/37784886']
}

// Supported chains 
export const chains = [sepolia, mainnet]

// Web3Modal and Wagmi configuration
export const getWeb3Config = () => {
  return {
    projectId: walletConnectProjectId,
    chains,
    metadata: projectMetadata,
  }
}