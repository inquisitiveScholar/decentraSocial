// DCSM Network Configuration
const DCSM_NETWORK = {
  chainId: '0x4b18', // 19224 in hex
  chainName: 'DCSM Mainnet',
  nativeCurrency: {
    name: 'DCSM',
    symbol: 'DCSM',
    decimals: 18,
  },
  rpcUrls: ['https://rpc.decentraconnect.io'],
  blockExplorerUrls: ['https://explorer.decentraconnect.io'],
};

declare global {
  interface Window {
    ethereum?: {
      request: (args: { method: string; params?: any[] }) => Promise<any>;
      on: (event: string, callback: (...args: any[]) => void) => void;
      removeListener: (event: string, callback: (...args: any[]) => void) => void;
    };
  }
}

export class DCSMNetworkEnforcerNew {
  private static instance: DCSMNetworkEnforcerNew;
  private callbacks: Set<(isCorrectNetwork: boolean) => void> = new Set();
  private switchInProgress = false;

  static getInstance(): DCSMNetworkEnforcerNew {
    if (!DCSMNetworkEnforcerNew.instance) {
      DCSMNetworkEnforcerNew.instance = new DCSMNetworkEnforcerNew();
    }
    return DCSMNetworkEnforcerNew.instance;
  }

  // Check if current network is DCSM
  async isOnDCSMNetwork(): Promise<boolean> {
    if (!window.ethereum) return false;
    
    try {
      const currentChainId = await window.ethereum.request({ method: 'eth_chainId' });
      return currentChainId.toLowerCase() === DCSM_NETWORK.chainId.toLowerCase();
    } catch (error) {
      console.error('Error checking network:', error);
      return false;
    }
  }

  // Manual network switch - only when explicitly called
  async switchToDCSMManual(): Promise<boolean> {
    if (!window.ethereum) {
      throw new Error('No wallet detected');
    }

    if (this.switchInProgress) {
      console.log('Network switch already in progress');
      return false;
    }

    this.switchInProgress = true;
    console.log('Manual switch to DCSM network initiated...');

    try {
      // Check if already on DCSM
      const isAlreadyOnDCSM = await this.isOnDCSMNetwork();
      if (isAlreadyOnDCSM) {
        console.log('Already on DCSM network');
        return true;
      }

      // Add network first (in case it doesn't exist)
      try {
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [DCSM_NETWORK],
        });
        console.log('DCSM network added successfully');
      } catch (addError: any) {
        // Network might already exist, continue with switch
        if (addError.code !== 4001) { // Ignore user rejection for add
          console.log('Network might already exist, continuing...');
        }
      }

      // Switch to DCSM network
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: DCSM_NETWORK.chainId }],
      });

      // Verify switch success
      await new Promise(resolve => setTimeout(resolve, 1000));
      const switchSuccess = await this.isOnDCSMNetwork();
      
      if (switchSuccess) {
        console.log('Successfully switched to DCSM network');
        this.notifyCallbacks(true);
        return true;
      } else {
        console.error('Switch verification failed');
        return false;
      }
    } catch (error: any) {
      console.error('Network switch failed:', error);
      
      if (error.code === 4001) {
        throw new Error('User rejected network switch to DCSM Mainnet');
      }
      
      throw new Error('Failed to switch to DCSM Mainnet');
    } finally {
      this.switchInProgress = false;
    }
  }

  // Enforce DCSM network for wallet connection - with blocking
  async enforceForWalletConnection(): Promise<boolean> {
    console.log('=== DCSM Network Enforcement Started ===');
    
    try {
      // Check current network
      const isCurrentlyOnDCSM = await this.isOnDCSMNetwork();
      console.log('Current network is DCSM:', isCurrentlyOnDCSM);
      
      if (isCurrentlyOnDCSM) {
        console.log('Already on DCSM network, proceeding...');
        return true;
      }
      
      // Not on DCSM - attempt manual switch
      console.log('Wrong network detected, initiating manual switch...');
      const switchResult = await this.switchToDCSMManual();
      
      if (!switchResult) {
        throw new Error('Failed to switch to DCSM Mainnet');
      }
      
      // Final verification
      await new Promise(resolve => setTimeout(resolve, 2000));
      const finalCheck = await this.isOnDCSMNetwork();
      console.log('Final verification - on DCSM:', finalCheck);
      
      if (!finalCheck) {
        throw new Error('Network verification failed after switch');
      }
      
      console.log('=== Network Enforcement Successful ===');
      return true;
    } catch (error) {
      console.error('=== Network Enforcement Failed ===', error);
      throw error;
    }
  }

  // Simple network monitoring - no automatic switching
  setupNetworkMonitoring(): void {
    if (!window.ethereum) return;

    const handleChainChanged = (chainId: string) => {
      console.log('Network changed to:', chainId);
      const isCorrect = chainId.toLowerCase() === DCSM_NETWORK.chainId.toLowerCase();
      this.notifyCallbacks(isCorrect);
      
      if (isCorrect) {
        console.log('User switched to DCSM network');
      } else {
        console.log('User switched away from DCSM network');
      }
    };

    window.ethereum.on('chainChanged', handleChainChanged);
  }

  // Callback management
  onNetworkChange(callback: (isCorrectNetwork: boolean) => void): () => void {
    this.callbacks.add(callback);
    return () => this.callbacks.delete(callback);
  }

  private notifyCallbacks(isCorrectNetwork: boolean): void {
    this.callbacks.forEach(callback => {
      try {
        callback(isCorrectNetwork);
      } catch (error) {
        console.error('Network callback error:', error);
      }
    });
  }

  // Initialize
  async initialize(): Promise<void> {
    this.setupNetworkMonitoring();
    console.log('DCSM Network Enforcer initialized (manual mode)');
  }
}

// Export singleton instance
export const dcsmEnforcerNew = DCSMNetworkEnforcerNew.getInstance();