import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Plus, Trash2, Settings } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import { getAllNetworks, addCustomNetwork, removeCustomNetwork, type NetworkConfig } from "@/lib/networks";

interface NetworkManagementProps {
  currentNetwork: string;
  onNetworkChange: (network: string) => void;
}

export default function NetworkManagement({ currentNetwork, onNetworkChange }: NetworkManagementProps) {
  const { toast } = useToast();
  const [isOpen, setIsOpen] = useState(false);
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [networks, setNetworks] = useState(getAllNetworks());
  
  // Form states for adding custom network
  const [networkId, setNetworkId] = useState("");
  const [networkName, setNetworkName] = useState("");
  const [chainId, setChainId] = useState("");
  const [currency, setCurrency] = useState("");
  const [symbol, setSymbol] = useState("");
  const [rpcUrl, setRpcUrl] = useState("");
  const [blockExplorer, setBlockExplorer] = useState("");
  const [decimals, setDecimals] = useState("18");

  const resetForm = () => {
    setNetworkId("");
    setNetworkName("");
    setChainId("");
    setCurrency("");
    setSymbol("");
    setRpcUrl("");
    setBlockExplorer("");
    setDecimals("18");
  };

  const handleAddNetwork = () => {
    if (!networkId || !networkName || !chainId || !currency || !symbol || !rpcUrl || !blockExplorer) {
      toast({
        title: "Missing Information",
        description: "Please fill in all required fields",
        variant: "destructive"
      });
      return;
    }

    // Validate chain ID format (should be hex)
    if (!chainId.startsWith("0x")) {
      toast({
        title: "Invalid Chain ID",
        description: "Chain ID must be in hexadecimal format (e.g., 0x1)",
        variant: "destructive"
      });
      return;
    }

    const networkConfig: NetworkConfig = {
      chainId,
      name: networkName,
      currency,
      symbol,
      rpcUrl,
      blockExplorer,
      decimals: parseInt(decimals) || 18
    };

    const success = addCustomNetwork(networkId, networkConfig);
    
    if (success) {
      setNetworks(getAllNetworks());
      resetForm();
      setIsAddDialogOpen(false);
      toast({
        title: "Network Added",
        description: `Successfully added ${networkName} network`,
      });
    } else {
      toast({
        title: "Error",
        description: "Failed to add custom network",
        variant: "destructive"
      });
    }
  };

  const handleRemoveNetwork = (networkId: string) => {
    const success = removeCustomNetwork(networkId);
    
    if (success) {
      setNetworks(getAllNetworks());
      
      // If the removed network was selected, switch to default
      if (currentNetwork === networkId) {
        onNetworkChange("ethereum");
      }
      
      toast({
        title: "Network Removed",
        description: "Custom network has been removed",
      });
    } else {
      toast({
        title: "Error",
        description: "Failed to remove custom network",
        variant: "destructive"
      });
    }
  };

  const defaultNetworks = ["ethereum", "bsc", "polygon"];
  const customNetworkIds = Object.keys(networks).filter(id => !defaultNetworks.includes(id));

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm" className="gap-2">
          <Settings className="h-4 w-4" />
          Manage Networks
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[500px] bg-[#0d1421] border-[#1a2747]">
        <DialogHeader>
          <DialogTitle className="text-white">Network Management</DialogTitle>
          <DialogDescription className="text-gray-400">
            Manage supported blockchain networks for wallet connections and transactions.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          {/* Current Network Selection */}
          <div className="space-y-2">
            <Label className="text-white">Current Network</Label>
            <Select value={currentNetwork} onValueChange={onNetworkChange}>
              <SelectTrigger className="bg-[#1a2747] border-[#2a3f5f] text-white">
                <SelectValue />
              </SelectTrigger>
              <SelectContent className="bg-[#1a2747] border-[#2a3f5f]">
                {Object.entries(networks).map(([id, config]) => (
                  <SelectItem key={id} value={id} className="text-white hover:bg-[#2a3f5f]">
                    {config.name} ({config.symbol})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Custom Networks List */}
          {customNetworkIds.length > 0 && (
            <div className="space-y-2">
              <Label className="text-white">Custom Networks</Label>
              <div className="space-y-2 max-h-32 overflow-y-auto">
                {customNetworkIds.map((networkId) => (
                  <div key={networkId} className="flex items-center justify-between p-2 bg-[#1a2747] rounded">
                    <span className="text-white text-sm">{networks[networkId].name}</span>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleRemoveNetwork(networkId)}
                      className="text-red-400 hover:text-red-300 hover:bg-red-500/10"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Add Custom Network */}
          <div className="pt-2 border-t border-[#2a3f5f]">
            <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" className="w-full gap-2 border-[#2a3f5f] text-white hover:bg-[#1a2747]">
                  <Plus className="h-4 w-4" />
                  Add Custom Network
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-[600px] bg-[#0d1421] border-[#1a2747]">
                <DialogHeader>
                  <DialogTitle className="text-white">Add Custom Network</DialogTitle>
                  <DialogDescription className="text-gray-400">
                    Enter the details for your custom blockchain network.
                  </DialogDescription>
                </DialogHeader>

                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label className="text-white">Network ID *</Label>
                    <Input
                      value={networkId}
                      onChange={(e) => setNetworkId(e.target.value)}
                      placeholder="e.g., arbitrum"
                      className="bg-[#1a2747] border-[#2a3f5f] text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white">Network Name *</Label>
                    <Input
                      value={networkName}
                      onChange={(e) => setNetworkName(e.target.value)}
                      placeholder="e.g., Arbitrum One"
                      className="bg-[#1a2747] border-[#2a3f5f] text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white">Chain ID *</Label>
                    <Input
                      value={chainId}
                      onChange={(e) => setChainId(e.target.value)}
                      placeholder="e.g., 0xa4b1"
                      className="bg-[#1a2747] border-[#2a3f5f] text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white">Currency *</Label>
                    <Input
                      value={currency}
                      onChange={(e) => setCurrency(e.target.value)}
                      placeholder="e.g., Ethereum"
                      className="bg-[#1a2747] border-[#2a3f5f] text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white">Symbol *</Label>
                    <Input
                      value={symbol}
                      onChange={(e) => setSymbol(e.target.value)}
                      placeholder="e.g., ETH"
                      className="bg-[#1a2747] border-[#2a3f5f] text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label className="text-white">Decimals</Label>
                    <Input
                      value={decimals}
                      onChange={(e) => setDecimals(e.target.value)}
                      placeholder="18"
                      type="number"
                      className="bg-[#1a2747] border-[#2a3f5f] text-white"
                    />
                  </div>
                  <div className="col-span-2 space-y-2">
                    <Label className="text-white">RPC URL *</Label>
                    <Input
                      value={rpcUrl}
                      onChange={(e) => setRpcUrl(e.target.value)}
                      placeholder="e.g., https://arb1.arbitrum.io/rpc"
                      className="bg-[#1a2747] border-[#2a3f5f] text-white"
                    />
                  </div>
                  <div className="col-span-2 space-y-2">
                    <Label className="text-white">Block Explorer *</Label>
                    <Input
                      value={blockExplorer}
                      onChange={(e) => setBlockExplorer(e.target.value)}
                      placeholder="e.g., https://arbiscan.io"
                      className="bg-[#1a2747] border-[#2a3f5f] text-white"
                    />
                  </div>
                </div>

                <DialogFooter>
                  <Button
                    variant="outline"
                    onClick={() => {
                      resetForm();
                      setIsAddDialogOpen(false);
                    }}
                    className="border-[#2a3f5f] text-white hover:bg-[#1a2747]"
                  >
                    Cancel
                  </Button>
                  <Button onClick={handleAddNetwork} className="bg-blue-600 hover:bg-blue-700">
                    Add Network
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        <DialogFooter>
          <Button onClick={() => setIsOpen(false)} className="bg-gray-600 hover:bg-gray-700">
            Close
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}