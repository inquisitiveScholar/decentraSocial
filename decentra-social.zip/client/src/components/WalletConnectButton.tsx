import React, { useState, useEffect } from 'react';
import { Button } from './ui/button';
import { useAuth } from '@/context/AuthContext';
import { useToast } from '@/hooks/use-toast';
import { ethers } from 'ethers';

// Make TypeScript happy with window.ethereum
interface Ethereum {
  request: (args: { method: string; params?: any[] }) => Promise<any>;
  on: (event: string, callback: (...args: any[]) => void) => void;
  removeListener: (event: string, callback: (...args: any[]) => void) => void;
  isMetaMask?: boolean;
}

declare global {
  interface Window {
    ethereum?: Ethereum;
  }
}

const WalletConnectButton = () => {
  const { toast } = useToast();
  const [address, setAddress] = useState<string | null>(null);
  const [isConnecting, setIsConnecting] = useState(false);
  const [chainId, setChainId] = useState<string | null>(null);
  const { checkWalletRegistration } = useAuth();

  useEffect(() => {
    // Check if user already has wallet connected
    const checkConnection = async () => {
      if (window.ethereum) {
        try {
          const accounts = await window.ethereum.request({ method: 'eth_accounts' });
          
          if (accounts && accounts.length > 0) {
            setAddress(accounts[0]);
            
            // Get network
            const chainIdHex = await window.ethereum.request({ method: 'eth_chainId' });
            setChainId(chainIdHex);
          }
        } catch (error) {
          console.error('Error checking wallet connection:', error);
        }
      }
    };
    
    checkConnection();
    
    // Set up event listeners
    const handleAccountsChanged = (accounts: string[]) => {
      if (accounts.length === 0) {
        // User disconnected their wallet
        setAddress(null);
        toast({
          title: "Wallet disconnected",
          description: "Your wallet has been disconnected."
        });
      } else {
        // User switched accounts
        setAddress(accounts[0]);
      }
    };
    
    const handleChainChanged = (chainIdHex: string) => {
      setChainId(chainIdHex);
      // Reload the page when they change networks
      window.location.reload();
    };
    
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', handleChainChanged);
    }
    
    // Cleanup
    return () => {
      if (window.ethereum) {
        window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
        window.ethereum.removeListener('chainChanged', handleChainChanged);
      }
    };
  }, [toast]);

  const connectWallet = async () => {
    setIsConnecting(true);
    try {
      if (window.ethereum) {
        // Request accounts from MetaMask
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        
        if (accounts && accounts.length > 0) {
          const walletAddress = accounts[0];
          setAddress(walletAddress);
          
          // Get network information
          const chainIdHex = await window.ethereum.request({ method: 'eth_chainId' });
          setChainId(chainIdHex);
          
          // Check if this wallet is already registered
          const isRegistered = await checkWalletRegistration(walletAddress);
          
          if (isRegistered) {
            toast({
              title: "Wallet connected!",
              description: "This wallet is already registered with an account.",
            });
          } else {
            toast({
              title: "Wallet connected!",
              description: "Please register to continue.",
              variant: "default",
            });
            // You could redirect to registration page here
          }
        }
      } else {
        toast({
          title: "No Ethereum wallet found",
          description: "Please install MetaMask or another Ethereum wallet.",
          variant: "destructive",
        });
      }
    } catch (error) {
      console.error('Error connecting wallet:', error);
      toast({
        title: "Connection Failed",
        description: "Failed to connect to wallet. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const disconnectWallet = () => {
    setAddress(null);
    toast({
      title: "Wallet disconnected",
      description: "Your wallet has been disconnected.",
    });
  };

  // Helper function to display the network name
  const getNetworkName = () => {
    if (!chainId) return "Unknown Network";

    const networks: Record<string, string> = {
      "0x1": "Ethereum Mainnet",
      "0x3": "Ropsten Testnet",
      "0x4": "Rinkeby Testnet",
      "0x5": "Goerli Testnet",
      "0xaa36a7": "Sepolia Testnet",
      "0x89": "Polygon Mainnet",
      "0x13881": "Mumbai Testnet",
    };

    return networks[chainId] || `Chain ID: ${chainId}`;
  };

  return (
    <div className="flex flex-col space-y-2">
      {address ? (
        <div className="flex flex-col items-center space-y-2">
          <div className="text-sm font-medium">
            <span className="text-muted-foreground">Connected: </span>
            <span className="text-foreground">{address.slice(0, 6)}...{address.slice(-4)}</span>
          </div>
          <div className="text-xs text-muted-foreground">
            {getNetworkName()}
          </div>
          <Button variant="outline" size="sm" onClick={disconnectWallet}>
            Disconnect
          </Button>
        </div>
      ) : (
        <Button 
          onClick={connectWallet} 
          disabled={isConnecting}
          className="bg-primary text-white hover:bg-primary/90"
        >
          {isConnecting ? "Connecting..." : "Connect Wallet"}
        </Button>
      )}
    </div>
  );
};

export default WalletConnectButton;