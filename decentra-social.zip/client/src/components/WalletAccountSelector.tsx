import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Wallet, Check, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface WalletAccount {
  address: string;
  balance: string;
  isRegistered: boolean;
}

interface WalletAccountSelectorProps {
  onAccountSelect: (address: string) => void;
  selectedAccount?: string;
  isConnected: boolean;
}

export default function WalletAccountSelector({ 
  onAccountSelect, 
  selectedAccount, 
  isConnected 
}: WalletAccountSelectorProps) {
  const [accounts, setAccounts] = useState<WalletAccount[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const getWalletAccounts = async () => {
    if (!window.ethereum || !isConnected) return;

    setIsLoading(true);
    try {
      // Request all accounts from wallet
      const allAccounts = await window.ethereum.request({
        method: 'eth_accounts'
      });

      const accountsWithData: WalletAccount[] = [];

      for (const address of allAccounts) {
        try {
          // Get balance for each account
          const balanceWei = await window.ethereum.request({
            method: 'eth_getBalance',
            params: [address, 'latest']
          });
          
          // Convert Wei to DCSM (assuming 18 decimals)
          const balanceEth = parseInt(balanceWei, 16) / Math.pow(10, 18);
          const balance = balanceEth.toFixed(6);

          // Check if account is already registered
          const response = await fetch(`/api/wallet/${address}/exists`);
          const { exists } = await response.json();

          accountsWithData.push({
            address,
            balance,
            isRegistered: exists
          });
        } catch (error) {
          console.error(`Error getting data for account ${address}:`, error);
          // Add account even if we can't get balance
          accountsWithData.push({
            address,
            balance: "0.000000",
            isRegistered: false
          });
        }
      }

      setAccounts(accountsWithData);
      
      // If no account is selected, select the first one
      if (!selectedAccount && accountsWithData.length > 0) {
        onAccountSelect(accountsWithData[0].address);
      }
    } catch (error) {
      console.error("Error fetching wallet accounts:", error);
      toast({
        variant: "destructive",
        title: "Account Fetch Failed",
        description: "Unable to retrieve wallet accounts. Please try again."
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isConnected) {
      getWalletAccounts();
    }
  }, [isConnected]);

  const handleRefresh = () => {
    getWalletAccounts();
  };

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  if (!isConnected) {
    return (
      <Card className="w-full">
        <CardContent className="pt-6">
          <div className="text-center">
            <Wallet className="h-8 w-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">Connect your wallet to view accounts</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-lg">Select Wallet Account</CardTitle>
        <Button
          variant="outline"
          size="sm"
          onClick={handleRefresh}
          disabled={isLoading}
          className="h-8 w-8 p-0"
        >
          <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
        </Button>
      </CardHeader>
      <CardContent className="space-y-3">
        {isLoading ? (
          <div className="text-center py-4">
            <div className="animate-spin h-6 w-6 border-2 border-t-transparent border-primary rounded-full mx-auto mb-2"></div>
            <p className="text-sm text-muted-foreground">Loading accounts...</p>
          </div>
        ) : accounts.length === 0 ? (
          <div className="text-center py-4">
            <p className="text-sm text-muted-foreground">No accounts found</p>
          </div>
        ) : (
          accounts.map((account, index) => (
            <div
              key={account.address}
              className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                selectedAccount === account.address
                  ? 'border-primary bg-primary/10'
                  : 'border-border hover:border-primary/50'
              }`}
              onClick={() => onAccountSelect(account.address)}
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Avatar className="h-8 w-8">
                    <AvatarImage src={`https://api.dicebear.com/7.x/identicon/svg?seed=${account.address}`} />
                    <AvatarFallback>
                      {account.address.slice(2, 4).toUpperCase()}
                    </AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="flex items-center space-x-2">
                      <span className="font-medium text-sm">
                        Account {index + 1}
                      </span>
                      {account.isRegistered && (
                        <Badge variant="secondary" className="text-xs">
                          Registered
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {formatAddress(account.address)}
                    </p>
                    <p className="text-xs text-muted-foreground">
                      {account.balance} DCSM
                    </p>
                  </div>
                </div>
                {selectedAccount === account.address && (
                  <Check className="h-4 w-4 text-primary" />
                )}
              </div>
              
              {parseFloat(account.balance) < 0.1 && (
                <div className="mt-2 p-2 bg-yellow-500/10 border border-yellow-500/20 rounded text-xs text-yellow-600">
                  <div className="p-2 bg-red-500/10 border border-red-500/20 rounded-md">
                  <div className="flex items-start space-x-2">
                    <svg className="h-3 w-3 text-red-400 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                    <div className="flex-1 min-w-0">
                      <p className="text-xs text-red-300 font-medium">Insufficient Balance</p>
                      <p className="text-xs text-red-200 mb-1">Minimum 0.1 DCSM required</p>
                      <a 
                        href="https://dcsocial.org/swap.html" 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="inline-flex items-center px-2 py-1 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded transition-colors duration-200"
                      >
                        <svg className="w-2.5 h-2.5 mr-1" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                        </svg>
                        Get DCSM Coins
                      </a>
                    </div>
                  </div>
                </div>
                </div>
              )}
            </div>
          ))
        )}
        
        {accounts.length > 0 && (
          <div className="pt-2 border-t border-border">
            <p className="text-xs text-muted-foreground text-center">
              Select an account to continue with authentication
            </p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

// Window ethereum interface is already declared in MetaMaskButton.tsx