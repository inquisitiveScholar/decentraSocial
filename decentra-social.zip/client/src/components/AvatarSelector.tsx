import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { User } from "lucide-react";

// Import all DC avatar images
import dcAvatar1 from "@assets/DC_avtar1_1749581137967.png";
import dcAvatar2 from "@assets/DC_avtar2_1749581137970.png";
import dcAvatar3 from "@assets/DC_avtar3_1749581137970.png";
import dcAvatar4 from "@assets/DC_avtar4_1749581137970.png";
import dcAvatar5 from "@assets/DC_avtar5_1749581137970.png";
import dcAvatar6 from "@assets/DC_avtar6_1749581137970.png";
import dcAvatar7 from "@assets/DC_avtar7_1749581137970.png";
import dcAvatar8 from "@assets/DC_avtar8_1749581137970.png";
import dcAvatar9 from "@assets/DC_avtar9_1749581137969.png";
import dcAvatar10 from "@assets/DC_avtar10_1749581137969.png";
import dcAvatar11 from "@assets/DC_avtar11_1749581137969.png";
import dcAvatar12 from "@assets/DC_avtar12_1749581137969.png";
import dcAvatar13 from "@assets/DC_avtar13_1749581137969.png";
import dcAvatar14 from "@assets/DC_avtar14_1749581137968.png";

const avatarOptions = [
  { id: "dc_avatar_1", src: dcAvatar1, name: "DC Avatar 1" },
  { id: "dc_avatar_2", src: dcAvatar2, name: "DC Avatar 2" },
  { id: "dc_avatar_3", src: dcAvatar3, name: "DC Avatar 3" },
  { id: "dc_avatar_4", src: dcAvatar4, name: "DC Avatar 4" },
  { id: "dc_avatar_5", src: dcAvatar5, name: "DC Avatar 5" },
  { id: "dc_avatar_6", src: dcAvatar6, name: "DC Avatar 6" },
  { id: "dc_avatar_7", src: dcAvatar7, name: "DC Avatar 7" },
  { id: "dc_avatar_8", src: dcAvatar8, name: "DC Avatar 8" },
  { id: "dc_avatar_9", src: dcAvatar9, name: "DC Avatar 9" },
  { id: "dc_avatar_10", src: dcAvatar10, name: "DC Avatar 10" },
  { id: "dc_avatar_11", src: dcAvatar11, name: "DC Avatar 11" },
  { id: "dc_avatar_12", src: dcAvatar12, name: "DC Avatar 12" },
  { id: "dc_avatar_13", src: dcAvatar13, name: "DC Avatar 13" },
  { id: "dc_avatar_14", src: dcAvatar14, name: "DC Avatar 14" },
];

interface AvatarSelectorProps {
  currentAvatar?: string;
  onSelect: (avatarId: string, avatarSrc: string) => void;
  trigger?: React.ReactNode;
}

export default function AvatarSelector({ currentAvatar, onSelect, trigger }: AvatarSelectorProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [selectedAvatar, setSelectedAvatar] = useState(currentAvatar || "");

  const handleSelect = (avatarId: string, avatarSrc: string) => {
    setSelectedAvatar(avatarId);
    onSelect(avatarId, avatarSrc);
    setIsOpen(false);
  };

  const getCurrentAvatarSrc = () => {
    const current = avatarOptions.find(avatar => avatar.id === currentAvatar);
    return current?.src || "";
  };

  const defaultTrigger = (
    <Button variant="outline" className="w-full">
      <Avatar className="w-8 h-8 mr-2">
        <AvatarImage src={getCurrentAvatarSrc()} alt="Current avatar" />
        <AvatarFallback>
          <User className="w-4 h-4" />
        </AvatarFallback>
      </Avatar>
      {currentAvatar ? "Change Avatar" : "Select Avatar"}
    </Button>
  );

  return (
    <Dialog open={isOpen} onOpenChange={setIsOpen}>
      <DialogTrigger asChild>
        {trigger || defaultTrigger}
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Choose Your DC Avatar</DialogTitle>
        </DialogHeader>
        <div className="grid grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4 p-4">
          {avatarOptions.map((avatar) => (
            <button
              key={avatar.id}
              onClick={() => handleSelect(avatar.id, avatar.src)}
              className={`relative p-2 rounded-lg border-2 transition-all hover:scale-105 ${
                selectedAvatar === avatar.id || currentAvatar === avatar.id
                  ? "border-blue-500 bg-blue-50 dark:bg-blue-950"
                  : "border-gray-200 dark:border-gray-700 hover:border-gray-300 dark:hover:border-gray-600"
              }`}
            >
              <Avatar className="w-16 h-16 mx-auto">
                <AvatarImage src={avatar.src} alt={avatar.name} />
                <AvatarFallback>
                  <User className="w-8 h-8" />
                </AvatarFallback>
              </Avatar>
              <p className="text-xs mt-2 text-center truncate">{avatar.name}</p>
            </button>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}

// Export function to get avatar source by ID
export function getAvatarSrc(avatarId: string): string {
  const avatar = avatarOptions.find(a => a.id === avatarId);
  return avatar?.src || "";
}

// Export all avatar options for other components
export { avatarOptions };