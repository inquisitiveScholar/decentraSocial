import { useEffect, useState } from 'react';
import { useToast } from '@/hooks/use-toast';
import { dcsmEnforcer } from '@/lib/dcsmNetworkEnforcer';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { AlertTriangle, CheckCircle, Wifi, WifiOff } from 'lucide-react';

export default function NetworkEnforcer() {
  const [isCorrectNetwork, setIsCorrectNetwork] = useState<boolean | null>(null);
  const [isEnforcing, setIsEnforcing] = useState(false);
  const [isWalletConnected, setIsWalletConnected] = useState(false);
  const { toast } = useToast();

  const handleSwitchNetwork = async () => {
    if (isEnforcing) return;
    
    setIsEnforcing(true);
    try {
      const success = await dcsmEnforcer.switchToDCSM();
      if (success) {
        toast({
          title: "Network Switched",
          description: "Successfully connected to DCSM Mainnet",
        });
        setIsCorrectNetwork(true);
      } else {
        toast({
          title: "Switch Failed",
          description: "Please manually switch to DCSM Mainnet in your wallet",
          variant: "destructive",
        });
      }
    } catch (error: any) {
      console.error('Network switch error:', error);
      toast({
        title: "Switch Failed",
        description: error.message || "Please manually switch to DCSM Mainnet in your wallet",
        variant: "destructive",
      });
    } finally {
      setIsEnforcing(false);
    }
  };

  useEffect(() => {
    // Initialize DCSM network enforcement
    dcsmEnforcer.initialize();

    // Set up network status callback
    const handleNetworkChange = (isCorrect: boolean) => {
      console.log('DCSM Network status changed:', isCorrect);
      setIsCorrectNetwork(isCorrect);
      
      if (!isCorrect && isWalletConnected) {
        toast({
          title: "Wrong Network Detected",
          description: "Please switch to DCSM Mainnet to continue",
          variant: "destructive",
        });
      }
    };

    dcsmEnforcer.onNetworkChange(handleNetworkChange);

    // Check wallet connection status
    const checkWalletConnection = async () => {
      if (window.ethereum) {
        try {
          const accounts = await window.ethereum.request({ method: 'eth_accounts' });
          const connected = accounts && accounts.length > 0;
          setIsWalletConnected(connected);
          
          if (connected) {
            const isCorrect = await dcsmEnforcer.isOnDCSMNetwork();
            setIsCorrectNetwork(isCorrect);
          }
        } catch (error) {
          console.error('Failed to check wallet connection:', error);
          setIsWalletConnected(false);
        }
      }
    };

    checkWalletConnection();

    return () => {
      dcsmEnforcer.removeCallback(handleNetworkChange);
    };
  }, [toast, isWalletConnected]);

  // Don't show anything if wallet is not connected
  if (!isWalletConnected || !window.ethereum) return null;

  // Show warning for wrong network
  if (isCorrectNetwork === false) {
    return (
      <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-md px-4">
        <Alert className="bg-red-900/95 border-red-500 text-white backdrop-blur-sm shadow-lg">
          <WifiOff className="h-4 w-4" />
          <AlertDescription className="flex items-center justify-between">
            <span className="font-medium">Wrong network! Switch to DCSM Mainnet</span>
            <Button
              size="sm"
              onClick={handleSwitchNetwork}
              disabled={isEnforcing}
              className="ml-2 bg-red-600 hover:bg-red-700 text-white"
            >
              {isEnforcing ? "Switching..." : "Switch Now"}
            </Button>
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Show success for correct network
  if (isCorrectNetwork === true) {
    return (
      <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-md px-4">
        <Alert className="bg-green-900/95 border-green-500 text-white backdrop-blur-sm shadow-lg">
          <Wifi className="h-4 w-4" />
          <AlertDescription className="font-medium">
            Connected to DCSM Mainnet
          </AlertDescription>
        </Alert>
      </div>
    );
  }

  // Show loading state
  return (
    <div className="fixed top-20 left-1/2 transform -translate-x-1/2 z-50 w-full max-w-md px-4">
      <Alert className="bg-blue-900/95 border-blue-500 text-white backdrop-blur-sm shadow-lg">
        <CheckCircle className="h-4 w-4 animate-pulse" />
        <AlertDescription className="font-medium">
          Checking network connection...
        </AlertDescription>
      </Alert>
    </div>
  );
}