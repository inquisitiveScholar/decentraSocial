import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

import { Badge } from "@/components/ui/badge";
import { Wallet, RefreshCw } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface WalletAccountSwitcherProps {
  onAccountChange: (address: string) => void;
  currentAddress?: string;
  isConnected: boolean;
}

export default function WalletAccountSwitcher({ 
  onAccountChange, 
  currentAddress, 
  isConnected 
}: WalletAccountSwitcherProps) {
  const [accounts, setAccounts] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [balances, setBalances] = useState<Record<string, string>>({});
  const { toast } = useToast();

  const fetchWalletAccounts = async () => {
    if (!window.ethereum || !isConnected) return;

    setIsLoading(true);
    try {
      // Request all accounts from wallet
      const allAccounts = await window.ethereum.request({
        method: 'eth_accounts'
      });

      setAccounts(allAccounts);

      // Fetch balances for each account
      const balancePromises = allAccounts.map(async (address: string) => {
        try {
          const balanceWei = await window.ethereum!.request({
            method: 'eth_getBalance',
            params: [address, 'latest']
          });
          
          const balanceEth = parseInt(balanceWei, 16) / Math.pow(10, 18);
          return { address, balance: balanceEth.toFixed(6) };
        } catch (error) {
          console.error(`Error getting balance for ${address}:`, error);
          return { address, balance: "0.000000" };
        }
      });

      const balanceResults = await Promise.all(balancePromises);
      const balanceMap: Record<string, string> = {};
      balanceResults.forEach(({ address, balance }) => {
        balanceMap[address] = balance;
      });
      setBalances(balanceMap);

      // If no current address is set, use the first account
      if (!currentAddress && allAccounts.length > 0) {
        onAccountChange(allAccounts[0]);
      }
    } catch (error) {
      console.error("Error fetching wallet accounts:", error);
      toast({
        variant: "destructive",
        title: "Account Fetch Failed",
        description: "Unable to retrieve wallet accounts."
      });
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isConnected) {
      fetchWalletAccounts();
    }
  }, [isConnected]);

  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const switchToAccount = async (address: string) => {
    try {
      // Request to switch to the selected account
      await window.ethereum?.request({
        method: 'wallet_requestPermissions',
        params: [{ eth_accounts: {} }]
      });
      
      onAccountChange(address);
      
      toast({
        title: "Account Switched",
        description: `Switched to account ${formatAddress(address)}`
      });
    } catch (error) {
      console.error("Error switching account:", error);
      // If wallet_requestPermissions fails, just update the selection
      onAccountChange(address);
    }
  };

  if (!isConnected) {
    return (
      <div className="p-4 text-center text-muted-foreground">
        <Wallet className="h-6 w-6 mx-auto mb-2" />
        <p className="text-sm">Connect your wallet to view accounts</p>
      </div>
    );
  }

  return (
    <Card className="w-full bg-gradient-to-br from-slate-900 to-slate-800 border border-slate-700 shadow-xl">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="text-lg font-semibold text-white flex items-center gap-2">
          <div className="p-1.5 bg-blue-500/20 rounded-lg">
            <Wallet className="h-4 w-4 text-blue-400" />
          </div>
          Select Wallet Account
        </CardTitle>
        <Button
          variant="ghost"
          size="sm"
          onClick={fetchWalletAccounts}
          disabled={isLoading}
          className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-500/10"
        >
          <RefreshCw className={`h-4 w-4 ${isLoading ? 'animate-spin' : ''}`} />
        </Button>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-6">
            <div className="animate-spin h-6 w-6 border-2 border-t-transparent border-blue-400 rounded-full mx-auto mb-3"></div>
            <p className="text-sm text-slate-300">Loading accounts...</p>
          </div>
        ) : accounts.length === 0 ? (
          <div className="text-center py-6">
            <div className="p-3 bg-orange-500/10 rounded-lg inline-block mb-3">
              <Wallet className="h-6 w-6 text-orange-400" />
            </div>
            <p className="text-sm text-slate-300">No accounts found</p>
          </div>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between mb-4">
              <span className="text-sm font-medium text-blue-400">Available Accounts</span>
              <Badge variant="outline" className="text-slate-300 border-slate-600">
                {accounts.length} total
              </Badge>
            </div>
            <div className="space-y-2">
              {accounts.map((address, index) => {
                const isActive = address === currentAddress;
                const balance = parseFloat(balances[address] || "0");
                const hasLowBalance = balance < 0.1;
                
                return (
                  <div
                    key={address}
                    className={`p-4 rounded-lg border cursor-pointer transition-all duration-200 ${
                      isActive
                        ? 'bg-blue-500/20 border-blue-500/50 ring-2 ring-blue-500/30'
                        : 'bg-slate-800/50 border-slate-700 hover:bg-slate-700/50 hover:border-slate-600'
                    }`}
                    onClick={() => switchToAccount(address)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-3 mb-2">
                          <span className="text-sm font-semibold text-white">
                            Account {index + 1}
                          </span>
                          {isActive && (
                            <Badge className="text-xs bg-green-500 hover:bg-green-500">
                              Active
                            </Badge>
                          )}
                          {hasLowBalance && (
                            <Badge variant="destructive" className="text-xs">
                              Low Balance
                            </Badge>
                          )}
                        </div>
                        <div className="space-y-1">
                          <code className="text-xs font-mono text-slate-300 bg-slate-900/50 px-2 py-1 rounded block">
                            {address}
                          </code>
                          <div className="flex items-center justify-between">
                            <span className="text-xs text-slate-400">Balance:</span>
                            <span className={`text-sm font-semibold ${hasLowBalance ? 'text-red-400' : 'text-blue-400'}`}>
                              {balances[address] || "0.000000"} DCSM
                            </span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
            
            {currentAddress && parseFloat(balances[currentAddress] || "0") < 0.1 && (
              <div className="p-3 bg-yellow-500/10 border border-yellow-500/20 rounded text-sm text-yellow-400">
                <div className="p-3 bg-red-500/10 border border-red-500/20 rounded-lg">
                <div className="flex items-start space-x-2">
                  <div className="flex-shrink-0 mt-0.5">
                    <svg className="h-4 w-4 text-red-400" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <div className="flex-1">
                    <h4 className="text-sm font-medium text-red-300 mb-1">Insufficient Balance</h4>
                    <p className="text-sm text-red-200 mb-2">
                      Minimum 0.1 DCSM required for authentication.
                    </p>
                    <a 
                      href="https://dcsocial.org/swap.html" 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center px-3 py-1.5 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-md transition-colors duration-200"
                    >
                      <svg className="w-3 h-3 mr-1.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6v6m0 0v6m0-6h6m-6 0H6" />
                      </svg>
                      Get DCSM Coins
                    </a>
                  </div>
                </div>
              </div>
              </div>
            )}
            
            <div className="text-xs text-slate-400 text-center pt-3 border-t border-slate-700">
              You can switch between accounts in your wallet to choose which one to use for authentication.
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}