import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Sparkles } from "lucide-react";

// For trending topics based on actual posts
const trendingTopics = [
  {
    id: 1,
    category: "Trending",
    topic: "#to_the_moon",
    posts: "3",
  },
  {
    id: 2,
    category: "Popular",
    topic: "#crypto",
    posts: "2",
  },
  {
    id: 3,
    category: "Latest",
    topic: "#blockchain",
    posts: "2",
  },
  {
    id: 4,
    category: "Recent",
    topic: "#web3",
    posts: "1",
  },
  {
    id: 5,
    category: "New",
    topic: "#defi",
    posts: "1",
  },
];

export default function TrendingSection() {
  const [, navigate] = useLocation();
  const [showAll, setShowAll] = useState(false);
  const [trending, setTrending] = useState(trendingTopics);
  const [isGlowing, setIsGlowing] = useState(false);

  // Visual effect for trending hashtags - subtle glow animation
  useEffect(() => {
    const interval = setInterval(() => {
      setIsGlowing(prev => !prev);
    }, 3000);
    
    return () => clearInterval(interval);
  }, []);
  
  // Navigate to a trending topic
  const navigateToTrending = (topic: string) => {
    // Remove the hashtag for the URL
    const tag = topic.substring(1);
    navigate(`/trending/${tag}`);
  };

  return (
    <Card className="bg-[#141e33] rounded-xl mb-6 border border-[#1a2747] overflow-hidden">
      <CardHeader className="pb-0 pt-4 px-4">
        <div className="flex items-center">
          <Sparkles className={`h-5 w-5 mr-2 ${isGlowing ? 'text-purple-400' : 'text-blue-500'} transition-colors duration-1000`} />
          <CardTitle className="text-lg font-bold text-white">Trending Topics</CardTitle>
        </div>
      </CardHeader>
      <CardContent className="pt-3 px-0">
        <div>
          {trending.slice(0, showAll ? trending.length : 3).map((topic) => (
            <div 
              key={topic.id} 
              className="px-4 py-3 hover:bg-[#1a2747] cursor-pointer transition-colors"
              onClick={() => navigateToTrending(topic.topic)}
            >
              <div className="text-sm text-gray-400">{topic.category} · Trending</div>
              <div className="font-bold text-[15px] text-white group flex items-center">
                <span className="bg-gradient-to-r from-purple-500 to-blue-500 bg-clip-text text-transparent">{topic.topic}</span>
                <div className="w-1.5 h-1.5 rounded-full bg-purple-500 ml-2 group-hover:animate-ping"></div>
              </div>
              <div className="text-sm text-gray-400">{topic.posts} posts</div>
            </div>
          ))}
          <div 
            className="px-4 py-3 text-blue-500 hover:underline cursor-pointer font-medium"
            onClick={() => setShowAll(!showAll)}
          >
            {showAll ? "Show less" : "Show more"}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
