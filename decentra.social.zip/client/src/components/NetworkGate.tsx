import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { useToast } from '@/hooks/use-toast';
import { dcsmEnforcerNew } from '@/lib/dcsmNetworkEnforcerNew';
import { Loader2, Wifi, WifiOff, AlertCircle } from 'lucide-react';

interface NetworkGateProps {
  children: React.ReactNode;
  onNetworkReady?: () => void;
  requireUserConfirmation?: boolean;
}

export default function NetworkGate({ children, onNetworkReady, requireUserConfirmation = false }: NetworkGateProps) {
  const [isOnDCSM, setIsOnDCSM] = useState<boolean | null>(null);
  const [isChecking, setIsChecking] = useState(true);
  const [isSwitching, setIsSwitching] = useState(false);
  const [walletConnected, setWalletConnected] = useState(false);
  const [userConfirmed, setUserConfirmed] = useState(false);
  const { toast } = useToast();

  // Check network status
  const checkNetworkStatus = async () => {
    try {
      if (!window.ethereum) {
        setIsOnDCSM(false);
        setWalletConnected(false);
        return;
      }

      // Check if wallet is connected
      const accounts = await window.ethereum.request({ method: 'eth_accounts' });
      setWalletConnected(accounts.length > 0);

      if (accounts.length > 0) {
        const networkStatus = await dcsmEnforcerNew.isOnDCSMNetwork();
        setIsOnDCSM(networkStatus);
        
        // Only call onNetworkReady if user has confirmed (for auth pages) or no confirmation required
        if (networkStatus && (!requireUserConfirmation || userConfirmed) && onNetworkReady) {
          onNetworkReady();
        }
      } else {
        setIsOnDCSM(false);
      }
    } catch (error) {
      console.error('Network check failed:', error);
      setIsOnDCSM(false);
    } finally {
      setIsChecking(false);
    }
  };

  // Connect wallet
  const connectWallet = async () => {
    try {
      if (!window.ethereum) {
        toast({
          title: 'Wallet Not Found',
          description: 'Please install MetaMask or another Ethereum wallet',
          variant: 'destructive',
        });
        return;
      }

      await window.ethereum.request({ method: 'eth_requestAccounts' });
      await checkNetworkStatus();
    } catch (error) {
      console.error('Wallet connection failed:', error);
      toast({
        title: 'Connection Failed',
        description: 'Failed to connect wallet. Please try again.',
        variant: 'destructive',
      });
    }
  };

  // Switch to DCSM network
  const switchToDCSM = async () => {
    setIsSwitching(true);
    try {
      await dcsmEnforcerNew.switchToDCSMManual();
      
      // Wait a moment and check again
      setTimeout(async () => {
        await checkNetworkStatus();
        setIsSwitching(false);
        
        toast({
          title: 'Network Switched',
          description: 'Successfully switched to DCSM Mainnet',
        });
      }, 2000);
    } catch (error: any) {
      setIsSwitching(false);
      console.error('Network switch failed:', error);
      
      toast({
        title: 'Network Switch Failed',
        description: error.message || 'Please switch to DCSM Mainnet manually in your wallet',
        variant: 'destructive',
      });
    }
  };

  // Initialize network monitoring
  useEffect(() => {
    checkNetworkStatus();
    dcsmEnforcerNew.initialize();

    // Listen for network changes
    const unsubscribe = dcsmEnforcerNew.onNetworkChange((isCorrect) => {
      setIsOnDCSM(isCorrect);
      if (isCorrect && (!requireUserConfirmation || userConfirmed) && onNetworkReady) {
        onNetworkReady();
      }
    });

    return unsubscribe;
  }, [onNetworkReady, requireUserConfirmation, userConfirmed]);

  // Show loading state
  if (isChecking) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Card className="w-full max-w-md">
          <CardContent className="pt-6">
            <div className="flex flex-col items-center space-y-4">
              <Loader2 className="h-8 w-8 animate-spin text-primary" />
              <p className="text-muted-foreground">Checking network status...</p>
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Add function to confirm and proceed
  const confirmAndProceed = () => {
    setUserConfirmed(true);
    if (onNetworkReady) {
      onNetworkReady();
    }
  };

  // Show network gate if not on DCSM, wallet not connected, or waiting for user confirmation
  if (!walletConnected || !isOnDCSM || (requireUserConfirmation && isOnDCSM && !userConfirmed)) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background p-4">
        <Card className="w-full max-w-md">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <WifiOff className="h-5 w-5 text-destructive" />
              Network Required
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>
                This platform requires connection to DCSM Mainnet. Please connect your wallet and switch to the correct network to continue.
              </AlertDescription>
            </Alert>

            {!walletConnected ? (
              <div className="space-y-4">
                <p className="text-sm text-muted-foreground">
                  First, connect your Ethereum wallet:
                </p>
                <Button onClick={connectWallet} className="w-full">
                  Connect Wallet
                </Button>
              </div>
            ) : isOnDCSM && requireUserConfirmation && !userConfirmed ? (
              <div className="space-y-4">
                <div className="p-3 bg-green-500/10 border border-green-500/20 rounded-md">
                  <div className="flex items-center gap-2 text-green-700">
                    <Wifi className="h-4 w-4" />
                    <p className="text-sm">
                      <strong>Network Ready:</strong> Connected to DCSM Mainnet
                    </p>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    You're now connected to the correct network. Click below to proceed with authentication:
                  </p>
                  <Button 
                    onClick={confirmAndProceed}
                    className="w-full"
                  >
                    <Wifi className="mr-2 h-4 w-4" />
                    Proceed to Authentication
                  </Button>
                </div>

                <div className="text-xs text-muted-foreground space-y-1">
                  <p><strong>Network:</strong> DCSM Mainnet</p>
                  <p><strong>Chain ID:</strong> 19224</p>
                  <p><strong>Status:</strong> Ready for authentication</p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-md">
                  <p className="text-sm text-destructive">
                    <strong>Wrong Network:</strong> You're not connected to DCSM Mainnet
                  </p>
                </div>
                
                <div className="space-y-2">
                  <p className="text-sm text-muted-foreground">
                    Switch to DCSM Mainnet to continue:
                  </p>
                  <Button 
                    onClick={switchToDCSM} 
                    disabled={isSwitching}
                    className="w-full"
                  >
                    {isSwitching ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Switching Network...
                      </>
                    ) : (
                      <>
                        <Wifi className="mr-2 h-4 w-4" />
                        Switch to DCSM Mainnet
                      </>
                    )}
                  </Button>
                </div>

                <div className="text-xs text-muted-foreground space-y-1">
                  <p><strong>Network:</strong> DCSM Mainnet</p>
                  <p><strong>Chain ID:</strong> 19224</p>
                  <p><strong>RPC:</strong> https://rpc.decentraconnect.io</p>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    );
  }

  // Show success state briefly, then render children
  return (
    <div className="min-h-screen">
      <div className="fixed top-4 right-4 z-50">
        <div className="bg-green-500/10 border border-green-500/20 rounded-md px-3 py-2">
          <div className="flex items-center gap-2 text-green-500 text-sm">
            <Wifi className="h-4 w-4" />
            Connected to DCSM Mainnet
          </div>
        </div>
      </div>
      {children}
    </div>
  );
}