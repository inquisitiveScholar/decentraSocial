import React, { useEffect, useState } from 'react';
import { useWebSocket } from '@/hooks/useWebSocket';
import { Bell } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/context/AuthContext';

type Notification = {
  id: string;
  type: 'like' | 'comment' | 'follow';
  userId: number;
  postId?: number;
  message: string;
  read: boolean;
  createdAt: Date;
};

const NotificationAlert = () => {
  const { isConnected, lastMessage } = useWebSocket();
  const { toast } = useToast();
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [unreadCount, setUnreadCount] = useState(0);

  // Process notifications from WebSocket
  useEffect(() => {
    if (lastMessage && lastMessage.type === 'notification' && user) {
      // Build notification object
      const newNotification: Notification = {
        id: `notif-${Date.now()}`,
        type: lastMessage.action,
        userId: lastMessage.userId,
        postId: lastMessage.postId,
        message: getNotificationMessage(lastMessage),
        read: false,
        createdAt: new Date()
      };

      // Add to notifications and update unread count
      setNotifications(prev => [newNotification, ...prev]);
      setUnreadCount(prev => prev + 1);

      // Show toast notification
      toast({
        title: `New ${lastMessage.action}`,
        description: getNotificationMessage(lastMessage),
        duration: 4000,
      });
    }
  }, [lastMessage, user, toast]);

  // Helper function to generate notification message
  const getNotificationMessage = (msg: any): string => {
    switch (msg.action) {
      case 'like':
        return 'Someone liked your post';
      case 'comment':
        return 'Someone commented on your post';
      case 'follow':
        return 'Someone started following you';
      default:
        return 'You have a new notification';
    }
  };

  // Mark all notifications as read
  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, read: true }))
    );
    setUnreadCount(0);
  };

  return (
    <div className="relative">
      <Bell className="h-5 w-5" />
      
      {/* Notification badge */}
      {unreadCount > 0 && (
        <div className="absolute -top-1 -right-1 flex h-4 w-4 items-center justify-center rounded-full bg-red-500 text-[10px] font-medium text-white">
          {unreadCount}
        </div>
      )}
    </div>
  );
};

export default NotificationAlert;