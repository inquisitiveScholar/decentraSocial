import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { dcsmEnforcerNew } from '@/lib/dcsmNetworkEnforcerNew';
import { useAuth } from '@/context/AuthContext';

// Define type for window.ethereum
declare global {
  interface Window {
    ethereum?: {
      request: (args: { method: string; params?: any[] }) => Promise<any>;
      on: (event: string, callback: (...args: any[]) => void) => void;
      removeListener: (event: string, callback: (...args: any[]) => void) => void;
    };
  }
}

const MetaMaskButton = () => {
  const [account, setAccount] = useState<string | null>(null);
  const [connecting, setConnecting] = useState(false);
  const { toast } = useToast();
  const { loginWithWallet } = useAuth();

  useEffect(() => {
    // Check if MetaMask is already connected
    const checkConnection = async () => {
      if (window.ethereum) {
        try {
          const accounts = await window.ethereum.request({ method: 'eth_accounts' });
          if (accounts.length > 0) {
            setAccount(accounts[0]);
          }
        } catch (error) {
          console.error('Error checking MetaMask connection:', error);
        }
      }
    };

    checkConnection();

    // Set up event listeners for account changes
    if (window.ethereum) {
      const handleAccountsChanged = (accounts: string[]) => {
        if (accounts.length === 0) {
          // User disconnected
          setAccount(null);
        } else {
          // User switched accounts
          setAccount(accounts[0]);
        }
      };

      window.ethereum.on('accountsChanged', handleAccountsChanged);

      return () => {
        if (window.ethereum) {
          window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
        }
      };
    }
  }, []);

  const connectMetaMask = async () => {
    if (!window.ethereum) {
      toast({
        title: 'MetaMask Not Found',
        description: 'Please install MetaMask extension to connect your wallet',
        variant: 'destructive',
      });
      return;
    }

    setConnecting(true);
    try {
      const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
      if (accounts.length > 0) {
        setAccount(accounts[0]);
        
        // Use AuthContext loginWithWallet for proper network enforcement
        try {
          const user = await loginWithWallet(accounts[0]);
          if (user) {
            toast({
              title: 'Wallet Connected',
              description: `Connected to ${accounts[0].slice(0, 6)}...${accounts[0].slice(-4)} on DCSM Mainnet`,
            });
          } else {
            throw new Error('Authentication failed');
          }
        } catch (networkError) {
          console.error('Network enforcement or authentication failed:', networkError);
          setAccount(null); // Clear account on failure
          toast({
            title: 'Connection Failed',
            description: 'Must be connected to DCSM Mainnet to use this platform. Please switch networks and try again.',
            variant: 'destructive',
          });
        }
      }
    } catch (error) {
      console.error('Error connecting to MetaMask:', error);
      toast({
        title: 'Connection Failed',
        description: 'Failed to connect to MetaMask. Please try again.',
        variant: 'destructive',
      });
    } finally {
      setConnecting(false);
    }
  };

  const disconnectMetaMask = () => {
    setAccount(null);
    toast({
      title: 'Wallet Disconnected',
      description: 'Your wallet has been disconnected',
    });
  };

  // Format address for display
  const formatAddress = (address: string) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  return (
    <div>
      {account ? (
        <div className="flex flex-col space-y-2">
          <div className="px-3 py-2 bg-secondary/50 rounded-md text-sm">
            <span className="text-muted-foreground mr-1">Connected:</span>
            <span className="font-medium">{formatAddress(account)}</span>
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={disconnectMetaMask}
          >
            Disconnect
          </Button>
        </div>
      ) : (
        <Button 
          onClick={connectMetaMask} 
          disabled={connecting}
        >
          {connecting ? 'Connecting...' : 'Connect MetaMask'}
        </Button>
      )}
    </div>
  );
};

export default MetaMaskButton;