import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { PostWithUser } from "@shared/schema";
import { useAuth } from "@/context/AuthContext";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { queryClient } from "@/lib/queryClient";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle,
  DialogFooter,
  DialogDescription
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { UserIcon, ThumbsUp, ThumbsDown, MessageCircle, Repeat, Share, MoreVertical, Trash, Edit, ExternalLink, Loader2, ChevronLeft, HandHeart, Flag, UserX, AlertTriangle, Shield } from "lucide-react";
import { getNetworkConfig, getDefaultNetwork } from "@/lib/networks";
import { sendNativeTransaction, waitForTransaction, getCurrentWalletAddress, getWalletBalance } from "@/lib/web3";
import { web3TxWrapper } from "@/lib/web3TransactionWrapper";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { getAvatarSrc } from "@/components/AvatarSelector";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

interface PostCardProps {
  post: PostWithUser;
}

export default function PostCard({ post }: PostCardProps) {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  // Use preloaded data from optimized query to eliminate N+1 queries
  const [userReaction, setUserReaction] = useState<'like' | 'dislike' | null>((post as any).userReaction || null);
  const [likesCount, setLikesCount] = useState(post.likesCount || 0);
  const [dislikesCount, setDislikesCount] = useState(post.dislikesCount || 0);

  // Update local state when post data changes (e.g., after invalidation)
  useEffect(() => {
    setUserReaction((post as any).userReaction || null);
    setLikesCount(post.likesCount || 0);
    setDislikesCount(post.dislikesCount || 0);
  }, [post.id, (post as any).userReaction, post.likesCount, post.dislikesCount]);
  const [retweeted, setRetweeted] = useState((post as any).isRetweeted || false);
  const [retweetCount, setRetweetCount] = useState(post.retweetCount || 0);
  const [postTips, setPostTips] = useState({ total: post.tipTotal || "0", currency: "DCSM" });
  
  const [isCommentOpen, setIsCommentOpen] = useState(false);
  const [comment, setComment] = useState("");
  const [commentToEdit, setCommentToEdit] = useState<any>(null);
  const [editedCommentContent, setEditedCommentContent] = useState("");
  const [comments, setComments] = useState<any[]>([]);
  const [loadingComments, setLoadingComments] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isCommentEditDialogOpen, setIsCommentEditDialogOpen] = useState(false);
  const [isCommentDeleteDialogOpen, setIsCommentDeleteDialogOpen] = useState(false);
  const [showRetweetersDialog, setShowRetweetersDialog] = useState(false);
  const [retweetersList, setRetweetersList] = useState<any[]>([]);
  const [isLoadingRetweeters, setIsLoadingRetweeters] = useState(false);
  const [editedContent, setEditedContent] = useState(post.content);
  const [isEditing, setIsEditing] = useState(false);
  const [location, setLocation] = useState<string | null>(null);
  const [isTipDialogOpen, setIsTipDialogOpen] = useState(false);
  const [tipAmount, setTipAmount] = useState("0.1");
  const [isReportDialogOpen, setIsReportDialogOpen] = useState(false);
  const [reportReason, setReportReason] = useState("");
  const [reportDescription, setReportDescription] = useState("");
  // Always use DCSM network - no user selection
  const dcsmNetwork = getDefaultNetwork();
  const [isSendingTip, setIsSendingTip] = useState(false);
  const [walletBalance, setWalletBalance] = useState<string>("0");
  const [isBlocked, setIsBlocked] = useState(false);
  const [isBlockDialogOpen, setIsBlockDialogOpen] = useState(false);
  
  // Check if user is post owner
  const isPostOwner = user?.id === post.userId;

  // Tip totals are now embedded in post data - no separate API call needed

  // All data is now preloaded from optimized query - no more individual API calls needed!

  // Format the post date
  const formattedDate = formatDistanceToNow(new Date(post.createdAt), { addSuffix: true });
  
  // Reaction mutation (YouTube-style like/dislike)
  const reactionMutation = useMutation({
    mutationFn: async (reaction: 'like' | 'dislike') => {
      const response = await apiRequest("POST", `/api/posts/${post.id}/reaction`, { isLike: reaction === 'like' });
      return response.json();
    },
    onSuccess: (data: any) => {
      setUserReaction(data.reaction);
      setLikesCount(data.likesCount || 0);
      setDislikesCount(data.dislikesCount || 0);
      
      // Invalidate queries to refresh the posts feed with updated counts
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update reaction",
      });
    }
  });

  // Report post mutation
  const reportMutation = useMutation({
    mutationFn: () => {
      const reportData = {
        reportedPostId: post.id,
        reason: reportReason,
        description: reportDescription
      };
      return apiRequest("POST", "/api/reports", reportData);
    },
    onSuccess: () => {
      // Reset all dialog states to prevent UI blocking
      setIsReportDialogOpen(false);
      setReportReason("");
      setReportDescription("");
      
      // Refresh posts to hide reported post from feed
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      
      toast({
        title: "Report submitted",
        description: "This post will no longer appear in your feed.",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to submit report. Please try again.",
      });
    }
  });

  // Block user mutation
  const blockMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", `/api/users/${post.user.id}/block`);
    },
    onSuccess: () => {
      // Reset all dialog states to prevent UI blocking
      setIsBlockDialogOpen(false);
      setIsBlocked(true);
      
      toast({
        title: "User Blocked",
        description: `You have blocked @${post.user.username}`,
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to block user",
      });
    }
  });
  
  // Retweet mutation
  const retweetMutation = useMutation({
    mutationFn: () => {
      return apiRequest("POST", `/api/posts/${post.id}/retweet`, {
        content: ""  // Can be empty or include additional comment
      });
    },
    onSuccess: (response) => {
      const data = response.json();
      data.then(result => {
        setRetweeted(!!result.retweeted);
        setRetweetCount(result.retweetCount || 0);
        
        // Update the posts list to show the retweet
        queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
        
        toast({
          title: result.retweeted ? "Post reshared!" : "Reshare removed",
          description: result.retweeted ? "The post has been shared to your timeline" : "The post has been removed from your timeline",
        });
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to reshare post",
      });
    }
  });

  // Comment mutation
  const commentMutation = useMutation({
    mutationFn: (content: string) => 
      apiRequest("POST", `/api/posts/${post.id}/comments`, { content }),
    onSuccess: (data) => {
      setComment("");
      // Don't close dialog, just fetch fresh comments
      fetchComments();
      
      toast({
        title: "Comment added",
        description: "Your comment has been posted",
      });
      
      // Invalidate queries to refresh comments count
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to post comment",
      });
    }
  });
  
  // Comment edit mutation
  const editCommentMutation = useMutation({
    mutationFn: () => 
      apiRequest("PATCH", `/api/comments/${commentToEdit?.id}`, { content: editedCommentContent }),
    onSuccess: () => {
      setIsCommentEditDialogOpen(false);
      setCommentToEdit(null);
      setEditedCommentContent("");
      // Refetch comments
      fetchComments();
      toast({
        title: "Comment updated",
        description: "Your comment has been updated successfully",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update comment",
      });
    }
  });
  
  // Comment delete mutation
  const deleteCommentMutation = useMutation({
    mutationFn: () => 
      apiRequest("DELETE", `/api/comments/${commentToEdit?.id}`),
    onSuccess: () => {
      setIsCommentDeleteDialogOpen(false);
      setCommentToEdit(null);
      
      // Refetch comments
      fetchComments();
      
      // Update post comment count locally
      if (post.commentsCount && post.commentsCount > 0) {
        post.commentsCount -= 1;
      }
      
      // Invalidate queries to refresh comments count
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      
      toast({
        title: "Comment deleted",
        description: "Your comment has been deleted",
      });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete comment",
      });
    }
  });
  


  // Check if post is liked on mount
  // This would normally be done with a query, but for this demo we'll keep it simple

  const handleReaction = (reaction: 'like' | 'dislike') => {
    if (!user) {
      navigate("/auth");
      return;
    }
    
    reactionMutation.mutate(reaction);
  };

  // Fetch comments when comment dialog opens
  useEffect(() => {
    if (isCommentOpen) {
      fetchComments();
    }
  }, [isCommentOpen]);
  
  // Function to fetch comments
  const fetchComments = async () => {
    if (!post.id) return;
    
    setLoadingComments(true);
    try {
      const response = await fetch(`/api/posts/${post.id}/comments`);
      if (response.ok) {
        const data = await response.json();
        setComments(data);
      }
    } catch (error) {
      console.error('Error fetching comments:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to load comments",
      });
    } finally {
      setLoadingComments(false);
    }
  };
  
  const handleComment = () => {
    if (!user) {
      navigate("/auth");
      return;
    }
    
    setIsCommentOpen(true);
  };

  const submitComment = () => {
    if (!comment.trim()) return;
    commentMutation.mutate(comment);
  };
  
  // Edit and delete mutations
  const editPostMutation = useMutation({
    mutationFn: () => apiRequest("PATCH", `/api/posts/${post.id}`, { content: editedContent }),
    onSuccess: () => {
      setIsEditDialogOpen(false);
      
      // Update the local state to reflect the changes immediately
      post.content = editedContent;
      
      toast({
        title: "Post updated",
        description: "Your post has been updated successfully",
      });
      
      // Refresh posts
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to update post",
      });
    }
  });
  
  const deletePostMutation = useMutation({
    mutationFn: () => apiRequest("DELETE", `/api/posts/${post.id}`),
    onSuccess: () => {
      // Reset all dialog states to prevent UI blocking
      setIsDeleteDialogOpen(false);
      setIsEditDialogOpen(false);
      setIsCommentOpen(false);
      setIsCommentEditDialogOpen(false);
      setIsCommentDeleteDialogOpen(false);
      setIsTipDialogOpen(false);
      setIsReportDialogOpen(false);
      setIsBlockDialogOpen(false);
      setShowRetweetersDialog(false);
      
      toast({
        title: "Post deleted",
        description: "Your post has been deleted successfully",
      });
      
      // Refresh posts in all relevant lists
      queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
      
      // Also refresh user profile posts
      if (post.userId) {
        queryClient.invalidateQueries({ queryKey: [`/api/users/${post.userId}/posts`] });
      }
      
      // If currently on the post detail page, redirect to home
      if (window.location.pathname.includes(`/post/${post.id}`)) {
        navigate('/');
      }
    },
    onError: () => {
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to delete post",
      });
    }
  });

  const navigateToProfile = (e: React.MouseEvent) => {
    e.stopPropagation();
    navigate(`/profile/${post.user.username}`);
  };
  
  // Navigate to trending hashtag page
  const navigateToHashtag = (hashtag: string, e: React.MouseEvent) => {
    e.stopPropagation();
    e.preventDefault();
    navigate(`/trending/${hashtag.replace('#', '')}`);
  };
  
  // Format content to highlight hashtags
  const formatPostContent = (content: string) => {
    if (!content) return null;
    
    // Regex to match hashtags (#word_with_underscores or #word)
    const hashtagRegex = /#[\w_]+/g;
    
    // Split the content by hashtags
    const parts = content.split(hashtagRegex);
    
    // Extract all hashtags from the content
    const hashtags = content.match(hashtagRegex) || [];
    
    // If no hashtags, return the content as is
    if (hashtags.length === 0) return content;
    
    // Combine parts and hashtags
    return parts.map((part, index) => (
      <span key={index}>
        {part}
        {hashtags[index] && (
          <a 
            href={`/trending/${hashtags[index].replace('#', '')}`}
            onClick={(e) => navigateToHashtag(hashtags[index], e)}
            className="text-primary font-semibold hover:underline crypto-text-gradient"
          >
            {hashtags[index]}
          </a>
        )}
      </span>
    ));
  };

  return (
    <>
      <article className="p-5 hover:bg-[#141e33] transition-colors border-b border-[#1a2747] cursor-pointer">
        <div className="flex">
          <div className="mr-3 flex-shrink-0">
            <div 
              className="h-11 w-11 rounded-full overflow-hidden cursor-pointer ring-2 ring-primary"
              onClick={navigateToProfile}
            >
              {post.user.avatar ? (
                <img src={getAvatarSrc(post.user.avatar)} alt={`${post.user.displayName}'s avatar`} className="h-full w-full object-cover" />
              ) : (
                <div className="h-full w-full bg-[#141e33] flex items-center justify-center">
                  <UserIcon className="h-5 w-5 text-primary" />
                </div>
              )}
            </div>
          </div>
          <div className="flex-1">
            <div className="flex items-center mb-1">
              <h3 
                className="font-bold mr-1 cursor-pointer hover:text-primary transition-colors"
                onClick={navigateToProfile}
              >
                {post.user.displayName}
              </h3>
              <span 
                className="text-gray-400 text-sm cursor-pointer hover:text-primary transition-colors"
                onClick={navigateToProfile}
              >
                @{post.user.username}
              </span>
              <span className="mx-1 text-gray-500">·</span>
              <span className="text-gray-500 text-sm hover:underline cursor-pointer">{formattedDate}</span>
              
              {/* Post actions menu for owner */}
              {isPostOwner && (
                <div className="ml-auto">
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <button className="p-2 rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
                        <MoreVertical className="h-4 w-4" />
                      </button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end" className="bg-[#0f172a] text-gray-200 border-[#1a2747]">
                      <DropdownMenuItem 
                        className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                        onClick={() => setIsEditDialogOpen(true)}
                      >
                        <Edit className="h-4 w-4" /> 
                        <span>Edit Post</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="flex items-center gap-2 text-red-500 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                        onClick={() => setIsDeleteDialogOpen(true)}
                      >
                        <Trash className="h-4 w-4" /> 
                        <span>Delete Post</span>
                      </DropdownMenuItem>
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              )}
            </div>
            <p className="mb-3 text-[15px] leading-normal">{formatPostContent(post.content)}</p>
            {post.image && (
              <div className="rounded-xl overflow-hidden mb-3 border border-[#1a2747]">
                <img src={post.image} alt="Post attachment" className="w-full" />
              </div>
            )}
            
            {post.video && (
              <div className="rounded-xl overflow-hidden mb-3 border border-[#1a2747]">
                <video
                  src={post.video}
                  controls
                  className="w-full"
                  style={{ maxHeight: "400px" }}
                  preload="metadata"
                />
              </div>
            )}
            <div className="flex justify-between text-gray-400 pt-1">
              <button 
                className="flex items-center group"
                onClick={handleComment}
              >
                <div className="p-2 rounded-full group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                  <MessageCircle className="h-5 w-5" />
                </div>
                <span className="text-sm ml-1 group-hover:text-primary transition-colors">{post.commentsCount || 0}</span>
              </button>
              <div className="flex items-center">
                <button 
                  className="flex items-center group"
                  onClick={(e) => {
                    e.stopPropagation();
                    if (!user) {
                      navigate("/auth");
                      return;
                    }
                    
                    // Call API directly for retweet functionality
                    apiRequest("POST", `/api/posts/${post.id}/retweet`, {})
                      .then(async (response) => {
                        if (response.ok) {
                          const result = await response.json();
                          setRetweeted(result.retweeted);
                          setRetweetCount(result.retweetCount || 0);
                          
                          // Update the posts list to show the retweet
                          queryClient.invalidateQueries({ queryKey: ["/api/posts"] });
                          
                          toast({
                            title: result.retweeted ? "Post reshared!" : "Reshare removed",
                            description: result.retweeted ? "The post has been shared to your timeline" : "The post has been removed from your timeline",
                          });
                        }
                      })
                      .catch(() => {
                        toast({
                          variant: "destructive",
                          title: "Error",
                          description: "Failed to reshare post",
                        });
                      });
                  }}
                >
                  <div className={`p-2 rounded-full ${retweeted ? 'bg-green-500/10 text-green-500' : 'group-hover:bg-green-500/10 group-hover:text-green-500'} transition-colors`}>
                    <Repeat className={`h-5 w-5 ${retweeted ? 'fill-current' : ''}`} />
                  </div>
                  <span className={`text-sm ml-1 ${retweeted ? 'text-green-500' : 'group-hover:text-green-500'} transition-colors`}>{retweetCount}</span>
                </button>
                {retweetCount > 0 && (
                  <button 
                    className="ml-1 text-xs text-gray-500 hover:text-green-500"
                    onClick={(e) => {
                      e.stopPropagation();
                      setIsLoadingRetweeters(true);
                      
                      // Fetch retweeters list
                      apiRequest("GET", `/api/posts/${post.id}/retweeters`)
                        .then(response => response.json())
                        .then(data => {
                          setRetweetersList(data.retweeters || []);
                          setShowRetweetersDialog(true);
                          setIsLoadingRetweeters(false);
                        })
                        .catch(() => {
                          toast({
                            variant: "destructive",
                            title: "Error",
                            description: "Failed to fetch retweeters"
                          });
                          setIsLoadingRetweeters(false);
                        });
                    }}
                  >
                    {isLoadingRetweeters ? (
                      <Loader2 className="h-3 w-3 animate-spin" />
                    ) : (
                      <span>who?</span>
                    )}
                  </button>
                )}
              </div>
              {/* Like Button */}
              <button 
                className="flex items-center group"
                onClick={() => handleReaction('like')}
                disabled={reactionMutation.isPending}
              >
                <div className={`p-2 rounded-full group-hover:bg-green-500/10 transition-colors ${
                  userReaction === 'like' ? 'text-green-500' : 'text-gray-400 group-hover:text-green-500'
                }`}>
                  <ThumbsUp className={`h-5 w-5 ${userReaction === 'like' ? 'fill-current' : ''}`} />
                </div>
                <span className={`text-sm ml-1 ${userReaction === 'like' ? 'text-green-500' : 'text-gray-400'} group-hover:text-green-500 transition-colors`}>
                  {likesCount}
                </span>
              </button>

              {/* Dislike Button */}
              <button 
                className="flex items-center group"
                onClick={() => handleReaction('dislike')}
                disabled={reactionMutation.isPending}
              >
                <div className={`p-2 rounded-full group-hover:bg-red-500/10 transition-colors ${
                  userReaction === 'dislike' ? 'text-red-500' : 'text-gray-400 group-hover:text-red-500'
                }`}>
                  <ThumbsDown className={`h-5 w-5 ${userReaction === 'dislike' ? 'fill-current' : ''}`} />
                </div>
                <span className={`text-sm ml-1 ${userReaction === 'dislike' ? 'text-red-500' : 'text-gray-400'} group-hover:text-red-500 transition-colors`}>
                  {dislikesCount}
                </span>
              </button>
              
              {/* Tip button */}
              {!isPostOwner && (
                <button 
                  className="flex items-center group"
                  onClick={() => setIsTipDialogOpen(true)}
                >
                  <div className="p-2 rounded-full group-hover:bg-yellow-500/10 group-hover:text-yellow-500 transition-colors">
                    <HandHeart className="h-5 w-5" />
                  </div>
                  <span className="text-sm ml-1 text-yellow-500 group-hover:text-yellow-400 transition-colors">
                    {postTips.total} {postTips.currency}
                  </span>
                </button>
              )}

              {/* Share and More actions */}
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center group">
                    <div className="p-2 rounded-full group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                      <Share className="h-5 w-5" />
                    </div>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="bg-[#0f172a] text-gray-200 border-[#1a2747]">
                  <DropdownMenuItem 
                    className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                    onClick={() => {
                      navigator.clipboard.writeText(window.location.origin + `/post/${post.id}`);
                      toast({
                        title: "Link copied",
                        description: "Post link copied to clipboard",
                      });
                    }}
                  >
                    <ExternalLink className="h-4 w-4 text-gray-400" />
                    <span>Copy link</span>
                  </DropdownMenuItem>
                  {!isPostOwner && (
                    <>
                      <DropdownMenuItem 
                        className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747] text-red-400"
                        onClick={() => setIsReportDialogOpen(true)}
                      >
                        <Flag className="h-4 w-4" />
                        <span>Report post</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem 
                        className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747] text-red-400"
                        onClick={() => setIsBlockDialogOpen(true)}
                      >
                        <UserX className="h-4 w-4" />
                        <span>Block @{post.user.username}</span>
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
            </div>
          </div>
        </div>
      </article>

      <Dialog open={isCommentOpen} onOpenChange={setIsCommentOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-lg">Comments on @{post.user.username}'s post</DialogTitle>
          </DialogHeader>
          <div className="mt-4">
            <div className="mb-4 pl-4 border-l-2 border-[#1a2747]">
              <p className="text-gray-300">{post.content}</p>
              {post.image && (
                <img src={post.image} alt="Post attachment" className="w-full h-auto max-h-40 object-cover mt-2 rounded-md" />
              )}
              {post.video && (
                <video 
                  src={post.video} 
                  controls 
                  className="w-full max-h-40 mt-2 rounded-md" 
                  preload="metadata" 
                />
              )}
            </div>
            
            {/* Comments list */}
            <div className="mb-6 space-y-4">
              <h3 className="text-sm font-medium text-gray-400 mb-2">{comments.length} Comments</h3>
              
              {loadingComments ? (
                <div className="flex justify-center p-4">
                  <div className="animate-spin h-6 w-6 border-t-2 border-b-2 border-primary rounded-full"></div>
                </div>
              ) : comments.length === 0 ? (
                <div className="text-center py-4 text-gray-500">
                  <p>No comments yet. Be the first to comment!</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {comments.map(comment => (
                    <div key={comment.id} className="flex space-x-3 p-2 rounded-md hover:bg-[#141e33]/50 transition-colors">
                      <div className="flex-shrink-0">
                        {comment.user?.avatar ? (
                          <img 
                            src={getAvatarSrc(comment.user.avatar)} 
                            alt={`${comment.user.displayName}'s avatar`} 
                            className="app-avatar-sm" 
                          />
                        ) : (
                          <div className="app-avatar-sm">
                            <UserIcon className="h-4 w-4 text-primary" />
                          </div>
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex flex-wrap items-center justify-between gap-1 mb-1 w-full">
                          <div>
                            <span className="font-bold text-sm">{comment.user?.displayName}</span>
                            <span className="text-gray-400 text-xs">@{comment.user?.username}</span>
                            <span className="text-gray-500 text-xs">· {formatDistanceToNow(new Date(comment.createdAt), { addSuffix: true })}</span>
                          </div>
                          {user?.id === comment.userId && (
                            <DropdownMenu>
                              <DropdownMenuTrigger asChild>
                                <button className="p-1 rounded-full hover:bg-primary/10 hover:text-primary transition-colors">
                                  <MoreVertical className="h-4 w-4" />
                                </button>
                              </DropdownMenuTrigger>
                              <DropdownMenuContent align="end" className="bg-[#0f172a] text-gray-200 border-[#1a2747]">
                                <DropdownMenuItem 
                                  className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747]"
                                  onClick={() => {
                                    // Edit comment functionality
                                    setCommentToEdit(comment);
                                    setEditedCommentContent(comment.content);
                                    setIsCommentEditDialogOpen(true);
                                  }}
                                >
                                  <Edit className="h-4 w-4" />
                                  <span>Edit</span>
                                </DropdownMenuItem>
                                <DropdownMenuItem 
                                  className="flex items-center gap-2 cursor-pointer hover:bg-[#1a2747] focus:bg-[#1a2747] text-red-500"
                                  onClick={() => {
                                    // Delete comment functionality
                                    setCommentToEdit(comment);
                                    setIsCommentDeleteDialogOpen(true);
                                  }}
                                >
                                  <Trash className="h-4 w-4" />
                                  <span>Delete</span>
                                </DropdownMenuItem>
                              </DropdownMenuContent>
                            </DropdownMenu>
                          )}
                        </div>
                        <p className="text-sm text-gray-300">{comment.content}</p>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            {/* Add new comment */}
            {user && (
              <div className="border-t border-[#1a2747] pt-4">
                <div className="flex">
                  <div className="mr-3">
                    {user?.avatar ? (
                      <img src={getAvatarSrc(user.avatar)} alt={`${user.displayName}'s avatar`} className="h-11 w-11 rounded-full ring-2 ring-primary" />
                    ) : (
                      <div className="app-avatar-lg">
                        <UserIcon className="h-5 w-5 text-primary" />
                      </div>
                    )}
                  </div>
                  <div className="flex-1">
                    <Textarea
                      placeholder="Write your comment..."
                      className="w-full bg-transparent border-b border-[#1a2747] resize-none focus:outline-none focus:border-primary mb-3"
                      value={comment}
                      onChange={(e) => setComment(e.target.value)}
                    />
                    <div className="flex justify-end">
                      <Button
                        className="bg-primary text-primary-foreground px-5 py-2 rounded-xl font-bold hover:bg-primary/90 transition-colors"
                        onClick={submitComment}
                        disabled={!comment.trim() || commentMutation.isPending}
                      >
                        {commentMutation.isPending ? "Posting..." : "Comment"}
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
      
      {/* Comment Edit Dialog */}
      <Dialog open={isCommentEditDialogOpen} onOpenChange={setIsCommentEditDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Edit Comment</DialogTitle>
            <DialogDescription className="text-gray-400">
              Make changes to your comment below.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <Textarea
              placeholder="Edit your comment..."
              className="w-full bg-[#1a2747]/50 border-[#1a2747] resize-none focus:outline-none focus:border-primary"
              value={editedCommentContent}
              onChange={(e) => setEditedCommentContent(e.target.value)}
            />
          </div>
          <DialogFooter className="mt-4">
            <Button
              type="button"
              variant="outline"
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747]/50"
              onClick={() => setIsCommentEditDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              className="bg-primary text-primary-foreground px-5 py-2 rounded-xl font-bold hover:bg-primary/90 transition-colors"
              onClick={() => editCommentMutation.mutate()}
              disabled={!editedCommentContent.trim() || editCommentMutation.isPending}
            >
              {editCommentMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Saving...
                </>
              ) : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Comment Delete Dialog */}
      <Dialog open={isCommentDeleteDialogOpen} onOpenChange={setIsCommentDeleteDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Delete Comment</DialogTitle>
            <DialogDescription className="text-gray-400">
              Are you sure you want to delete this comment? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter className="mt-4">
            <Button
              type="button"
              variant="outline"
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747]/50"
              onClick={() => setIsCommentDeleteDialogOpen(false)}
            >
              Cancel
            </Button>
            <Button
              type="button"
              variant="destructive"
              onClick={() => deleteCommentMutation.mutate()}
              disabled={deleteCommentMutation.isPending}
            >
              {deleteCommentMutation.isPending ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Deleting...
                </>
              ) : "Delete Comment"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Edit Post Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Edit Post</DialogTitle>
            <DialogDescription className="text-gray-400">
              Make changes to your post content below.
            </DialogDescription>
          </DialogHeader>
          <div className="mt-4">
            <Textarea
              value={editedContent}
              onChange={(e) => setEditedContent(e.target.value)}
              className="min-h-[120px] w-full bg-[#141e33] border-[#1a2747] rounded-lg p-3 text-white resize-none focus:border-primary"
              placeholder="What's on your mind?"
            />
            {post.image && (
              <div className="mt-3 rounded-lg overflow-hidden border border-[#1a2747]">
                <img src={post.image} alt="Post attachment" className="w-full h-40 object-cover" />
              </div>
            )}
            {post.video && (
              <div className="mt-3 rounded-lg overflow-hidden border border-[#1a2747]">
                <video 
                  src={post.video} 
                  controls 
                  className="w-full max-h-40" 
                  preload="metadata" 
                />
              </div>
            )}
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsEditDialogOpen(false)}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Cancel
            </Button>
            <Button 
              onClick={() => editPostMutation.mutate()}
              disabled={!editedContent.trim() || editPostMutation.isPending}
              className="bg-primary text-white hover:bg-primary/90"
            >
              {editPostMutation.isPending ? "Saving..." : "Save Changes"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Delete Post Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Delete Post</DialogTitle>
            <DialogDescription className="text-gray-400">
              Are you sure you want to delete this post? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsDeleteDialogOpen(false)}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Cancel
            </Button>
            <Button 
              onClick={() => {
                deletePostMutation.mutate();
                // Close dialog immediately to prevent page locking issue
                setIsDeleteDialogOpen(false);
              }}
              disabled={deletePostMutation.isPending}
              className="bg-red-600 text-white hover:bg-red-700"
            >
              {deletePostMutation.isPending ? (
                <div className="flex items-center">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  <span>Deleting...</span>
                </div>
              ) : "Delete Post"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      
      {/* Retweeters Dialog */}
      <Dialog open={showRetweetersDialog} onOpenChange={setShowRetweetersDialog}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl z-[60]">
          <DialogHeader>
            <DialogTitle className="text-lg">Reshared by</DialogTitle>
            <DialogDescription className="text-gray-400">
              Users who shared this post
            </DialogDescription>
          </DialogHeader>
          <div className="max-h-[300px] overflow-y-auto py-2">
            {retweetersList.length > 0 ? (
              retweetersList.map((retweeter) => (
                <div 
                  key={retweeter.id} 
                  className="flex items-center gap-3 p-3 hover:bg-[#1a2747] cursor-pointer transition-colors rounded-lg"
                  onClick={() => {
                    setShowRetweetersDialog(false);
                    navigate(`/profile/${retweeter.username}`);
                  }}
                >
                  <Avatar className="h-10 w-10">
                    <AvatarImage 
                      src={retweeter.avatar || undefined} 
                      alt={retweeter.displayName}
                    />
                    <AvatarFallback className="bg-primary/10 text-primary">
                      {retweeter.displayName ? retweeter.displayName.charAt(0).toUpperCase() : "U"}
                    </AvatarFallback>
                  </Avatar>
                  <div className="flex flex-col">
                    <span className="font-medium">{retweeter.displayName}</span>
                    <span className="text-gray-400 text-sm">@{retweeter.username}</span>
                  </div>
                </div>
              ))
            ) : (
              <div className="p-4 text-center text-gray-400">
                No users have reshared this post yet
              </div>
            )}
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setShowRetweetersDialog(false)}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Close
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Tip Dialog */}
      <Dialog open={isTipDialogOpen} onOpenChange={setIsTipDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl">
          <DialogHeader>
            <DialogTitle className="text-lg">Send Tip to @{post.user.username}</DialogTitle>
            <DialogDescription className="text-gray-400">
              Support this creator by sending them a tip in cryptocurrency.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="bg-[#1a2747] rounded-lg p-3 border border-[#2a3f5f]">
              <div className="flex items-center justify-between">
                <span className="text-gray-300 text-sm">Network:</span>
                <span className="text-white font-medium">DCSM Mainnet</span>
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">
                Amount (DCSM)
              </label>
              <input
                type="number"
                step="0.001"
                min="0"
                value={tipAmount}
                onChange={(e) => setTipAmount(e.target.value)}
                className="w-full bg-[#141e33] border-[#1a2747] rounded-lg p-3 text-white focus:border-primary"
                placeholder="0.01"
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsTipDialogOpen(false)}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Cancel
            </Button>
            <Button 
              onClick={async () => {
                setIsSendingTip(true);
                try {
                  // Always use DCSM network for tips
                  const dcsmNetwork = getDefaultNetwork();
                  const networkConfig = getNetworkConfig(dcsmNetwork);
                  if (!networkConfig) {
                    toast({
                      title: "Network Error",
                      description: "DCSM network configuration not found",
                      variant: "destructive"
                    });
                    return;
                  }

                  // Check if user has a wallet address to receive the tip
                  if (!post.user.walletAddress) {
                    toast({
                      title: "No Wallet Address",
                      description: `@${post.user.username} hasn't connected their wallet yet`,
                      variant: "destructive"
                    });
                    return;
                  }

                  // Execute tip transaction with automatic DCSM network enforcement
                  const txHash = await web3TxWrapper.executeWithNetworkEnforcement(async () => {
                    // Get current wallet address
                    const walletAddress = await getCurrentWalletAddress();
                    if (!walletAddress) {
                      throw new Error("Wallet not connected. Please connect your wallet to send tips.");
                    }

                    // Check wallet balance on DCSM network
                    const balance = await getWalletBalance(dcsmNetwork);
                    if (parseFloat(balance) < parseFloat(tipAmount)) {
                      throw new Error(`Insufficient balance for tip. You need at least ${tipAmount} DCSM. Get tokens at: https://dcsocial.org/swap.html`);
                    }

                    toast({
                      title: "Sending Transaction",
                      description: "Please confirm the transaction in your wallet",
                    });

                    // Send the actual blockchain transaction on DCSM network
                    return await sendNativeTransaction(
                      post.user.walletAddress,
                      tipAmount,
                      dcsmNetwork
                    );
                  }, "Tip transaction");

                  toast({
                    title: "Transaction Sent",
                    description: "Waiting for confirmation...",
                  });

                  // Wait for transaction confirmation
                  const confirmed = await waitForTransaction(txHash);
                  
                  if (confirmed) {
                    // Record the successful tip in the database
                    const tipData = {
                      amount: tipAmount,
                      currency: "DCSM",
                      network: dcsmNetwork,
                      txHash: txHash
                    };

                    const response = await fetch(`/api/posts/${post.id}/tip`, {
                      method: "POST",
                      body: JSON.stringify(tipData),
                      headers: {
                        "Content-Type": "application/json",
                      },
                    });

                    if (response.ok) {
                      toast({
                        title: "Tip Sent Successfully!",
                        description: `Successfully sent ${tipAmount} ${networkConfig.symbol} to @${post.user.username}`,
                      });
                      
                      // Update tip total locally
                      const currentTotal = parseFloat(postTips.total || "0");
                      const newTotal = currentTotal + parseFloat(tipAmount);
                      setPostTips({ total: newTotal.toString(), currency: "DCSM" });
                    } else {
                      toast({
                        title: "Warning",
                        description: "Transaction confirmed but failed to record. Please contact support.",
                        variant: "destructive"
                      });
                    }
                  } else {
                    toast({
                      title: "Transaction Failed",
                      description: "The transaction was not confirmed",
                      variant: "destructive"
                    });
                  }

                  setIsTipDialogOpen(false);
                  setTipAmount("");
                } catch (error: any) {
                  console.error("Error sending tip:", error);
                  toast({
                    title: "Transaction Error",
                    description: error.message || "Failed to send tip. Please try again.",
                    variant: "destructive"
                  });
                } finally {
                  setIsSendingTip(false);
                }
              }}
              disabled={!tipAmount || parseFloat(tipAmount) <= 0 || isSendingTip}
              className="bg-yellow-500 text-black hover:bg-yellow-400 disabled:opacity-50"
            >
              {isSendingTip ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Sending...
                </>
              ) : (
                "Send Tip"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Report Dialog */}
      <Dialog open={isReportDialogOpen} onOpenChange={setIsReportDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl">
          <DialogHeader>
            <DialogTitle className="text-lg">Report Post</DialogTitle>
            <DialogDescription className="text-gray-400">
              Help us keep the community safe by reporting inappropriate content.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">
                Reason for reporting
              </label>
              <select
                value={reportReason}
                onChange={(e) => setReportReason(e.target.value)}
                className="w-full bg-[#141e33] border-[#1a2747] rounded-lg p-3 text-white focus:border-primary"
              >
                <option value="">Select a reason</option>
                <option value="spam">Spam</option>
                <option value="harassment">Harassment</option>
                <option value="hate_speech">Hate Speech</option>
                <option value="violence">Violence</option>
                <option value="misinformation">Misinformation</option>
                <option value="inappropriate_content">Inappropriate Content</option>
                <option value="copyright">Copyright Violation</option>
                <option value="other">Other</option>
              </select>
            </div>
            <div>
              <label className="text-sm font-medium text-gray-300 mb-2 block">
                Additional details (optional)
              </label>
              <textarea
                value={reportDescription}
                onChange={(e) => setReportDescription(e.target.value)}
                className="w-full bg-[#141e33] border-[#1a2747] rounded-lg p-3 text-white focus:border-primary resize-none"
                rows={3}
                placeholder="Provide additional context about why you're reporting this content..."
              />
            </div>
          </div>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => {
                setIsReportDialogOpen(false);
                setReportReason("");
                setReportDescription("");
              }}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Cancel
            </Button>
            <Button 
              onClick={() => reportMutation.mutate()}
              disabled={!reportReason || reportMutation.isPending}
              className="bg-red-500 text-white hover:bg-red-400"
            >
              {reportMutation.isPending ? (
                <div className="flex items-center">
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  <span>Submitting...</span>
                </div>
              ) : "Submit Report"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Block User Dialog */}
      <Dialog open={isBlockDialogOpen} onOpenChange={setIsBlockDialogOpen}>
        <DialogContent className="bg-[#0f172a] border-[#1a2747] rounded-xl">
          <DialogHeader>
            <DialogTitle className="text-lg flex items-center gap-2">
              <UserX className="h-5 w-5 text-red-400" />
              Block @{post.user.username}
            </DialogTitle>
            <DialogDescription className="text-gray-400">
              Are you sure you want to block this user? You won't see their posts or be able to interact with them.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button 
              variant="outline" 
              onClick={() => setIsBlockDialogOpen(false)}
              className="border-[#1a2747] text-gray-400 hover:bg-[#1a2747] hover:text-white"
            >
              Cancel
            </Button>
            <Button 
              onClick={() => blockMutation.mutate()}
              disabled={blockMutation.isPending}
              className="bg-red-500 text-white hover:bg-red-400"
            >
              {blockMutation.isPending ? "Blocking..." : "Block User"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
