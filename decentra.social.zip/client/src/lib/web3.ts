// Web3 transaction utilities for tip functionality
import { getNetworkConfig, getDefaultNetwork } from './networks';
import { web3TxWrapper } from './web3TransactionWrapper';

// Convert amount to Wei (for 18 decimal networks)
export function toWei(amount: string, decimals: number = 18): string {
  const factor = Math.pow(10, decimals);
  return (parseFloat(amount) * factor).toString(16);
}

// Convert Wei to readable amount
export function fromWei(weiAmount: string, decimals: number = 18): string {
  const factor = Math.pow(10, decimals);
  return (parseInt(weiAmount, 16) / factor).toString();
}

// Send native cryptocurrency transaction with automatic DCSM network enforcement
export async function sendNativeTransaction(
  toAddress: string,
  amount: string,
  network: string
): Promise<string> {
  return await web3TxWrapper.executeWithNetworkEnforcement(async () => {
    if (!window.ethereum) {
      throw new Error('MetaMask is not installed');
    }

    const networkConfig = getNetworkConfig(network);
    if (!networkConfig) {
      throw new Error(`Network ${network} not found`);
    }

    // Request account access
    const accounts = await window.ethereum.request({
      method: 'eth_requestAccounts'
    });

    if (accounts.length === 0) {
      throw new Error('No accounts available');
    }

    const fromAddress = accounts[0];

    // Convert amount to Wei
    const amountInWei = '0x' + toWei(amount, networkConfig.decimals || 18);

    // Prepare transaction
    const transactionParameters = {
      to: toAddress,
      from: fromAddress,
      value: amountInWei,
      gas: '0x5208', // 21000 gas for simple transfer
    };

    // Send transaction
    const txHash = await window.ethereum.request({
      method: 'eth_sendTransaction',
      params: [transactionParameters],
    });

    return txHash;
  }, `Send ${amount} ${network} transaction`);
}

// Wait for transaction confirmation
export async function waitForTransaction(txHash: string): Promise<boolean> {
  if (!window.ethereum) {
    throw new Error('MetaMask is not installed');
  }

  try {
    let receipt = null;
    let attempts = 0;
    const maxAttempts = 60; // Wait up to 60 seconds

    while (!receipt && attempts < maxAttempts) {
      try {
        receipt = await window.ethereum.request({
          method: 'eth_getTransactionReceipt',
          params: [txHash],
        });

        if (receipt) {
          return receipt.status === '0x1'; // Success if status is 1
        }

        // Wait 1 second before next attempt
        await new Promise(resolve => setTimeout(resolve, 1000));
        attempts++;
      } catch (error) {
        // Transaction might not be mined yet
        await new Promise(resolve => setTimeout(resolve, 1000));
        attempts++;
      }
    }

    throw new Error('Transaction confirmation timeout');
  } catch (error: any) {
    console.error('Error waiting for transaction:', error);
    throw new Error(error.message || 'Failed to confirm transaction');
  }
}

// Get wallet balance with automatic DCSM network enforcement
export async function getWalletBalance(network: string): Promise<string> {
  return await web3TxWrapper.executeWithNetworkEnforcement(async () => {
    if (!window.ethereum) {
      throw new Error('MetaMask is not installed');
    }

    const networkConfig = getNetworkConfig(network);
    if (!networkConfig) {
      throw new Error(`Network ${network} not found`);
    }

    const accounts = await window.ethereum.request({
      method: 'eth_requestAccounts'
    });

    if (accounts.length === 0) {
      throw new Error('No accounts available');
    }

    const balance = await window.ethereum.request({
      method: 'eth_getBalance',
      params: [accounts[0], 'latest'],
    });

    return fromWei(balance, networkConfig.decimals || 18);
  }, `Get ${network} wallet balance`);
}

// Force DCSM Mainnet connection - automatically add and switch network
export async function forceDCSMNetwork(): Promise<boolean> {
  if (!window.ethereum) {
    throw new Error('MetaMask is not installed');
  }

  const dcsmNetwork = getNetworkConfig(getDefaultNetwork());
  if (!dcsmNetwork) {
    throw new Error('DCSM network configuration not found');
  }

  try {
    // First try to switch to DCSM network
    await window.ethereum.request({
      method: 'wallet_switchEthereumChain',
      params: [{ chainId: dcsmNetwork.chainId }],
    });
    return true;
  } catch (switchError: any) {
    // If network doesn't exist, add it
    if (switchError.code === 4902) {
      try {
        await window.ethereum.request({
          method: 'wallet_addEthereumChain',
          params: [{
            chainId: dcsmNetwork.chainId,
            chainName: dcsmNetwork.name,
            nativeCurrency: {
              name: dcsmNetwork.currency,
              symbol: dcsmNetwork.symbol,
              decimals: dcsmNetwork.decimals || 18,
            },
            rpcUrls: [dcsmNetwork.rpcUrl],
            blockExplorerUrls: [dcsmNetwork.blockExplorer],
          }],
        });
        return true;
      } catch (addError: any) {
        console.error('Error adding DCSM network:', addError);
        throw new Error('Failed to add DCSM network to wallet');
      }
    } else {
      console.error('Error switching to DCSM network:', switchError);
      throw new Error('Failed to switch to DCSM network');
    }
  }
}

// Get current wallet address
export async function getCurrentWalletAddress(): Promise<string | null> {
  if (!window.ethereum) {
    return null;
  }

  try {
    const accounts = await window.ethereum.request({
      method: 'eth_requestAccounts'
    });

    return accounts.length > 0 ? accounts[0] : null;
  } catch (error) {
    console.error('Error getting wallet address:', error);
    return null;
  }
}

// Validate Ethereum address
export function isValidEthereumAddress(address: string): boolean {
  return /^0x[a-fA-F0-9]{40}$/.test(address);
}