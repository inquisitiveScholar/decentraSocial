// DCSM Network Enforcement - Focused implementation
declare global {
  interface Window {
    ethereum?: {
      request: (args: { method: string; params?: any[] }) => Promise<any>;
      on: (event: string, callback: (...args: any[]) => void) => void;
      removeListener: (event: string, callback: (...args: any[]) => void) => void;
    };
  }
}

// DCSM Mainnet configuration
const DCSM_NETWORK = {
  chainId: "0x4b18", // 19224 in decimal
  chainName: "DCSM Mainnet",
  nativeCurrency: {
    name: "DCSM",
    symbol: "DCSM",
    decimals: 18,
  },
  rpcUrls: ["https://rpc.decentraconnect.io"],
  blockExplorerUrls: ["https://decentraconnect.io"],
};

export class DCSMNetworkEnforcer {
  private static instance: DCSMNetworkEnforcer;
  private callbacks: Array<(isCorrectNetwork: boolean) => void> = [];
  private isEnforcing = false;
  private lastNetworkCheck: string | null = null;
  private switchInProgress = false;
  private autoSwitchEnabled = false; // Only auto-switch when explicitly enabled

  static getInstance(): DCSMNetworkEnforcer {
    if (!DCSMNetworkEnforcer.instance) {
      DCSMNetworkEnforcer.instance = new DCSMNetworkEnforcer();
    }
    return DCSMNetworkEnforcer.instance;
  }

  // Check if current network is DCSM
  async isOnDCSMNetwork(): Promise<boolean> {
    if (!window.ethereum) return false;
    
    try {
      const currentChainId = await window.ethereum.request({ method: 'eth_chainId' });
      console.log('Current network:', currentChainId, 'Expected DCSM:', DCSM_NETWORK.chainId);
      return currentChainId.toLowerCase() === DCSM_NETWORK.chainId.toLowerCase();
    } catch (error) {
      console.error('Failed to check network:', error);
      return false;
    }
  }

  // Force switch to DCSM network - aggressive switching
  async switchToDCSM(): Promise<boolean> {
    if (!window.ethereum) {
      throw new Error('Wallet not available');
    }

    if (this.switchInProgress) {
      console.log('Network switch already in progress, waiting...');
      // Wait for current switch to complete
      let attempts = 0;
      while (this.switchInProgress && attempts < 30) {
        await new Promise(resolve => setTimeout(resolve, 100));
        attempts++;
      }
    }

    this.switchInProgress = true;

    try {
      console.log('Force switching to DCSM network...');
      
      // Check current network first
      const currentChainId = await window.ethereum.request({ method: 'eth_chainId' });
      console.log('Current chain before switch:', currentChainId);
      
      if (currentChainId.toLowerCase() === DCSM_NETWORK.chainId.toLowerCase()) {
        console.log('Already on DCSM network');
        return true;
      }
      
      // Try to switch to DCSM network
      await window.ethereum.request({
        method: 'wallet_switchEthereumChain',
        params: [{ chainId: DCSM_NETWORK.chainId }],
      });

      // Wait a moment for the switch to take effect
      await new Promise(resolve => setTimeout(resolve, 500));

      // Verify the switch
      const newChainId = await window.ethereum.request({ method: 'eth_chainId' });
      const success = newChainId.toLowerCase() === DCSM_NETWORK.chainId.toLowerCase();
      
      if (success) {
        console.log('Successfully switched to DCSM network');
        this.notifyCallbacks(true);
      } else {
        console.log('Network switch verification failed. Current:', newChainId, 'Expected:', DCSM_NETWORK.chainId);
      }
      
      return success;
    } catch (switchError: any) {
      console.log('Switch failed, trying to add network. Error:', switchError.code);
      
      // If network doesn't exist (error 4902), add it
      if (switchError.code === 4902) {
        try {
          await window.ethereum.request({
            method: 'wallet_addEthereumChain',
            params: [DCSM_NETWORK],
          });

          // Verify after adding
          const newChainId = await window.ethereum.request({ method: 'eth_chainId' });
          const success = newChainId === DCSM_NETWORK.chainId;
          
          if (success) {
            console.log('Successfully added and switched to DCSM network');
            this.notifyCallbacks(true);
          }
          
          return success;
        } catch (addError: any) {
          console.error('Failed to add DCSM network:', addError);
          throw new Error('Failed to add DCSM network to wallet');
        }
      } else {
        console.error('Failed to switch to DCSM network:', switchError);
        throw new Error('Failed to switch to DCSM network');
      }
    } finally {
      this.switchInProgress = false;
    }
  }

  // Set up network monitoring - no automatic switching to prevent loops
  setupNetworkMonitoring(): void {
    if (!window.ethereum) return;

    const handleChainChanged = async (chainId: string) => {
      console.log('Network changed to:', chainId, 'Expected DCSM:', DCSM_NETWORK.chainId);
      const isCorrect = chainId === DCSM_NETWORK.chainId;
      this.notifyCallbacks(isCorrect);
      
      // Just monitor, no automatic switching to prevent infinite loops
      if (!isCorrect) {
        console.log('User is not on DCSM network. Manual switch required for platform access.');
      } else {
        console.log('User is on correct DCSM network');
      }
    };

    const handleAccountsChanged = async (accounts: string[]) => {
      if (accounts.length > 0) {
        const isCorrect = await this.isOnDCSMNetwork();
        this.notifyCallbacks(isCorrect);
        // Only enforce on account change if auto-switch is enabled
        if (!isCorrect && this.autoSwitchEnabled) {
          try {
            await this.switchToDCSM();
          } catch (error) {
            console.error('Account change network enforcement failed:', error);
          }
        }
      }
    };

    // Clean up existing listeners
    try {
      window.ethereum.removeListener('chainChanged', handleChainChanged);
      window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
    } catch (error) {
      // Ignore cleanup errors
    }

    // Add listeners
    window.ethereum.on('chainChanged', handleChainChanged);
    window.ethereum.on('accountsChanged', handleAccountsChanged);
  }

  // Add callback for network status changes
  onNetworkChange(callback: (isCorrectNetwork: boolean) => void): void {
    this.callbacks.push(callback);
  }

  // Remove callback
  removeCallback(callback: (isCorrectNetwork: boolean) => void): void {
    this.callbacks = this.callbacks.filter(cb => cb !== callback);
  }

  // Notify callbacks
  private notifyCallbacks(isCorrectNetwork: boolean): void {
    this.callbacks.forEach(callback => {
      try {
        callback(isCorrectNetwork);
      } catch (error) {
        console.error('Error in network callback:', error);
      }
    });
  }

  // Method specifically for wallet connection enforcement - MANDATORY blocking
  async enforceForWalletConnection(): Promise<boolean> {
    console.log('MANDATORY DCSM network enforcement starting...');
    
    // Temporarily disable auto-switching to prevent interference
    const originalAutoSwitch = this.autoSwitchEnabled;
    this.autoSwitchEnabled = false;
    
    try {
      // Check current network first
      const isCurrentlyOnDCSM = await this.isOnDCSMNetwork();
      console.log('Current network check:', isCurrentlyOnDCSM);
      
      if (isCurrentlyOnDCSM) {
        console.log('Already on DCSM network, proceeding...');
        return true;
      }
      
      // Force network switch with multiple attempts
      console.log('Wrong network detected, forcing switch...');
      let switchResult = false;
      
      for (let attempt = 1; attempt <= 3; attempt++) {
        console.log(`Network switch attempt ${attempt}/3`);
        try {
          switchResult = await this.switchToDCSM();
          if (switchResult) {
            // Wait for network to settle
            await new Promise(resolve => setTimeout(resolve, 2000));
            
            // Verify the switch worked
            const verifyResult = await this.isOnDCSMNetwork();
            if (verifyResult) {
              console.log(`Network switch successful on attempt ${attempt}`);
              break;
            } else {
              console.log(`Network verification failed on attempt ${attempt}`);
              switchResult = false;
            }
          }
        } catch (error) {
          console.error(`Switch attempt ${attempt} failed:`, error);
          if (attempt < 3) {
            await new Promise(resolve => setTimeout(resolve, 1000));
          }
        }
      }
      
      if (!switchResult) {
        console.error('All network switch attempts failed, blocking authentication');
        throw new Error('Failed to switch to DCSM Mainnet after multiple attempts. Please switch manually.');
      }
      
      console.log('Network enforcement successful, proceeding with authentication');
      return true;
    } finally {
      // Restore auto-switching setting
      this.autoSwitchEnabled = originalAutoSwitch;
    }
  }

  // Initialize enforcer
  async initialize(): Promise<void> {
    this.setupNetworkMonitoring();
    
    // Check current status
    const isCorrect = await this.isOnDCSMNetwork();
    this.notifyCallbacks(isCorrect);
    
    // Don't auto-switch on initialization to prevent infinite loops
    // Network switching should be explicitly requested
  }
}

// Export singleton
export const dcsmEnforcer = DCSMNetworkEnforcer.getInstance();