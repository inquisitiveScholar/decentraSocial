import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { useAccount } from "wagmi";
import { useWeb3Modal } from "@web3modal/wagmi/react";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { User } from "@shared/schema";

interface WalletAuthContextType {
  user: User | null;
  isLoading: boolean;
  isConnecting: boolean;
  isRegistering: boolean;
  registerWithWallet: (userData: WalletRegisterData) => Promise<void>;
  logout: () => Promise<void>;
  connectWallet: () => Promise<void>;
  checkWalletRegistration: (walletAddress: string) => Promise<boolean>;
}

interface WalletRegisterData {
  username: string;
  displayName: string;
  bio?: string | null;
  avatar?: string | null;
  walletAddress: string;
  network: string;
}

const WalletAuthContext = createContext<WalletAuthContextType | null>(null);

export function WalletAuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isConnecting, setIsConnecting] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  
  const { address, isConnected, chainId } = useAccount();
  const { open: openConnectModal } = useWeb3Modal();
  const { toast } = useToast();

  // Check session status on mount
  useEffect(() => {
    async function checkAuth() {
      try {
        const response = await fetch("/api/auth/session", {
          credentials: "include"
        });
        
        if (response.ok) {
          const data = await response.json();
          setUser(data.user);
        } else {
          setUser(null);
        }
      } catch (error) {
        console.error("Session check failed:", error);
        setUser(null);
      } finally {
        setIsLoading(false);
      }
    }
    
    checkAuth();
  }, []);

  // Auto login with wallet when connected
  useEffect(() => {
    if (isConnected && address && !user && !isLoading) {
      // Check if wallet is registered and login
      checkWalletRegistration(address)
        .then(isRegistered => {
          if (isRegistered) {
            walletLogin(address, chainId?.toString() || "1");
          }
        })
        .catch(err => {
          console.error("Error during auto wallet login:", err);
        });
    }
  }, [isConnected, address, user, isLoading, chainId]);

  const connectWallet = async () => {
    setIsConnecting(true);
    try {
      await openConnectModal();
    } catch (error) {
      console.error("Error connecting wallet:", error);
      toast({
        variant: "destructive",
        title: "Connection failed",
        description: "Failed to connect your wallet. Please try again."
      });
    } finally {
      setIsConnecting(false);
    }
  };

  const checkWalletRegistration = async (walletAddress: string): Promise<boolean> => {
    try {
      const response = await fetch(`/api/wallet/${walletAddress}/exists`);
      if (!response.ok) {
        throw new Error("Failed to check wallet registration");
      }
      const data = await response.json();
      return data.exists;
    } catch (error) {
      console.error("Error checking wallet registration:", error);
      return false;
    }
  };

  const walletLogin = async (walletAddress: string, network: string) => {
    try {
      const response = await apiRequest("POST", "/api/auth/wallet", {
        walletAddress,
        network
      });
      
      if (response.ok) {
        const userData = await response.json();
        setUser(userData);
        return userData;
      } else {
        const errorData = await response.json();
        if (response.status === 404 && errorData.registered === false) {
          // Wallet not registered yet
          return { registered: false, walletAddress };
        }
        throw new Error(errorData.message || "Failed to login with wallet");
      }
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Login failed",
        description: error.message || "Failed to login with wallet"
      });
      return null;
    }
  };

  const registerWithWallet = async (userData: WalletRegisterData) => {
    setIsRegistering(true);
    try {
      const response = await apiRequest("POST", "/api/auth/wallet", userData);
      
      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Registration failed");
      }
      
      const newUser = await response.json();
      setUser(newUser);
      
      toast({
        title: "Registration successful",
        description: `Welcome, ${newUser.displayName}!`
      });
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Registration failed",
        description: error.message || "Username may already be taken"
      });
      throw error;
    } finally {
      setIsRegistering(false);
    }
  };

  const logout = async () => {
    try {
      const response = await apiRequest("POST", "/api/auth/logout");
      if (response.ok) {
        setUser(null);
        toast({
          title: "Logged out",
          description: "You have been logged out successfully"
        });
      } else {
        throw new Error("Logout failed");
      }
    } catch (error) {
      toast({
        variant: "destructive",
        title: "Logout failed",
        description: "There was an error logging out"
      });
    }
  };

  return (
    <WalletAuthContext.Provider
      value={{
        user,
        isLoading,
        isConnecting,
        isRegistering,
        registerWithWallet,
        logout,
        connectWallet,
        checkWalletRegistration
      }}
    >
      {children}
    </WalletAuthContext.Provider>
  );
}

export function useWalletAuth() {
  const context = useContext(WalletAuthContext);
  if (!context) {
    throw new Error("useWalletAuth must be used within a WalletAuthProvider");
  }
  return context;
}