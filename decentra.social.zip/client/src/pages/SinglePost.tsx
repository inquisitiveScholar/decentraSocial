import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/context/AuthContext";
import { ArrowLeft, Share, ExternalLink } from "lucide-react";
import { useLocation } from "wouter";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";
import { getAvatarSrc } from "@/components/AvatarSelector";
import { Button } from "@/components/ui/button";

// Utility function to format post content
function formatPostContent(content: string) {
  return content.split('\n').map((line, index) => (
    <span key={index}>
      {line}
      {index < content.split('\n').length - 1 && <br />}
    </span>
  ));
}

export default function SinglePost() {
  const params = useParams();
  const postId = params.id;
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();

  // Fetch the specific post (public endpoint, no auth required)
  const { data: post, isLoading, error } = useQuery({
    queryKey: [`/api/posts/${postId}`],
    enabled: !!postId,
  });

  // Debug logging
  console.log('SinglePost debug:', { post, isLoading, error, postId });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-[#0a0f1c] text-white">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="sticky top-0 z-50 bg-[#0a0f1c]/80 backdrop-blur-md border-b border-[#1a2747]">
            <div className="flex items-center px-4 py-3">
              <button 
                onClick={() => navigate("/")}
                className="p-2 rounded-full hover:bg-[#141e33] transition-colors mr-3"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <h1 className="text-xl font-bold">Post</h1>
            </div>
          </div>

          {/* Loading skeleton */}
          <div className="p-4">
            <div className="bg-[#0f172a] border border-[#1a2747] rounded-xl p-6">
              <div className="flex items-start space-x-3">
                <Skeleton className="h-10 w-10 rounded-full bg-[#1a2747]" />
                <div className="flex-1 space-y-2">
                  <Skeleton className="h-4 w-32 bg-[#1a2747]" />
                  <Skeleton className="h-4 w-full bg-[#1a2747]" />
                  <Skeleton className="h-4 w-3/4 bg-[#1a2747]" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !post || !(post as any).user) {
    return (
      <div className="min-h-screen bg-[#0a0f1c] text-white">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="sticky top-0 z-50 bg-[#0a0f1c]/80 backdrop-blur-md border-b border-[#1a2747]">
            <div className="flex items-center px-4 py-3">
              <button 
                onClick={() => navigate("/")}
                className="p-2 rounded-full hover:bg-[#141e33] transition-colors mr-3"
              >
                <ArrowLeft className="h-5 w-5" />
              </button>
              <h1 className="text-xl font-bold">Post</h1>
            </div>
          </div>

          {/* Error state */}
          <div className="p-4">
            <div className="bg-[#0f172a] border border-[#1a2747] rounded-xl p-8 text-center">
              <h2 className="text-xl font-semibold mb-2">Post not found</h2>
              <p className="text-gray-400 mb-4">
                This post might have been deleted or doesn't exist.
              </p>
              <button
                onClick={() => navigate("/")}
                className="px-4 py-2 bg-purple-600 hover:bg-purple-700 rounded-lg transition-colors"
              >
                Go back to feed
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0a0f1c] text-white">
      <div className="max-w-2xl mx-auto">
        {/* Header */}
        <div className="sticky top-0 z-50 bg-[#0a0f1c]/80 backdrop-blur-md border-b border-[#1a2747]">
          <div className="flex items-center px-4 py-3">
            <button 
              onClick={() => navigate("/")}
              className="p-2 rounded-full hover:bg-[#141e33] transition-colors mr-3"
            >
              <ArrowLeft className="h-5 w-5" />
            </button>
            <div>
              <h1 className="text-xl font-bold">Post</h1>
              <p className="text-sm text-gray-400">
                by @{(post as any)?.user?.username || 'unknown'}
              </p>
            </div>
          </div>
        </div>

        {/* Single Post Content */}
        <div className="p-4">
          <div className="bg-[#0f172a] border border-[#1a2747] rounded-xl p-6">
            {/* Post Header */}
            <div className="flex items-start space-x-3 mb-4">
              <div className="app-avatar">
                {(post as any).user?.avatar ? (
                  <img 
                    src={(post as any).user.avatar.startsWith('http') ? (post as any).user.avatar : getAvatarSrc((post as any).user.avatar)} 
                    alt={`${(post as any).user.displayName || 'User'}'s avatar`} 
                    className="h-full w-full object-cover" 
                  />
                ) : (
                  <div className="h-full w-full bg-purple-600 rounded-full flex items-center justify-center text-white font-bold">
                    {(post as any).user?.displayName?.charAt(0)?.toUpperCase() || 'U'}
                  </div>
                )}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center space-x-2">
                  <h3 className="font-bold text-white hover:underline cursor-pointer">
                    {(post as any).user?.displayName || 'Unknown User'}
                  </h3>
                  <span className="text-gray-400">@{(post as any).user?.username || 'unknown'}</span>
                  <span className="text-gray-400">·</span>
                  <span className="text-gray-400 text-sm">
                    {formatDistanceToNow(new Date((post as any).createdAt), { addSuffix: true })}
                  </span>
                </div>
                {(post as any).user?.bio && (
                  <p className="text-gray-400 text-sm mt-1">{(post as any).user.bio}</p>
                )}
              </div>
            </div>

            {/* Post Content */}
            <div className="mb-4">
              <p className="text-[15px] leading-normal text-white">
                {formatPostContent((post as any).content)}
              </p>
            </div>

            {/* Media Content */}
            {(post as any).image && (
              <div className="rounded-xl overflow-hidden mb-4 border border-[#1a2747]">
                <img src={(post as any).image} alt="Post attachment" className="w-full" />
              </div>
            )}
            
            {(post as any).video && (
              <div className="rounded-xl overflow-hidden mb-4 border border-[#1a2747]">
                <video
                  src={(post as any).video}
                  controls
                  className="w-full"
                  style={{ maxHeight: "400px" }}
                  preload="metadata"
                />
              </div>
            )}

            {/* Post Stats */}
            <div className="flex items-center justify-between pt-4 border-t border-[#1a2747]">
              <div className="flex items-center space-x-6 text-gray-400">
                <div className="flex items-center space-x-1">
                  <span className="text-sm">{(post as any).commentsCount || 0} comments</span>
                </div>
                <div className="flex items-center space-x-1">
                  <span className="text-sm">{(post as any).likesCount || 0} likes</span>
                </div>
                <div className="flex items-center space-x-1">
                  <span className="text-sm">{(post as any).dislikesCount || 0} dislikes</span>
                </div>
                {(post as any).tipTotal && parseFloat((post as any).tipTotal) > 0 && (
                  <div className="flex items-center space-x-1">
                    <span className="text-sm">{(post as any).tipTotal} DCSM tips</span>
                  </div>
                )}
              </div>

              {/* Share Button */}
              <Button
                variant="outline"
                size="sm"
                onClick={() => {
                  navigator.clipboard.writeText(window.location.href);
                  toast({
                    title: "Link copied",
                    description: "Post link copied to clipboard",
                  });
                }}
                className="bg-transparent border-[#1a2747] hover:bg-[#1a2747] text-gray-400 hover:text-white"
              >
                <Share className="h-4 w-4 mr-1" />
                Share
              </Button>
            </div>

            {/* Login Prompt for Interactions */}
            {!user && (
              <div className="mt-6 p-4 bg-purple-500/10 rounded-lg border border-purple-500/20">
                <p className="text-purple-400 text-sm text-center">
                  <button 
                    onClick={() => navigate('/login')}
                    className="underline hover:text-purple-300"
                  >
                    Login
                  </button> to like, comment, or tip this post
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}