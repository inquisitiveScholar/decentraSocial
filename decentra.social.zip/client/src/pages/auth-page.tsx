import { useState } from 'react';
import { useLocation } from 'wouter';
import { z } from 'zod';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Wallet, User } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useAuth } from '@/context/AuthContext';
import { useWeb3 } from '@/context/Web3Context';
import { Textarea } from '@/components/ui/textarea';
import { insertUserSchema } from '@shared/schema';
import AvatarSelector from '@/components/AvatarSelector';

// Login Schema
const loginSchema = z.object({
  username: z.string().min(3, { message: 'Username must be at least 3 characters' }),
  password: z.string().min(6, { message: 'Password must be at least 6 characters' }),
});

// Registration Schema
const registerSchema = insertUserSchema.extend({
  password: z.string().min(6, { message: 'Password must be at least 6 characters' }),
  confirmPassword: z.string(),
}).refine((data) => data.password === data.confirmPassword, {
  message: "Passwords don't match",
  path: ["confirmPassword"],
});

// WalletConnect Schema
const walletSchema = z.object({
  username: z.string().min(3, { message: 'Username must be at least 3 characters' }),
  displayName: z.string().min(3, { message: 'Display name must be at least 3 characters' }),
  bio: z.string().optional().nullable(),
});

type LoginValues = z.infer<typeof loginSchema>;
type RegisterValues = z.infer<typeof registerSchema>;
type WalletValues = z.infer<typeof walletSchema>;

export default function AuthPage() {
  const [isLoading, setIsLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('login');
  const [walletAddress, setWalletAddress] = useState<string | null>(null);
  const [selectedAvatar, setSelectedAvatar] = useState<string>('');
  const [selectedAvatarSrc, setSelectedAvatarSrc] = useState<string>('');
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  // Temporarily comment out these hooks to avoid dependency issues
  const { login, register, user } = useAuth();
  // const { openModal, isConnected, address } = useWeb3();

  // Comment this out for now to avoid dependency on user auth state 
  // which might be causing issues
  // if (user) {
  //   setLocation('/');
  //   return null;
  // }

  // Login Form
  const loginForm = useForm<LoginValues>({
    resolver: zodResolver(loginSchema),
    defaultValues: {
      username: '',
      password: '',
    },
  });

  // Register Form
  const registerForm = useForm<RegisterValues>({
    resolver: zodResolver(registerSchema),
    defaultValues: {
      username: '',
      displayName: '',
      password: '',
      confirmPassword: '',
      bio: '',
    },
  });

  // Wallet Form
  const walletForm = useForm<WalletValues>({
    resolver: zodResolver(walletSchema),
    defaultValues: {
      username: '',
      displayName: '',
      bio: '',
    },
  });

  // Login Handler
  async function onLoginSubmit(values: LoginValues) {
    setIsLoading(true);
    try {
      await login(values.username, values.password);
      toast({
        title: 'Login successful',
        description: 'Welcome back!',
      });
      setLocation('/');
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Login failed',
        description: error.message || 'Invalid credentials',
      });
    } finally {
      setIsLoading(false);
    }
  }

  // Register Handler
  async function onRegisterSubmit(values: RegisterValues) {
    setIsLoading(true);
    try {
      const registrationData = {
        ...values,
        avatar: selectedAvatar || 'dc_avatar_1' // Default to first avatar if none selected
      };
      await register(registrationData);
      toast({
        title: 'Registration successful',
        description: 'Your account has been created',
      });
      setLocation('/');
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Registration failed',
        description: error.message || 'Error creating account',
      });
    } finally {
      setIsLoading(false);
    }
  }

  // Wallet Connect Handler
  async function handleWalletConnect() {
    // Disabled for now until we fix Web3Context issues
    toast({
      title: "Wallet connect unavailable",
      description: "This feature is temporarily disabled",
      variant: "destructive"
    });
    // openModal();
  }

  // Wallet Registration Handler
  async function onWalletSubmit(values: WalletValues) {
    // Wallet functionality temporarily disabled
    toast({
      variant: 'destructive',
      title: 'Wallet registration unavailable',
      description: 'This feature is temporarily disabled',
    });
    return;
    
    // Original implementation commented out
    /*
    if (!address) {
      toast({
        variant: 'destructive',
        title: 'Wallet not connected',
        description: 'Please connect your wallet first',
      });
      return;
    }

    setIsLoading(true);
    try {
      await registerWithWallet({
        ...values,
        walletAddress: address,
        network: 'sepolia',
      });
      toast({
        title: 'Wallet registration successful',
        description: 'Your account has been created',
      });
      setLocation('/');
    } catch (error: any) {
      toast({
        variant: 'destructive',
        title: 'Wallet registration failed',
        description: error.message || 'Error creating account',
      });
    } finally {
      setIsLoading(false);
    }
    */
  }

  return (
    <div className="flex min-h-screen">
      {/* Form Section */}
      <div className="flex flex-col justify-center px-4 py-12 sm:px-6 lg:flex-none lg:px-10 xl:px-20 w-full lg:w-1/2">
        <div className="w-full max-w-sm mx-auto lg:w-96">
          <div className="flex flex-col items-center">
            <h2 className="mt-6 text-3xl font-extrabold">
              Welcome to {import.meta.env.NEXT_PUBLIC_APP_NAME || 'Social App'}
            </h2>
            <p className="mt-2 text-sm text-center text-muted-foreground">
              Connect, share, and engage with a community of like-minded individuals
            </p>
          </div>

          <div className="mt-8">
            <Tabs defaultValue="login" className="w-full" value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="login">Login</TabsTrigger>
                <TabsTrigger value="register">Register</TabsTrigger>
                <TabsTrigger value="wallet">Web3</TabsTrigger>
              </TabsList>

              {/* Login Tab */}
              <TabsContent value="login" className="mt-6">
                <Form {...loginForm}>
                  <form onSubmit={loginForm.handleSubmit(onLoginSubmit)} className="space-y-4">
                    <FormField
                      control={loginForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input placeholder="username" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={loginForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="••••••" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? 'Logging in...' : 'Login'}
                    </Button>
                  </form>
                </Form>
                
                <div className="mt-6">
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-border"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                      <span className="px-2 bg-background text-muted-foreground">
                        Or continue with
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <Button 
                      variant="outline" 
                      onClick={handleWalletConnect} 
                      className="w-full flex items-center justify-center gap-2"
                    >
                      <Wallet className="h-4 w-4" />
                      Connect Wallet
                    </Button>
                  </div>
                </div>
              </TabsContent>

              {/* Register Tab */}
              <TabsContent value="register" className="mt-6">
                <Form {...registerForm}>
                  <form onSubmit={registerForm.handleSubmit(onRegisterSubmit)} className="space-y-4">
                    <FormField
                      control={registerForm.control}
                      name="username"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Username</FormLabel>
                          <FormControl>
                            <Input placeholder="username" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="displayName"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Display Name</FormLabel>
                          <FormControl>
                            <Input placeholder="John Doe" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="bio"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Bio</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Tell us about yourself" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Choose Your Avatar</label>
                      <AvatarSelector
                        currentAvatar={selectedAvatar}
                        onSelect={(avatarId, avatarSrc) => {
                          setSelectedAvatar(avatarId);
                          setSelectedAvatarSrc(avatarSrc);
                        }}
                      />
                    </div>
                    
                    <FormField
                      control={registerForm.control}
                      name="password"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="••••••" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <FormField
                      control={registerForm.control}
                      name="confirmPassword"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Confirm Password</FormLabel>
                          <FormControl>
                            <Input type="password" placeholder="••••••" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    
                    <Button type="submit" className="w-full" disabled={isLoading}>
                      {isLoading ? 'Creating account...' : 'Register'}
                    </Button>
                  </form>
                </Form>
                
                <div className="mt-6">
                  <div className="relative">
                    <div className="absolute inset-0 flex items-center">
                      <div className="w-full border-t border-border"></div>
                    </div>
                    <div className="relative flex justify-center text-sm">
                      <span className="px-2 bg-background text-muted-foreground">
                        Or continue with
                      </span>
                    </div>
                  </div>
                  
                  <div className="mt-6">
                    <Button 
                      variant="outline" 
                      onClick={handleWalletConnect} 
                      className="w-full flex items-center justify-center gap-2"
                    >
                      <Wallet className="h-4 w-4" />
                      Register with Wallet
                    </Button>
                  </div>
                </div>
              </TabsContent>

              {/* Wallet Tab */}
              <TabsContent value="wallet" className="mt-6">
                {true ? ( // Always show the wallet connection prompt for now
                  <div className="space-y-4">
                    <div className="p-6 text-center border rounded-lg border-border">
                      <User className="w-10 h-10 mx-auto mb-4" />
                      <h3 className="text-lg font-medium">Connect your Web3 Wallet</h3>
                      <p className="mt-2 text-sm text-muted-foreground">
                        Connect your wallet to sign in or create a new account using your Web3 identity
                      </p>
                      <Button 
                        onClick={handleWalletConnect} 
                        className="mt-4 w-full flex items-center justify-center gap-2"
                      >
                        <Wallet className="h-4 w-4" />
                        Connect Wallet
                      </Button>
                    </div>
                  </div>
                ) : (
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg border-border mb-4">
                      <div className="flex justify-between items-center">
                        <div>
                          <h3 className="font-medium">Wallet Connected</h3>
                          <p className="text-sm text-muted-foreground truncate w-40 sm:w-60">
                            {"0x1234...5678"} {/* Placeholder address */}
                          </p>
                        </div>
                        <Wallet className="h-8 w-8 text-primary" />
                      </div>
                    </div>
                    
                    <Form {...walletForm}>
                      <form onSubmit={walletForm.handleSubmit(onWalletSubmit)} className="space-y-4">
                        <FormField
                          control={walletForm.control}
                          name="username"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Username</FormLabel>
                              <FormControl>
                                <Input placeholder="username" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={walletForm.control}
                          name="displayName"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Display Name</FormLabel>
                              <FormControl>
                                <Input placeholder="John Doe" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <FormField
                          control={walletForm.control}
                          name="bio"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>Bio</FormLabel>
                              <FormControl>
                                <Textarea placeholder="Tell us about yourself" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                        
                        <div className="space-y-2">
                          <label className="text-sm font-medium">Choose Your Avatar</label>
                          <AvatarSelector
                            currentAvatar={selectedAvatar}
                            onSelect={(avatarId, avatarSrc) => {
                              setSelectedAvatar(avatarId);
                              setSelectedAvatarSrc(avatarSrc);
                            }}
                          />
                        </div>
                        
                        <Button type="submit" className="w-full" disabled={isLoading}>
                          {isLoading ? 'Creating account...' : 'Register with Wallet'}
                        </Button>
                      </form>
                    </Form>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </div>
      
      {/* Hero Section */}
      <div className="relative hidden lg:block lg:w-1/2">
        <div className="absolute inset-0 bg-gradient-to-tr from-primary to-blue-700 flex flex-col justify-center px-10">
          <div className="max-w-2xl mx-auto">
            <h1 className="text-5xl font-bold text-white mb-6">
              Connect to the Future of Social Networking
            </h1>
            <p className="text-xl text-white/90 mb-8">
              Join the platform that leverages both traditional and Web3 authentication, giving you complete control over your online identity.
            </p>
            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-white mb-2">Web3 Login</h3>
                <p className="text-white/80">Connect with your favorite Web3 wallet</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-white mb-2">Own Your Data</h3>
                <p className="text-white/80">You control what you share</p>
              </div>
              <div className="bg-white/10 backdrop-blur-sm p-4 rounded-lg">
                <h3 className="text-xl font-semibold text-white mb-2">Community</h3>
                <p className="text-white/80">Connect with like-minded people</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}