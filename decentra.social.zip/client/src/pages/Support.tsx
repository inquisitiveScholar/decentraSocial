import React from "react";
import { useLocation } from "wouter";
import { 
  ArrowLeft, 
  Mail, 
  MessageCircle, 
  Phone, 
  MapPin, 
  Clock, 
  Twitter, 
  Github, 
  Globe, 
  HelpCircle,
  Bug,
  Shield,
  Heart
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";

export default function SupportPage() {
  const [, navigate] = useLocation();

  const contactMethods = [
    {
      icon: <Mail className="h-6 w-6" />,
      title: "Email Support",
      description: "Get help via email within 24 hours",
      contact: "support@dcsocial.io",
      action: "mailto:support@dcsocial.io",
      color: "text-blue-500"
    },
    {
      icon: <MessageCircle className="h-6 w-6" />,
      title: "Live Chat",
      description: "Chat with our support team",
      contact: "Available 9 AM - 6 PM UTC",
      action: "#",
      color: "text-green-500"
    },
    {
      icon: <Twitter className="h-6 w-6" />,
      title: "Twitter Support",
      description: "Quick responses on social media",
      contact: "@DCSocialSupport",
      action: "https://twitter.com/DCSocialSupport",
      color: "text-sky-500"
    },
    {
      icon: <Github className="h-6 w-6" />,
      title: "GitHub Issues",
      description: "Report bugs and feature requests",
      contact: "github.com/dcsocial/issues",
      action: "https://github.com/dcsocial/issues",
      color: "text-gray-500"
    }
  ];

  const supportCategories = [
    {
      icon: <HelpCircle className="h-8 w-8" />,
      title: "General Help",
      description: "Getting started, account setup, and basic features",
      topics: ["Account Creation", "Wallet Connection", "Profile Setup", "Navigation"]
    },
    {
      icon: <Bug className="h-8 w-8" />,
      title: "Technical Issues",
      description: "Bugs, errors, and technical problems",
      topics: ["Login Issues", "Transaction Errors", "App Performance", "Network Problems"]
    },
    {
      icon: <Shield className="h-8 w-8" />,
      title: "Security & Privacy",
      description: "Account security and privacy concerns",
      topics: ["Wallet Security", "Privacy Settings", "Suspicious Activity", "Account Recovery"]
    },
    {
      icon: <Heart className="h-8 w-8" />,
      title: "Feature Requests",
      description: "Suggestions for new features and improvements",
      topics: ["New Features", "UI Improvements", "Mobile App", "Integrations"]
    }
  ];

  return (
    <div className="min-h-screen bg-[#0f172a] pb-20 md:pb-0">
      {/* Header */}
      <div className="sticky top-0 z-10 bg-[#0f172a] border-b border-[#1a2747] px-4 py-4">
        <div className="flex items-center gap-3">
          <button 
            onClick={() => navigate("/")}
            className="p-2 rounded-full hover:bg-[#1a2747] transition-colors"
          >
            <ArrowLeft className="h-5 w-5" />
          </button>
          <div className="flex items-center gap-2">
            <HelpCircle className="h-6 w-6 text-purple-400" />
            <h1 className="text-xl font-bold">Support Center</h1>
          </div>
        </div>
      </div>

      <div className="px-4 py-6 max-w-4xl mx-auto">
        {/* Welcome Section */}
        <div className="text-center mb-8">
          <h2 className="text-2xl font-bold mb-2">How can we help you?</h2>
          <p className="text-gray-400">
            Our support team is here to assist you with any questions or issues you may have.
          </p>
        </div>

        {/* Contact Methods */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4">Contact Us</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {contactMethods.map((method, index) => (
              <Card key={index} className="bg-[#1a2747] border-[#2a3759] hover:bg-[#1e2951] transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-center gap-3 mb-2">
                    <div className={method.color}>
                      {method.icon}
                    </div>
                    <div>
                      <h4 className="font-medium">{method.title}</h4>
                      <p className="text-sm text-gray-400">{method.description}</p>
                    </div>
                  </div>
                  <p className="text-sm text-gray-300 mb-3">{method.contact}</p>
                  <Button 
                    variant="outline" 
                    size="sm" 
                    className="w-full"
                    onClick={() => {
                      if (method.action.startsWith('http')) {
                        window.open(method.action, '_blank');
                      } else if (method.action.startsWith('mailto:')) {
                        window.location.href = method.action;
                      }
                    }}
                  >
                    Contact Now
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <Separator className="my-8 bg-[#1a2747]" />

        {/* Support Categories */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4">Support Categories</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {supportCategories.map((category, index) => (
              <Card key={index} className="bg-[#1a2747] border-[#2a3759]">
                <CardHeader>
                  <div className="flex items-center gap-3 mb-2">
                    <div className="text-purple-400">
                      {category.icon}
                    </div>
                    <div>
                      <CardTitle className="text-lg">{category.title}</CardTitle>
                      <CardDescription className="text-gray-400">
                        {category.description}
                      </CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <p className="text-sm font-medium text-gray-300 mb-2">Common Topics:</p>
                    {category.topics.map((topic, topicIndex) => (
                      <div key={topicIndex} className="flex items-center gap-2">
                        <div className="h-1.5 w-1.5 bg-purple-400 rounded-full"></div>
                        <span className="text-sm text-gray-400">{topic}</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        <Separator className="my-8 bg-[#1a2747]" />

        {/* Business Information */}
        <div className="mb-8">
          <h3 className="text-lg font-semibold mb-4">Business Information</h3>
          <Card className="bg-[#1a2747] border-[#2a3759]">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <MapPin className="h-5 w-5 text-purple-400" />
                    <div>
                      <p className="font-medium">Address</p>
                      <p className="text-sm text-gray-400">
                        123 Blockchain Street<br />
                        Crypto City, CC 12345<br />
                        United States
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <Phone className="h-5 w-5 text-purple-400" />
                    <div>
                      <p className="font-medium">Phone</p>
                      <p className="text-sm text-gray-400">+1 (555) 123-4567</p>
                    </div>
                  </div>
                </div>
                
                <div className="space-y-4">
                  <div className="flex items-center gap-3">
                    <Clock className="h-5 w-5 text-purple-400" />
                    <div>
                      <p className="font-medium">Support Hours</p>
                      <p className="text-sm text-gray-400">
                        Monday - Friday: 9 AM - 6 PM UTC<br />
                        Saturday: 10 AM - 4 PM UTC<br />
                        Sunday: Closed
                      </p>
                    </div>
                  </div>
                  
                  <div className="flex items-center gap-3">
                    <Globe className="h-5 w-5 text-purple-400" />
                    <div>
                      <p className="font-medium">Website</p>
                      <p className="text-sm text-gray-400">www.dcsocial.io</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Emergency Contact */}
        <Card className="bg-gradient-to-r from-red-900/20 to-orange-900/20 border-red-800/30">
          <CardContent className="p-6 text-center">
            <Shield className="h-12 w-12 text-red-400 mx-auto mb-4" />
            <h3 className="text-lg font-semibold mb-2 text-red-300">Emergency Security Issues</h3>
            <p className="text-sm text-gray-300 mb-4">
              If you suspect unauthorized access to your account or wallet, contact us immediately.
            </p>
            <Button 
              variant="destructive" 
              onClick={() => window.location.href = 'mailto:security@dcsocial.io?subject=URGENT: Security Issue'}
            >
              Report Security Issue
            </Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}