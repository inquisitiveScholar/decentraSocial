import {
  User,
  InsertUser,
  Post,
  InsertPost,
  Comment,
  InsertComment,
  Like,
  InsertLike,
  Follow,
  InsertFollow,
  PostWithUser,
  CommentWithUser,
  Tip,
  InsertTip,
  Report,
  InsertReport,
  Block,
  InsertBlock,
  Notification,
  InsertNotification,
} from "@shared/schema";
import { db } from "./db";
import {
  users,
  posts,
  comments,
  likes,
  follows,
  tips,
  reports,
  blocks,
  notifications,
} from "@shared/schema";
import {
  eq,
  and,
  desc,
  sql,
  asc,
  or,
  like,
  not,
  isNull,
  isNotNull,

} from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByWalletAddress(walletAddress: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: number, user: Partial<User>): Promise<User | undefined>;

  // Post operations
  createPost(post: InsertPost): Promise<Post>;
  getPost(id: number): Promise<Post | undefined>;
  getPosts(limit?: number, offset?: number, currentUserId?: number): Promise<PostWithUser[]>;
  getPostsOptimized(
    limit?: number,
    offset?: number,
    currentUserId?: number,
  ): Promise<PostWithUser[]>;
  getPostsByUser(
    userId: number,
    limit?: number,
    offset?: number,
  ): Promise<PostWithUser[]>;
  updatePost(id: number, post: Partial<Post>): Promise<Post | undefined>;
  deletePost(id: number): Promise<boolean>;
  updateCommentCount(postId: number, increment: number): Promise<boolean>;
  updateRetweetCount(postId: number, increment: number): Promise<boolean>;
  getUserRetweetOfPost(
    userId: number,
    originalPostId: number,
  ): Promise<Post | undefined>;

  // Comment operations
  createComment(comment: InsertComment): Promise<Comment>;
  getCommentsByPost(postId: number): Promise<CommentWithUser[]>;
  getComment(id: number): Promise<Comment | undefined>;
  updateComment(
    id: number,
    data: Partial<Comment>,
  ): Promise<Comment | undefined>;
  deleteComment(id: number): Promise<boolean>;

  // Like operations (YouTube-style reactions)
  createLike(like: InsertLike): Promise<Like>;
  deleteLike(postId: number, userId: number): Promise<boolean>;
  getLike(postId: number, userId: number): Promise<Like | undefined>;
  getReactionCounts(
    postId: number,
  ): Promise<{ likes: number; dislikes: number }>;

  // Block operations
  createBlock(block: InsertBlock): Promise<Block>;
  deleteBlock(blockerId: number, blockedUserId: number): Promise<boolean>;
  getBlock(
    blockerId: number,
    blockedUserId: number,
  ): Promise<Block | undefined>;

  // Report operations
  createReport(report: InsertReport): Promise<Report>;
  getReports(status?: string): Promise<Report[]>;
  updateReportStatus(
    id: number,
    status: string,
    reviewedBy?: number,
  ): Promise<Report | undefined>;

  // Follow operations
  createFollow(follow: InsertFollow): Promise<Follow>;
  deleteFollow(followerId: number, followingId: number): Promise<boolean>;
  getFollow(
    followerId: number,
    followingId: number,
  ): Promise<Follow | undefined>;
  getAllFollows(): Promise<Follow[]>;

  // Suggestions
  getUserSuggestions(userId: number, limit?: number): Promise<User[]>;

  // Search
  searchUsers(query: string, limit?: number): Promise<User[]>;

  // Trending
  getTrendingPosts(limit?: number): Promise<PostWithUser[]>;

  // Tip operations
  createTip(tip: InsertTip): Promise<Tip>;
  getTipsByPost(postId: number): Promise<{ total: string; currency: string }>;
  getTipsByUser(userId: number): Promise<Tip[]>;

  // Report operations
  createReport(report: InsertReport): Promise<Report>;
  getReports(status?: string): Promise<Report[]>;
  updateReportStatus(
    id: number,
    status: string,
    reviewedBy?: number,
  ): Promise<Report | undefined>;

  // Notification operations
  createNotification(notification: InsertNotification): Promise<Notification>;
  getNotificationsByUser(userId: number): Promise<Notification[]>;
  markNotificationAsRead(
    id: number,
    userId: number,
  ): Promise<Notification | undefined>;
  markAllNotificationsAsRead(userId: number): Promise<void>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private posts: Map<number, Post>;
  private comments: Map<number, Comment>;
  private likes: Map<number, Like>;
  private follows: Map<number, Follow>;

  private currentUserId: number;
  private currentPostId: number;
  private currentCommentId: number;
  private currentLikeId: number;
  private currentFollowId: number;

  constructor() {
    this.users = new Map();
    this.posts = new Map();
    this.comments = new Map();
    this.likes = new Map();
    this.follows = new Map();

    this.currentUserId = 1;
    this.currentPostId = 1;
    this.currentCommentId = 1;
    this.currentLikeId = 1;
    this.currentFollowId = 1;

    // Initialize with sample users
    this.initializeSampleData();
  }

  // Initialize some sample data
  private initializeSampleData() {
    // Sample users
    const sampleUsers: InsertUser[] = [
      {
        username: "emmaj",
        password: "password123",
        displayName: "Emma Johnson",
        bio: "UI/UX Designer | Creative thinker | Coffee lover",
        avatar:
          "https://images.unsplash.com/photo-1494790108377-be9c29b29330?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50",
      },
      {
        username: "alexw",
        password: "password123",
        displayName: "Alex Williams",
        bio: "Software developer | Open source contributor",
        avatar:
          "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50",
      },
      {
        username: "mayar",
        password: "password123",
        displayName: "Maya Rodriguez",
        bio: "Digital marketer | Travel enthusiast",
        avatar:
          "https://images.unsplash.com/photo-1534528741775-53994a69daeb?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50",
      },
      {
        username: "danielk",
        password: "password123",
        displayName: "Daniel Kim",
        bio: "Web developer | React enthusiast",
        avatar:
          "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50",
      },
      {
        username: "sophiac",
        password: "password123",
        displayName: "Sophia Chen",
        bio: "Frontend developer | UI specialist",
        avatar:
          "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50",
      },
      {
        username: "jamesw",
        password: "password123",
        displayName: "James Wilson",
        bio: "Full-stack developer | Tech writer",
        avatar:
          "https://images.unsplash.com/photo-1463453091185-61582044d556?ixlib=rb-4.0.3&auto=format&fit=crop&w=50&h=50",
      },
    ];

    // Create users
    sampleUsers.forEach((user) => this.createUser(user));

    // Sample posts
    const samplePosts = [
      {
        userId: 2, // Alex Williams
        content:
          "Just launched my new project! After months of work, it's finally live. Check out this new design system for creating accessible web applications.",
        image:
          "https://images.unsplash.com/photo-1558655146-d09347e92766?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      },
      {
        userId: 3, // Maya Rodriguez
        content:
          "Looking for recommendations on good UX books or resources for beginners. Anyone have suggestions? #UXDesign #Learning",
        image: "",
      },
      {
        userId: 4, // Daniel Kim
        content:
          "Attending the React Conference this weekend in San Francisco! Can't wait to learn about the latest updates and meet fellow developers. Who else is going? #ReactConf",
        image:
          "https://images.unsplash.com/photo-1515187029135-18ee286d815b?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      },
      {
        userId: 5, // Sophia Chen
        content:
          "Just completed my 30-day coding challenge! I built a new project every day using different technologies. It was exhausting but so worth it for the learning experience.",
        image:
          "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?ixlib=rb-4.0.3&auto=format&fit=crop&w=600&h=400",
      },
      {
        userId: 6, // James Wilson
        content:
          "What's your go-to stack for building web applications in 2023? I'm considering switching to Next.js + Tailwind + Prisma. Thoughts? #WebDev #TechStack",
        image: "",
      },
    ];

    // Create posts
    samplePosts.forEach((post) => this.createPost(post as InsertPost));
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async getUserByWalletAddress(
    walletAddress: string,
  ): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.walletAddress === walletAddress,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const now = new Date();
    const user: User = {
      ...insertUser,
      id,
      createdAt: now,
      followingCount: 0,
      followersCount: 0,
    };
    this.users.set(id, user);
    return user;
  }

  async updateUser(
    id: number,
    userData: Partial<User>,
  ): Promise<User | undefined> {
    const user = await this.getUser(id);
    if (!user) return undefined;

    const updatedUser = { ...user, ...userData };
    this.users.set(id, updatedUser);
    return updatedUser;
  }

  // Post operations
  async createPost(insertPost: InsertPost): Promise<Post> {
    const id = this.currentPostId++;
    const now = new Date();
    const post: Post = {
      ...insertPost,
      id,
      createdAt: now,
      likesCount: 0,
      commentsCount: 0,
    };
    this.posts.set(id, post);
    return post;
  }

  async getPost(id: number): Promise<Post | undefined> {
    return this.posts.get(id);
  }

  async getPosts(limit = 20, offset = 0, currentUserId?: number): Promise<PostWithUser[]> {
    const posts = Array.from(this.posts.values())
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(offset, offset + limit);

    return Promise.all(
      posts.map(async (post) => {
        const user = await this.getUser(post.userId);
        return { ...post, user: user! };
      }),
    );
  }

  async getPostsByUser(
    userId: number,
    limit = 20,
    offset = 0,
  ): Promise<PostWithUser[]> {
    const posts = Array.from(this.posts.values())
      .filter((post) => post.userId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(offset, offset + limit);

    return Promise.all(
      posts.map(async (post) => {
        const user = await this.getUser(post.userId);
        return { ...post, user: user! };
      }),
    );
  }

  // Comment operations
  async createComment(insertComment: InsertComment): Promise<Comment> {
    const id = this.currentCommentId++;
    const now = new Date();
    const comment: Comment = {
      ...insertComment,
      id,
      createdAt: now,
    };
    this.comments.set(id, comment);

    // Update post comment count
    const post = await this.getPost(insertComment.postId);
    if (post) {
      post.commentsCount += 1;
      this.posts.set(post.id, post);
    }

    return comment;
  }

  async getCommentsByPost(postId: number): Promise<CommentWithUser[]> {
    const comments = Array.from(this.comments.values())
      .filter((comment) => comment.postId === postId)
      .sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());

    return Promise.all(
      comments.map(async (comment) => {
        const user = await this.getUser(comment.userId);
        return { ...comment, user: user! };
      }),
    );
  }

  // Like operations
  async createLike(insertLike: InsertLike): Promise<Like> {
    // Check if like already exists
    const existingLike = await this.getLike(
      insertLike.postId,
      insertLike.userId,
    );
    if (existingLike) return existingLike;

    const id = this.currentLikeId++;
    const now = new Date();
    const like: Like = {
      ...insertLike,
      id,
      createdAt: now,
    };
    this.likes.set(id, like);

    // Update post like count
    const post = await this.getPost(insertLike.postId);
    if (post) {
      post.likesCount += 1;
      this.posts.set(post.id, post);
    }

    return like;
  }

  async deleteLike(postId: number, userId: number): Promise<boolean> {
    const like = await this.getLike(postId, userId);
    if (!like) return false;

    this.likes.delete(like.id);

    // Update post like count
    const post = await this.getPost(postId);
    if (post) {
      post.likesCount = Math.max(0, post.likesCount - 1);
      this.posts.set(post.id, post);
    }

    return true;
  }

  async getLike(postId: number, userId: number): Promise<Like | undefined> {
    return Array.from(this.likes.values()).find(
      (like) => like.postId === postId && like.userId === userId,
    );
  }

  // Follow operations
  async createFollow(insertFollow: InsertFollow): Promise<Follow> {
    // Check if follow already exists
    const existingFollow = await this.getFollow(
      insertFollow.followerId,
      insertFollow.followingId,
    );
    if (existingFollow) return existingFollow;

    const id = this.currentFollowId++;
    const now = new Date();
    const follow: Follow = {
      ...insertFollow,
      id,
      createdAt: now,
    };
    this.follows.set(id, follow);

    // Update follower and following counts
    const follower = await this.getUser(insertFollow.followerId);
    const following = await this.getUser(insertFollow.followingId);

    if (follower) {
      follower.followingCount += 1;
      this.users.set(follower.id, follower);
    }

    if (following) {
      following.followersCount += 1;
      this.users.set(following.id, following);
    }

    return follow;
  }

  async deleteFollow(
    followerId: number,
    followingId: number,
  ): Promise<boolean> {
    const follow = await this.getFollow(followerId, followingId);
    if (!follow) return false;

    this.follows.delete(follow.id);

    // Update follower and following counts
    const follower = await this.getUser(followerId);
    const following = await this.getUser(followingId);

    if (follower) {
      follower.followingCount = Math.max(0, follower.followingCount - 1);
      this.users.set(follower.id, follower);
    }

    if (following) {
      following.followersCount = Math.max(0, following.followersCount - 1);
      this.users.set(following.id, following);
    }

    return true;
  }

  async getFollow(
    followerId: number,
    followingId: number,
  ): Promise<Follow | undefined> {
    return Array.from(this.follows.values()).find(
      (follow) =>
        follow.followerId === followerId && follow.followingId === followingId,
    );
  }

  // User suggestions
  async getUserSuggestions(userId: number, limit = 3): Promise<User[]> {
    // Get users that the current user is not following
    const following = Array.from(this.follows.values())
      .filter((follow) => follow.followerId === userId)
      .map((follow) => follow.followingId);

    return Array.from(this.users.values())
      .filter((user) => user.id !== userId && !following.includes(user.id))
      .slice(0, limit);
  }

  // Search users
  async searchUsers(query: string, limit = 10): Promise<User[]> {
    return Array.from(this.users.values())
      .filter(
        (user) =>
          user.username.toLowerCase().includes(query.toLowerCase()) ||
          user.displayName.toLowerCase().includes(query.toLowerCase()),
      )
      .slice(0, limit);
  }
}

export class DatabaseStorage implements IStorage {
  // Comment management
  async getComment(id: number): Promise<Comment | undefined> {
    const [comment] = await db
      .select()
      .from(comments)
      .where(eq(comments.id, id));
    return comment;
  }

  async updateComment(
    id: number,
    data: Partial<Comment>,
  ): Promise<Comment | undefined> {
    const [updatedComment] = await db
      .update(comments)
      .set(data)
      .where(eq(comments.id, id))
      .returning();
    return updatedComment;
  }

  async deleteComment(id: number): Promise<boolean> {
    // First get the comment to know which post to update
    const [comment] = await db
      .select({ postId: comments.postId })
      .from(comments)
      .where(eq(comments.id, id));

    if (!comment) return false;

    // Delete the comment
    const deletedComments = await db
      .delete(comments)
      .where(eq(comments.id, id))
      .returning();

    if (deletedComments.length === 0) return false;

    // Update post comment count
    await db
      .update(posts)
      .set({
        commentsCount: sql`GREATEST(${posts.commentsCount} - 1, 0)`,
      })
      .where(eq(posts.id, comment.postId));

    return true;
  }

  async updateCommentCount(
    postId: number,
    increment: number,
  ): Promise<boolean> {
    await db
      .update(posts)
      .set({
        commentsCount:
          increment > 0
            ? sql`${posts.commentsCount} + ${increment}`
            : sql`GREATEST(${posts.commentsCount} + ${increment}, 0)`,
      })
      .where(eq(posts.id, postId));
    return true;
  }

  // Retweet functionality
  async updateRetweetCount(
    postId: number,
    increment: number,
  ): Promise<boolean> {
    await db
      .update(posts)
      .set({
        retweetCount:
          increment > 0
            ? sql`${posts.retweetCount} + ${increment}`
            : sql`GREATEST(${posts.retweetCount} + ${increment}, 0)`,
      })
      .where(eq(posts.id, postId));
    return true;
  }

  async getUserRetweetOfPost(
    userId: number,
    originalPostId: number,
  ): Promise<Post | undefined> {
    const [retweet] = await db
      .select()
      .from(posts)
      .where(
        and(eq(posts.userId, userId), eq(posts.originalPostId, originalPostId)),
      );
    return retweet;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.username, username));
    return user;
  }

  async getUserByWalletAddress(
    walletAddress: string,
  ): Promise<User | undefined> {
    const [user] = await db
      .select()
      .from(users)
      .where(eq(users.walletAddress, walletAddress));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async updateUser(
    id: number,
    userData: Partial<User>,
  ): Promise<User | undefined> {
    const [updatedUser] = await db
      .update(users)
      .set(userData)
      .where(eq(users.id, id))
      .returning();
    return updatedUser;
  }

  // Post operations
  async createPost(insertPost: InsertPost): Promise<Post> {
    try {
      // Make sure null values are properly set for optional fields
      const data = {
        ...insertPost,
        image: insertPost.image || null,
        video: insertPost.video || null,
      };

      const [post] = await db.insert(posts).values(data).returning();
      return post;
    } catch (error) {
      console.error("Error creating post:", error);
      throw error;
    }
  }

  async getPost(id: number): Promise<Post | undefined> {
    try {
      const [post] = await db.select().from(posts).where(eq(posts.id, id));
      return post;
    } catch (error) {
      console.error("Error getting post:", error);
      return undefined;
    }
  }

  async updatePost(
    id: number,
    updateData: Partial<Post>,
  ): Promise<Post | undefined> {
    try {
      // Only allow updating certain fields
      const allowedFields = ["content", "image", "video"];
      const filteredData: any = {};

      Object.keys(updateData).forEach((key) => {
        if (allowedFields.includes(key)) {
          filteredData[key] = updateData[key as keyof Post];
        }
      });

      const [updatedPost] = await db
        .update(posts)
        .set(filteredData)
        .where(eq(posts.id, id))
        .returning();

      return updatedPost;
    } catch (error) {
      console.error("Error updating post:", error);
      return undefined;
    }
  }

  async deletePost(id: number): Promise<boolean> {
    try {
      // First delete all comments for this post
      await db.delete(comments).where(eq(comments.postId, id));

      // Delete all likes for this post
      await db.delete(likes).where(eq(likes.postId, id));

      // Delete the post
      const deletedPosts = await db
        .delete(posts)
        .where(eq(posts.id, id))
        .returning();

      return deletedPosts.length > 0;
    } catch (error) {
      console.error("Error deleting post:", error);
      return false;
    }
  }

  async getPosts(limit = 20, offset = 0, currentUserId?: number): Promise<PostWithUser[]> {
    try {
      // Get posts with all necessary data in separate queries for accuracy
      const postsResult = await db
        .select({
          post: posts,
          user: {
            id: users.id,
            username: users.username,
            displayName: users.displayName,
            avatar: users.avatar,
            walletAddress: users.walletAddress,
            network: users.network,
            bio: users.bio,
            createdAt: users.createdAt,
            followersCount: users.followersCount,
            followingCount: users.followingCount,
          },
        })
        .from(posts)
        .innerJoin(users, eq(posts.userId, users.id))
        .leftJoin(reports, eq(reports.reportedPostId, posts.id))
        .where(isNull(reports.id))
        .orderBy(desc(posts.createdAt))
        .limit(limit)
        .offset(offset);

      // For each post, get accurate counts and user reactions
      const postsWithData = await Promise.all(
        postsResult.map(async ({ post, user }) => {
          // Get reaction counts
          const reactionCounts = await this.getReactionCounts(post.id);
          
          // Get comment count
          const commentsResult = await db
            .select({ count: sql<number>`count(*)::int` })
            .from(comments)
            .where(eq(comments.postId, post.id));
          const commentsCount = commentsResult[0]?.count || 0;
          
          // Get tip total
          const tipResult = await db
            .select({ total: sql<string>`COALESCE(SUM(CAST(amount AS DECIMAL)), 0)` })
            .from(tips)
            .where(and(eq(tips.postId, post.id), eq(tips.currency, 'DCSM')));
          const tipTotal = tipResult[0]?.total || "0";
          
          // Get user reaction if currentUserId is provided
          let userReaction: string | null = null;
          if (currentUserId) {
            const userLike = await this.getLike(post.id, currentUserId);
            if (userLike) {
              userReaction = userLike.isLike ? 'like' : 'dislike';
            }
          }

          return {
            ...post,
            likesCount: reactionCounts.likes,
            dislikesCount: reactionCounts.dislikes,
            commentsCount,
            tipTotal,
            userReaction,
            user,
          };
        })
      );

      return postsWithData;
    } catch (error) {
      console.error("Error getting posts:", error);
      return [];
    }
  }

  async getPostsOptimized(
    limit = 20,
    offset = 0,
    currentUserId?: number,
  ): Promise<PostWithUser[]> {
    try {
      if (!currentUserId) {
        return []; // Only show posts to authenticated users
      }

      // Get posts from followed users only + user's own posts, excluding reported posts
      const result = await db
        .select({
          id: posts.id,
          userId: posts.userId,
          content: posts.content,
          image: posts.image,
          video: posts.video,
          createdAt: posts.createdAt,
          originalPostId: posts.originalPostId,
          retweetCount: posts.retweetCount,
          commentsCount: posts.commentsCount,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
          walletAddress: users.walletAddress,
          network: users.network,
          bio: users.bio,
          userCreatedAt: users.createdAt,
          followersCount: users.followersCount,
          followingCount: users.followingCount,
          likesCount: sql<number>`COALESCE(COUNT(CASE WHEN likes.is_like = true THEN 1 END), 0)`,
          dislikesCount: sql<number>`COALESCE(COUNT(CASE WHEN likes.is_like = false THEN 1 END), 0)`,
          tipTotal: sql<string>`COALESCE(SUM(CASE WHEN tips.currency = 'DCSM' THEN CAST(tips.amount AS DECIMAL) END), 0)`,
        })
        .from(posts)
        .innerJoin(users, eq(posts.userId, users.id))
        .leftJoin(likes, eq(likes.postId, posts.id))
        .leftJoin(tips, eq(tips.postId, posts.id))
        .leftJoin(
          follows,
          and(
            eq(follows.followerId, currentUserId),
            eq(follows.followingId, posts.userId),
          ),
        )
        .leftJoin(
          reports,
          and(
            eq(reports.reportedPostId, posts.id),
            eq(reports.reporterId, currentUserId),
          ),
        )
        .where(
          and(
            // Show posts from followed users OR user's own posts
            or(
              not(isNull(follows.id)), // Posts from followed users
              eq(posts.userId, currentUserId), // User's own posts
            ),
            // Exclude reported posts
            isNull(reports.id),
          ),
        )
        .groupBy(
          posts.id,
          posts.userId,
          posts.content,
          posts.image,
          posts.video,
          posts.createdAt,
          posts.originalPostId,
          posts.retweetCount,
          posts.commentsCount,
          users.id,
          users.username,
          users.displayName,
          users.avatar,
          users.walletAddress,
          users.network,
          users.bio,
          users.createdAt,
          users.followersCount,
          users.followingCount,
        )
        .orderBy(desc(posts.createdAt))
        .limit(limit)
        .offset(offset);

      return result.map((row) => ({
        id: row.id,
        userId: row.userId,
        content: row.content,
        image: row.image,
        video: row.video,
        createdAt: row.createdAt,
        originalPostId: row.originalPostId,
        retweetCount: row.retweetCount,
        commentsCount: row.commentsCount,
        likesCount: row.likesCount,
        dislikesCount: row.dislikesCount,
        tipTotal: row.tipTotal || "0",
        user: {
          id: row.userId,
          username: row.username,
          displayName: row.displayName,
          avatar: row.avatar,
          walletAddress: row.walletAddress,
          network: row.network,
          bio: row.bio,
          createdAt: row.userCreatedAt,
          followersCount: row.followersCount,
          followingCount: row.followingCount,
          password: "", // Not needed for display
        },
      }));
    } catch (error) {
      console.error("Error getting optimized posts:", error);
      // Fallback to regular posts query
      return this.getPosts(limit, offset);
    }
  }

  async getPostsByUser(
    userId: number,
    limit = 20,
    offset = 0,
  ): Promise<PostWithUser[]> {
    const result = await db
      .select({
        post: posts,
        user: users,
      })
      .from(posts)
      .innerJoin(users, eq(posts.userId, users.id))
      .where(eq(posts.userId, userId))
      .orderBy(desc(posts.createdAt))
      .limit(limit)
      .offset(offset);

    return result.map(({ post, user }) => ({ ...post, user }));
  }

  // Comment operations
  async createComment(insertComment: InsertComment): Promise<Comment> {
    const [comment] = await db
      .insert(comments)
      .values(insertComment)
      .returning();

    // Update post comment count
    await db
      .update(posts)
      .set({
        commentsCount: sql`${posts.commentsCount} + 1`,
      })
      .where(eq(posts.id, insertComment.postId));

    return comment;
  }

  async getCommentsByPost(postId: number): Promise<CommentWithUser[]> {
    const result = await db
      .select({
        comment: comments,
        user: users,
      })
      .from(comments)
      .innerJoin(users, eq(comments.userId, users.id))
      .where(eq(comments.postId, postId))
      .orderBy(asc(comments.createdAt));

    return result.map(({ comment, user }) => ({ ...comment, user }));
  }

  // Like operations
  async createLike(insertLike: InsertLike): Promise<Like> {
    // Check if like already exists
    const existingLike = await this.getLike(
      insertLike.postId,
      insertLike.userId,
    );
    if (existingLike) return existingLike;

    const [like] = await db.insert(likes).values(insertLike).returning();

    // Update post like count
    await db
      .update(posts)
      .set({
        likesCount: sql`${posts.likesCount} + 1`,
      })
      .where(eq(posts.id, insertLike.postId));

    return like;
  }

  async deleteLike(postId: number, userId: number): Promise<boolean> {
    const deletedLikes = await db
      .delete(likes)
      .where(and(eq(likes.postId, postId), eq(likes.userId, userId)))
      .returning();

    if (deletedLikes.length === 0) return false;

    // Update post like count
    await db
      .update(posts)
      .set({
        likesCount: sql`GREATEST(${posts.likesCount} - 1, 0)`,
      })
      .where(eq(posts.id, postId));

    return true;
  }

  async getLike(postId: number, userId: number): Promise<Like | undefined> {
    const [like] = await db
      .select()
      .from(likes)
      .where(and(eq(likes.postId, postId), eq(likes.userId, userId)));

    return like;
  }

  async getReactionCounts(
    postId: number,
  ): Promise<{ likes: number; dislikes: number }> {
    const result = await db
      .select({
        isLike: likes.isLike,
        count: sql<number>`count(*)::int`,
      })
      .from(likes)
      .where(eq(likes.postId, postId))
      .groupBy(likes.isLike);

    let likesCount = 0;
    let dislikesCount = 0;

    result.forEach((row) => {
      if (row.isLike) {
        likesCount = row.count;
      } else {
        dislikesCount = row.count;
      }
    });

    return { likes: likesCount, dislikes: dislikesCount };
  }

  // Block operations
  async createBlock(insertBlock: InsertBlock): Promise<Block> {
    const [block] = await db.insert(blocks).values(insertBlock).returning();
    return block;
  }

  async deleteBlock(
    blockerId: number,
    blockedUserId: number,
  ): Promise<boolean> {
    const deletedBlocks = await db
      .delete(blocks)
      .where(
        and(
          eq(blocks.blockerId, blockerId),
          eq(blocks.blockedId, blockedUserId),
        ),
      )
      .returning();
    return deletedBlocks.length > 0;
  }

  async getBlock(
    blockerId: number,
    blockedUserId: number,
  ): Promise<Block | undefined> {
    const [block] = await db
      .select()
      .from(blocks)
      .where(
        and(
          eq(blocks.blockerId, blockerId),
          eq(blocks.blockedId, blockedUserId),
        ),
      );
    return block;
  }

  // Follow operations
  async createFollow(insertFollow: InsertFollow): Promise<Follow> {
    // Check if follow already exists
    const existingFollow = await this.getFollow(
      insertFollow.followerId,
      insertFollow.followingId,
    );
    if (existingFollow) return existingFollow;

    const [follow] = await db.insert(follows).values(insertFollow).returning();

    // Update follower and following counts
    await db
      .update(users)
      .set({
        followingCount: sql`${users.followingCount} + 1`,
      })
      .where(eq(users.id, insertFollow.followerId));

    await db
      .update(users)
      .set({
        followersCount: sql`${users.followersCount} + 1`,
      })
      .where(eq(users.id, insertFollow.followingId));

    return follow;
  }

  async deleteFollow(
    followerId: number,
    followingId: number,
  ): Promise<boolean> {
    const deletedFollows = await db
      .delete(follows)
      .where(
        and(
          eq(follows.followerId, followerId),
          eq(follows.followingId, followingId),
        ),
      )
      .returning();

    if (deletedFollows.length === 0) return false;

    // Update follower and following counts
    await db
      .update(users)
      .set({
        followingCount: sql`GREATEST(${users.followingCount} - 1, 0)`,
      })
      .where(eq(users.id, followerId));

    await db
      .update(users)
      .set({
        followersCount: sql`GREATEST(${users.followersCount} - 1, 0)`,
      })
      .where(eq(users.id, followingId));

    return true;
  }

  async getFollow(
    followerId: number,
    followingId: number,
  ): Promise<Follow | undefined> {
    const [follow] = await db
      .select()
      .from(follows)
      .where(
        and(
          eq(follows.followerId, followerId),
          eq(follows.followingId, followingId),
        ),
      );

    return follow;
  }

  async getAllFollows(): Promise<Follow[]> {
    return await db.select().from(follows);
  }

  // User suggestions
  async getUserSuggestions(userId: number, limit = 3): Promise<User[]> {
    try {
      // Simplify this function to just return a few random users that aren't the current user
      // This avoids the in() operator issue and still provides suggestions
      const suggestions = await db
        .select()
        .from(users)
        .where(not(eq(users.id, userId)))
        .limit(limit);

      return suggestions;
    } catch (error) {
      console.error("Error getting user suggestions:", error);
      // Return empty array instead of throwing error
      return [];
    }
  }

  // Search users
  async searchUsers(query: string, limit = 10): Promise<User[]> {
    const results = await db
      .select()
      .from(users)
      .where(
        or(
          like(users.username, `%${query}%`),
          like(users.displayName, `%${query}%`),
        ),
      )
      .limit(limit);

    return results;
  }

  // Tip operations
  async createTip(insertTip: InsertTip): Promise<Tip> {
    const [tip] = await db.insert(tips).values(insertTip).returning();
    return tip;
  }

  async getTipsByPost(
    postId: number,
  ): Promise<{ total: string; currency: string }> {
    const results = await db
      .select({
        total: sql<string>`COALESCE(SUM(CAST(${tips.amount} AS DECIMAL)), 0)`,
        currency: tips.currency,
      })
      .from(tips)
      .where(eq(tips.postId, postId))
      .groupBy(tips.currency)
      .limit(1);

    if (results.length > 0) {
      return {
        total: results[0].total || "0",
        currency: results[0].currency || "DCSM",
      };
    }

    return { total: "0", currency: "DCSM" };
  }

  async getTipsByUser(userId: number): Promise<Tip[]> {
    return await db
      .select()
      .from(tips)
      .where(eq(tips.toUserId, userId))
      .orderBy(desc(tips.createdAt));
  }

  // Report operations
  async createReport(insertReport: InsertReport): Promise<Report> {
    const [report] = await db.insert(reports).values(insertReport).returning();
    return report;
  }

  async getReports(status?: string): Promise<Report[]> {
    const query = db.select().from(reports);

    if (status) {
      return await query
        .where(eq(reports.status, status))
        .orderBy(desc(reports.createdAt));
    }

    return await query.orderBy(desc(reports.createdAt));
  }

  async updateReportStatus(
    id: number,
    status: string,
    reviewedBy?: number,
  ): Promise<Report | undefined> {
    const [report] = await db
      .update(reports)
      .set({
        status,
        reviewedAt: new Date(),
        reviewedBy,
      })
      .where(eq(reports.id, id))
      .returning();
    return report;
  }

  // Notification operations
  async createNotification(
    insertNotification: InsertNotification,
  ): Promise<Notification> {
    const [notification] = await db
      .insert(notifications)
      .values(insertNotification)
      .returning();
    return notification;
  }

  async getNotificationsByUser(userId: number): Promise<any[]> {
    const result = await db
      .select({
        id: notifications.id,
        userId: notifications.userId,
        fromUserId: notifications.fromUserId,
        type: notifications.type,
        postId: notifications.postId,
        commentId: notifications.commentId,
        message: notifications.message,
        read: notifications.read,
        createdAt: notifications.createdAt,
        fromUserData: {
          id: users.id,
          username: users.username,
          displayName: users.displayName,
          avatar: users.avatar,
        },
      })
      .from(notifications)
      .leftJoin(users, eq(notifications.fromUserId, users.id))
      .where(eq(notifications.userId, userId))
      .orderBy(desc(notifications.createdAt));

    return result.map((row) => ({
      id: row.id,
      userId: row.userId,
      fromUserId: row.fromUserId,
      type: row.type,
      postId: row.postId,
      commentId: row.commentId,
      message: row.message,
      read: row.read,
      createdAt: row.createdAt,
      fromUser: row.fromUserData?.id ? row.fromUserData : null,
    }));
  }

  async markNotificationAsRead(
    id: number,
    userId: number,
  ): Promise<Notification | undefined> {
    const [notification] = await db
      .update(notifications)
      .set({ read: true })
      .where(and(eq(notifications.id, id), eq(notifications.userId, userId)))
      .returning();
    return notification;
  }

  async markAllNotificationsAsRead(userId: number): Promise<void> {
    await db
      .update(notifications)
      .set({ read: true })
      .where(eq(notifications.userId, userId));
  }

  async getTrendingPosts(limit = 20): Promise<PostWithUser[]> {
    try {
      // Use the existing getPosts method but order by engagement (likes + comments)
      const allPosts = await this.getPosts(100, 0); // Get more posts to sort
      
      // Calculate engagement score and sort
      const postsWithEngagement = allPosts.map(post => ({
        ...post,
        engagementScore: (post.likesCount || 0) + (post.commentsCount || 0) - (post.dislikesCount || 0)
      }));
      
      // Sort by engagement score descending, then by creation date
      postsWithEngagement.sort((a, b) => {
        if (b.engagementScore !== a.engagementScore) {
          return b.engagementScore - a.engagementScore;
        }
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
      
      return postsWithEngagement.slice(0, limit);
    } catch (error) {
      console.error("Error getting trending posts:", error);
      return [];
    }
  }
}

// Initialize database storage
export const storage = new DatabaseStorage();
